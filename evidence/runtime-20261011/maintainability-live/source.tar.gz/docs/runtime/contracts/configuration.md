# Configuration contract (v1)

Host configuration is root-owned JSON, mode 0640 or stricter. Environment
variables may select a test config path but may not override security policy.

Required host fields are state directory, Unix socket, Kerf executable,
Multikernel sysfs root, approved kernel-manifest directory, minimum primary
CPU count and memory, forbidden APIC IDs (including 0), backend timeout, and
maximum protocol frame size. Defaults are `/var/lib/mkruntime`,
`/run/mkruntimed.sock`, `/sys/fs/multikernel`, four primary CPUs, 8 GiB primary
memory, 30 seconds, and 1 MiB.

Per-sandbox input contains only ID, requested CPU APIC IDs, memory bytes,
approved kernel-manifest name, OCI bundle path, child CID, agent endpoint, and optional
labels. CPU IDs are unique non-negative integers and may not intersect the
forbidden set. Memory is an integer byte count. Labels have bounded key/value
sizes and never affect filesystem paths.

Configuration is parsed strictly. Unknown fields, duplicate JSON keys,
relative artifact paths, numeric overflow, world-writable configuration, and
unsafe state/socket parents are rejected before mutation.

The machine-readable forms are
[`host-config-v1.schema.json`](schemas/host-config-v1.schema.json) and
[`sandbox-config-v1.schema.json`](schemas/sandbox-config-v1.schema.json).
Label keys match `^[a-z][a-z0-9_.-]{0,62}$`; values are at most 256 characters.
Duplicate object names are invalid during parsing, before schema or wire-body
validation. Runtime Go code uses the shared `protocol.StrictDecode` decoder.

The primary network service has separate root-owned configuration: an explicit
egress interface, canonical RFC1918 `/16` through `/30` allocation pool,
validated MTU, bounded DNS lists, state directory, Unix socket, and authorized
UID. The CNI 1.0.0 configuration selects that socket and an absolute private
generation-cache directory. The shim may select test paths with
`MK_NETWORK_SOCKET`, `MK_CNI_BINARY`, and `MK_CNI_CONFIG`; endpoint policy still
comes only from `mknetd`.
