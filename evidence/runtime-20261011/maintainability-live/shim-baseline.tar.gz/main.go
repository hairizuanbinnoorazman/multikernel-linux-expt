//go:build linux

package main

import (
	"bytes"
	"context"
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"syscall"
	"time"

	cgroupstats "github.com/containerd/cgroups/stats/v1"
	eventstypes "github.com/containerd/containerd/api/events"
	taskapi "github.com/containerd/containerd/api/runtime/task/v2"
	types "github.com/containerd/containerd/api/types"
	tasktypes "github.com/containerd/containerd/api/types/task"
	"github.com/containerd/containerd/errdefs"
	"github.com/containerd/containerd/namespaces"
	ctruntime "github.com/containerd/containerd/runtime"
	"github.com/containerd/containerd/runtime/v2/shim"
	"github.com/containerd/typeurl/v2"
	specs "github.com/opencontainers/runtime-spec/specs-go"
	"golang.org/x/sys/unix"
	"google.golang.org/protobuf/proto"
	"google.golang.org/protobuf/types/known/anypb"
	"google.golang.org/protobuf/types/known/emptypb"
	"google.golang.org/protobuf/types/known/timestamppb"

	"github.com/hairizuan/multikernel-linux-expt/runtime/agent"
	"github.com/hairizuan/multikernel-linux-expt/runtime/internal/buildinfo"
	"github.com/hairizuan/multikernel-linux-expt/runtime/internal/daemon"
	mknetwork "github.com/hairizuan/multikernel-linux-expt/runtime/internal/network"
	rootfspkg "github.com/hairizuan/multikernel-linux-expt/runtime/internal/rootfs"
	"github.com/hairizuan/multikernel-linux-expt/runtime/internal/safefile"
	"github.com/hairizuan/multikernel-linux-expt/runtime/internal/unixsocket"
	"github.com/hairizuan/multikernel-linux-expt/runtime/protocol"
)

const runtimeName = "io.containerd.multikernel.v2"
const runtimeInfoInputLimit = 1 << 20
const fifoKeeperMode = "--multikernel-fifo-keeper"
const defaultAgentIOCallTimeout = 30 * time.Second

// A replacement worker can spend one complete agent I/O timeout proving that
// the inherited guest transport is stale before it replaces the relay. Keep
// the FIFO writer guard beyond that bounded recovery window so an existing
// containerd attach does not observe a transient EOF during reconstruction.
const fifoKeeperGrace = defaultAgentIOCallTimeout + 15*time.Second

var shimWorkerDisconnectGrace = 30 * time.Second

var runtimeIdentifier = regexp.MustCompile(`^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$`)
var guestProcessIdentifier = regexp.MustCompile(`^[a-z0-9][a-z0-9-]{0,63}$`)
var recoveryGeneration = regexp.MustCompile(`^[0-9a-f]{32}$`)
var recoverySHA256 = regexp.MustCompile(`^[0-9a-f]{64}$`)
var capabilityName = regexp.MustCompile(`^[a-z0-9][a-z0-9-]{0,127}$`)

var requiredAgentProtocolFeatures = []string{"signal-operation-id-v1", "stdin-offset-v1", "two-phase-shutdown-v1"}
var requiredAgentOCIFeatures = []string{
	"argv", "attach", "cwd", "environment", "exit-code", "hostname", "linux-capabilities",
	"masked-paths", "no-new-privileges", "readonly-bind-inputs-v1", "readonly-paths", "readonly-root",
	"rlimits", "split-stdio", "standard-mounts", "stdin", "terminal", "terminal-resize",
}

type guestCapabilities struct {
	Protocol         int            `json:"protocol"`
	ProtocolFeatures []string       `json:"protocol_features"`
	OCIFeatures      []string       `json:"oci_features"`
	Kernel           map[string]any `json:"kernel"`
	Agent            map[string]any `json:"agent"`
}

func requireCapabilitySet(observed, required []string, name string) error {
	if len(observed) > 128 {
		return fmt.Errorf("guest %s capability set exceeds its bound", name)
	}
	available := make(map[string]struct{}, len(observed))
	for _, feature := range observed {
		if !capabilityName.MatchString(feature) {
			return fmt.Errorf("guest %s capability set contains an invalid feature", name)
		}
		if _, duplicate := available[feature]; duplicate {
			return fmt.Errorf("guest %s capability set contains duplicate %q", name, feature)
		}
		available[feature] = struct{}{}
	}
	for _, feature := range required {
		if _, ok := available[feature]; !ok {
			return fmt.Errorf("guest does not advertise required %s capability %q", name, feature)
		}
	}
	return nil
}

type process struct {
	id, stdin, stdout, stderr      string
	stdinIdentity                  processIOIdentity
	stdoutIdentity                 processIOIdentity
	stderrIdentity                 processIOIdentity
	terminal                       bool
	width, height                  uint32
	sizeSet                        bool
	status                         tasktypes.Status
	pid                            uint32
	exit                           uint32
	exited                         time.Time
	done                           chan struct{}
	stdinReader                    io.ReadWriteCloser
	stdoutWriter, stderrWriter     io.WriteCloser
	stdoutGuard, stderrGuard       io.Closer
	stdinClosed, stdinCloseAcked   bool
	stdinOffset                    uint64
	stdinPending                   []byte
	stdoutOffset, stderrOffset     uint64
	stdoutPressure, stderrPressure time.Time
	exitEventQueued                bool
	deleteEventQueued              bool
	deleting                       bool
	pendingSignal                  uint32
	pendingSignalOperation         string
	pendingSignalAcknowledgement   bool
}

const processOutputChunk = 4096

type processOutput struct {
	Stdout          []byte `json:"stdout"`
	Stderr          []byte `json:"stderr"`
	StdoutOffset    uint64 `json:"stdout_offset"`
	StderrOffset    uint64 `json:"stderr_offset"`
	Status          string `json:"status"`
	StdoutTruncated bool   `json:"stdout_truncated"`
	StderrTruncated bool   `json:"stderr_truncated"`
}

type guestQuiesceResponse struct {
	Status string `json:"status"`
}

type agentClient interface {
	Call(string, any, any) error
	CallContext(context.Context, string, any, any) error
	Close() error
	Reconnect(string) error
	ReconnectContext(context.Context, string) error
}

type networkClient interface {
	Call(context.Context, mknetwork.Request) (mknetwork.Response, error)
	Attach(context.Context, mknetwork.Request) (mknetwork.Response, *os.File, error)
}

type agentDialer func(context.Context, string, string, string, uint32, []byte) (agentClient, error)
type relayFactory func(uint32, string) *exec.Cmd
type relayPathFactory func(uint32, string) string
type relayPathOwner interface{ Remove() error }
type relayOwnerFactory func(string) (relayPathOwner, error)
type namespaceHolder interface {
	PID() uint32
	Validate(string) error
	Stop() error
}
type namespaceHolderFactory func(string) (namespaceHolder, error)
type startShimSocket interface {
	shimSocketFile
	Close() error
}
type startShimSocketOwner interface {
	DialContext(context.Context) (net.Conn, error)
	Remove() error
	Close() error
}
type startShimSocketFactory func(string) (startShimSocket, error)
type startShimSocketOwnerFactory func(string) (startShimSocketOwner, error)

type stateFileIdentity struct {
	device uint64
	inode  uint64
	uid    uint32
	mode   uint32
	links  uint64
}

type service struct {
	mu                    sync.Mutex
	relayMu               sync.Mutex
	eventMu               sync.Mutex
	runtimeMu             sync.Mutex
	eventRetryStop        sync.Once
	bundleClose           sync.Once
	id, namespace, bundle string
	bundleDirectory       *safefile.Directory
	bundleIdentity        rootfspkg.DirectoryIdentity
	runtimeDirectory      *safefile.Directory
	publisher             shim.Publisher
	shutdown              func()
	daemon                daemon.Caller
	sandbox               protocol.Sandbox
	token                 []byte
	agent                 agentClient
	relay                 *exec.Cmd
	relaySocket           string
	relayOwner            relayPathOwner
	relayGeneration       uint64
	netDevice             *os.File
	netDone               chan struct{}
	netReports            chan string
	netWG                 sync.WaitGroup
	netEndpoint           mknetwork.Endpoint
	namespaceHolder       namespaceHolder
	netClient             networkClient
	newNamespaceHolder    namespaceHolderFactory
	agentDial             agentDialer
	newRelay              relayFactory
	relayPath             relayPathFactory
	newRelayOwner         relayOwnerFactory
	newShimSocketOwner    relayOwnerFactory
	shimArguments         []string
	ioCallTimeout         time.Duration
	networkCloseTimeout   time.Duration
	netRXPackets          atomic.Uint64
	netTXPackets          atomic.Uint64
	netRXDrops            atomic.Uint64
	netTXDrops            atomic.Uint64
	netErrors             atomic.Uint64
	processes             map[string]*process
	events                eventJournal
	eventJournalIdentity  *safefile.Identity
	recoveryIdentity      *safefile.Identity
	eventRetryCancel      context.CancelFunc
	eventRetryDone        chan struct{}
	shuttingDown          bool
}

const namespaceHolderMode = "__multikernel_namespace_holder"

type commandNamespaceHolder struct{ command *exec.Cmd }

func (h *commandNamespaceHolder) PID() uint32 {
	if h == nil || h.command == nil || h.command.Process == nil {
		return 0
	}
	return uint32(h.command.Process.Pid)
}

func (h *commandNamespaceHolder) Validate(netns string) error {
	pid := h.PID()
	if pid == 0 {
		return errors.New("network namespace holder has no process identity")
	}
	target, err := os.Stat(netns)
	if err != nil {
		return err
	}
	held, err := os.Stat("/proc/" + strconv.Itoa(int(pid)) + "/ns/net")
	if err != nil {
		return err
	}
	if !os.SameFile(target, held) {
		return errors.New("network namespace holder entered a different namespace")
	}
	return nil
}

func (h *commandNamespaceHolder) Stop() error {
	if h == nil || h.command == nil || h.command.Process == nil {
		return nil
	}
	err := h.command.Process.Kill()
	if err != nil && !errors.Is(err, os.ErrProcessDone) && !errors.Is(err, syscall.ESRCH) {
		return err
	}
	waitErr := h.command.Wait()
	var exitErr *exec.ExitError
	if waitErr == nil || errors.As(waitErr, &exitErr) || errors.Is(waitErr, syscall.ECHILD) {
		return nil
	}
	return waitErr
}

func startNamespaceHolder(netns string) (_ namespaceHolder, retErr error) {
	if !filepath.IsAbs(netns) || filepath.Clean(netns) != netns {
		return nil, errors.New("network namespace holder requires an absolute canonical path")
	}
	self, err := os.Executable()
	if err != nil {
		return nil, err
	}
	reader, writer, err := os.Pipe()
	if err != nil {
		return nil, err
	}
	defer reader.Close()
	// Enter the namespace before execing the Go helper. setns(2) is
	// thread-scoped, so calling it after the Go runtime has created threads can
	// leave /proc/PID/ns/net pointing at the original namespace.
	command := exec.Command("/usr/bin/nsenter", "--net="+netns, "--", self, namespaceHolderMode)
	command.ExtraFiles = []*os.File{writer}
	command.Stderr = os.Stderr
	command.SysProcAttr = &syscall.SysProcAttr{Pdeathsig: syscall.SIGKILL}
	if err = command.Start(); err != nil {
		writer.Close()
		return nil, err
	}
	holder := &commandNamespaceHolder{command: command}
	defer func() {
		_ = writer.Close()
		if retErr != nil {
			_ = holder.Stop()
		}
	}()
	if err = writer.Close(); err != nil {
		return nil, err
	}
	poll := []unix.PollFd{{Fd: int32(reader.Fd()), Events: unix.POLLIN | unix.POLLHUP}}
	ready, err := unix.Poll(poll, 5000)
	if err != nil {
		return nil, err
	}
	if ready != 1 || poll[0].Revents&unix.POLLIN == 0 {
		return nil, errors.New("network namespace holder did not become ready")
	}
	var status [1]byte
	if _, err = io.ReadFull(reader, status[:]); err != nil || status[0] != 1 {
		return nil, errors.Join(errors.New("network namespace holder rejected its target"), err)
	}
	if err = holder.Validate(netns); err != nil {
		return nil, err
	}
	return holder, nil
}

func runNamespaceHolder() int {
	ready := os.NewFile(3, "namespace-holder-ready")
	if ready == nil {
		return 1
	}
	if _, err := ready.Write([]byte{1}); err != nil {
		ready.Close()
		return 1
	}
	if err := ready.Close(); err != nil {
		return 1
	}
	for {
		_ = unix.Pause()
	}
}

const (
	rootfsPrepareDaemonTimeout = 11 * time.Minute
	createSandboxDaemonTimeout = 61 * time.Minute
)

func daemonCallerWithTimeout(caller daemon.Caller, timeout time.Duration) daemon.Caller {
	client, ok := caller.(daemon.Client)
	if !ok {
		return caller
	}
	client.Timeout = timeout
	return client
}

func getenv(name, fallback string) string {
	if v := os.Getenv(name); v != "" {
		return v
	}
	return fallback
}

func waitContext(ctx context.Context, delay time.Duration) error {
	timer := time.NewTimer(delay)
	defer timer.Stop()
	select {
	case <-ctx.Done():
		return ctx.Err()
	case <-timer.C:
		return nil
	}
}

func lockContext(ctx context.Context, mutex *sync.Mutex) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	for !mutex.TryLock() {
		timer := time.NewTimer(time.Millisecond)
		select {
		case <-ctx.Done():
			if !timer.Stop() {
				select {
				case <-timer.C:
				default:
				}
			}
			return ctx.Err()
		case <-timer.C:
		}
	}
	if err := ctx.Err(); err != nil {
		mutex.Unlock()
		return err
	}
	return nil
}

func newService(ctx context.Context, id string, publisher shim.Publisher, shutdown func()) (shim.Shim, error) {
	ns, err := namespaces.NamespaceRequired(ctx)
	if err != nil {
		return nil, err
	}
	bundle, err := os.Getwd()
	if err != nil {
		return nil, err
	}
	bundleDirectory, bundleIdentity, err := openServiceIdentity(id, ns, bundle)
	if err != nil {
		return nil, err
	}
	s := &service{id: id, namespace: ns, bundle: bundle, publisher: publisher, shutdown: shutdown,
		bundleDirectory: bundleDirectory, bundleIdentity: bundleIdentity,
		daemon:    daemon.Client{Path: getenv("MK_DAEMON_SOCKET", "/run/mkruntimed.sock")},
		netClient: mknetwork.Client{Path: getenv("MK_NETWORK_SOCKET", "/run/mknetd.sock")}, processes: map[string]*process{},
		events: eventJournal{SchemaVersion: 1, NextSequence: 1}}
	if !deleteInvocation(os.Args[1:]) {
		if err = s.loadEventJournal(); err != nil {
			_ = bundleDirectory.Close()
			return nil, err
		}
		if err = s.recoverExisting(ctx); err != nil {
			_ = bundleDirectory.Close()
			return nil, err
		}
		if err = s.flushEvents(ctx); err != nil {
			fmt.Fprintf(os.Stderr, "multikernel event replay deferred: %v\n", err)
		}
		s.startEventRetry(time.Second)
	}
	return s, nil
}

func deleteInvocation(arguments []string) bool {
	valueFlags := map[string]bool{
		"-address": true, "-bundle": true, "-id": true, "-namespace": true,
		"-publish-binary": true, "-socket": true,
	}
	for index := 0; index < len(arguments); index++ {
		argument := arguments[index]
		if valueFlags[argument] {
			index++
			if index >= len(arguments) {
				return false
			}
			continue
		}
		if argument == "-debug" || strings.HasPrefix(argument, "-debug=") {
			continue
		}
		matchedValueFlag := false
		for name := range valueFlags {
			if strings.HasPrefix(argument, name+"=") {
				matchedValueFlag = true
				break
			}
		}
		if matchedValueFlag {
			continue
		}
		return argument == "delete" && index == len(arguments)-1
	}
	return false
}

func (s *service) dialAgent(ctx context.Context, path string) (agentClient, error) {
	if s.agentDial != nil {
		return s.agentDial(ctx, path, s.sandbox.ID, s.sandbox.Generation, s.sandbox.Config.AgentPort, s.token)
	}
	return agent.DialContext(ctx, path, s.sandbox.ID, s.sandbox.Generation, s.sandbox.Config.AgentPort, s.token)
}

func (s *service) negotiateAgentCapabilities(ctx context.Context) error {
	var capabilities guestCapabilities
	if err := s.callAgentWithReconnectContext(ctx, "Capabilities", map[string]any{}, &capabilities); err != nil {
		return fmt.Errorf("query guest capabilities: %w", err)
	}
	if capabilities.Protocol != 1 || capabilities.Kernel == nil || capabilities.Agent == nil {
		return errors.New("guest capabilities omit the required protocol or runtime identity")
	}
	if err := requireCapabilitySet(capabilities.ProtocolFeatures, requiredAgentProtocolFeatures, "protocol"); err != nil {
		return err
	}
	if err := requireCapabilitySet(capabilities.OCIFeatures, requiredAgentOCIFeatures, "OCI"); err != nil {
		return err
	}
	return nil
}

func (s *service) relayCommand(port uint32, socket string) *exec.Cmd {
	if s.newRelay != nil {
		return s.newRelay(port, socket)
	}
	return newRelayCommand(getenv("MK_RELAY", "/opt/mkruntime/bin/mkvsock-relay"), port, socket)
}

func (s *service) agentRelaySocketPath(port uint32, generation string) string {
	if s.relayPath != nil {
		return s.relayPath(port, generation)
	}
	return relaySocketPath(port, generation)
}

func (s *service) captureRelaySocket(path string) (relayPathOwner, error) {
	if s.newRelayOwner != nil {
		return s.newRelayOwner(path)
	}
	return unixsocket.Capture(path)
}

func (s *service) acquireRelaySocketOwner(path string) error {
	owner, err := s.captureRelaySocket(path)
	if err != nil {
		return err
	}
	if owner == nil {
		return errors.New("relay socket capture returned no owner")
	}
	s.relayOwner = owner
	return nil
}

func validateServiceIdentity(id, namespace, bundle string) error {
	directory, _, err := openServiceIdentity(id, namespace, bundle)
	if directory != nil {
		_ = directory.Close()
	}
	return err
}

func openServiceIdentity(id, namespace, bundle string) (*safefile.Directory, rootfspkg.DirectoryIdentity, error) {
	if !runtimeIdentifier.MatchString(id) || !runtimeIdentifier.MatchString(namespace) {
		return nil, rootfspkg.DirectoryIdentity{}, fmt.Errorf("%w: invalid task ID or containerd namespace", errdefs.ErrInvalidArgument)
	}
	if !filepath.IsAbs(bundle) || filepath.Clean(bundle) != bundle {
		return nil, rootfspkg.DirectoryIdentity{}, fmt.Errorf("%w: bundle must be an absolute canonical path", errdefs.ErrInvalidArgument)
	}
	directory, err := safefile.OpenOwnedDirectory(bundle)
	if err != nil {
		return nil, rootfspkg.DirectoryIdentity{}, fmt.Errorf("%w: open bundle identity: %v", errdefs.ErrInvalidArgument, err)
	}
	identity := directory.Identity()
	observed := rootfspkg.DirectoryIdentity{Device: identity.Device, Inode: identity.Inode, UID: identity.UID}
	expected, err := supervisorBundleIdentity()
	if err != nil || expected != nil && *expected != observed {
		_ = directory.Close()
		return nil, rootfspkg.DirectoryIdentity{}, errors.Join(errors.New("bundle identity differs from the supervisor handoff"), err)
	}
	return directory, observed, nil
}

func supervisorBundleIdentity() (*rootfspkg.DirectoryIdentity, error) {
	raw := []string{os.Getenv("MK_SHIM_BUNDLE_DEVICE"), os.Getenv("MK_SHIM_BUNDLE_INODE"), os.Getenv("MK_SHIM_BUNDLE_UID")}
	if raw[0] == "" && raw[1] == "" && raw[2] == "" {
		return nil, nil
	}
	if raw[0] == "" || raw[1] == "" || raw[2] == "" {
		return nil, errors.New("supervisor bundle identity is incomplete")
	}
	device, err := strconv.ParseUint(raw[0], 10, 64)
	if err != nil {
		return nil, err
	}
	inode, err := strconv.ParseUint(raw[1], 10, 64)
	if err != nil {
		return nil, err
	}
	uid, err := strconv.ParseUint(raw[2], 10, 32)
	if err != nil || device == 0 || inode == 0 {
		return nil, errors.Join(errors.New("supervisor bundle identity is invalid"), err)
	}
	identity := &rootfspkg.DirectoryIdentity{Device: device, Inode: inode, UID: uint32(uid)}
	return identity, nil
}

func newCommand(ctx context.Context, id string, opts shim.StartOpts) (*exec.Cmd, error) {
	self, err := os.Executable()
	if err != nil {
		return nil, err
	}
	ns, err := namespaces.NamespaceRequired(ctx)
	if err != nil {
		return nil, err
	}
	cmd := exec.Command(self, "-namespace", ns, "-id", id, "-address", opts.Address)
	cmd.Env = append(os.Environ(), "GOMAXPROCS=2")
	cmd.SysProcAttr = &syscall.SysProcAttr{Setpgid: true}
	return cmd, nil
}

func bindCommandToBundle(cmd *exec.Cmd, directory *safefile.Directory) error {
	if cmd == nil || directory == nil {
		return errors.New("supervisor command or held bundle directory is unavailable")
	}
	cmd.Dir = directory.ProcPath()
	return nil
}

type shimSocketFile interface {
	File() (*os.File, error)
}

type publishedShimFile struct {
	directory *safefile.Directory
	name      string
	identity  safefile.Identity
}

func publishShimFile(path string, data []byte) (*publishedShimFile, error) {
	absolute, err := filepath.Abs(path)
	if err != nil {
		return nil, err
	}
	if filepath.Clean(absolute) != absolute || filepath.Base(absolute) == "." {
		return nil, errors.New("published shim file path must be canonical and absolute")
	}
	directory, err := safefile.OpenOwnedDirectory(filepath.Dir(absolute))
	if err != nil {
		return nil, err
	}
	name := filepath.Base(absolute)
	created, identity, err := directory.PublishExclusiveRegularIdentity(name, data, 0644)
	owner := &publishedShimFile{directory: directory, name: name, identity: identity}
	if err != nil {
		if created {
			return nil, errors.Join(err, owner.close(true))
		}
		return nil, errors.Join(err, directory.Close())
	}
	if !created {
		return nil, errors.Join(errors.New("published shim file already exists"), directory.Close())
	}
	return owner, nil
}

func (p *publishedShimFile) close(remove bool) error {
	if p == nil {
		return nil
	}
	var removeErr error
	if remove {
		_, removeErr = p.directory.RemoveIfIdentity(p.name, p.identity)
	}
	return errors.Join(removeErr, p.directory.Close())
}

func launchShimWorker(ctx context.Context, cmd *exec.Cmd, socket shimSocketFile, address, addressPath, pidPath string) (retErr error) {
	if err := ctx.Err(); err != nil {
		return err
	}
	var addressFile, pidFile *publishedShimFile
	started := false
	var inherited *os.File
	defer func() {
		var failures []error
		if retErr != nil && inherited != nil {
			failures = append(failures, inherited.Close())
		}
		if retErr != nil && started {
			failures = append(failures, terminateRelay(cmd))
		}
		if err := pidFile.close(retErr != nil); err != nil {
			failures = append(failures, fmt.Errorf("close partial shim PID ownership: %w", err))
		}
		if err := addressFile.close(retErr != nil); err != nil {
			failures = append(failures, fmt.Errorf("close partial shim address ownership: %w", err))
		}
		retErr = errors.Join(retErr, errors.Join(failures...))
	}()
	addressFile, retErr = publishShimFile(addressPath, []byte(address))
	if retErr != nil {
		return retErr
	}
	if err := ctx.Err(); err != nil {
		return err
	}
	var err error
	inherited, err = socket.File()
	if err != nil {
		return err
	}
	cmd.ExtraFiles = []*os.File{inherited}
	if err = ctx.Err(); err != nil {
		return err
	}
	if err = cmd.Start(); err != nil {
		return err
	}
	started = true
	if err = inherited.Close(); err != nil {
		inherited = nil
		return fmt.Errorf("close inherited shim socket: %w", err)
	}
	inherited = nil
	if err = ctx.Err(); err != nil {
		return err
	}
	pidFile, retErr = publishShimFile(pidPath, []byte(strconv.Itoa(cmd.Process.Pid)))
	if retErr != nil {
		return retErr
	}
	if err = ctx.Err(); err != nil {
		return err
	}
	go func() { _ = cmd.Wait() }()
	return nil
}

func (s *service) StartShim(ctx context.Context, opts shim.StartOpts) (_ string, retErr error) {
	if err := ctx.Err(); err != nil {
		return "", err
	}
	cmd, err := newCommand(ctx, opts.ID, opts)
	if err != nil {
		return "", err
	}
	if err = bindCommandToBundle(cmd, s.bundleDirectory); err != nil {
		return "", err
	}
	address, err := shim.SocketAddress(ctx, opts.Address, opts.ID)
	if err != nil {
		return "", err
	}
	socket, existing, err := acquireStartShimSocket(ctx, address,
		func(address string) (startShimSocket, error) {
			path, pathErr := pathnameShimSocket(address)
			if pathErr != nil {
				return nil, pathErr
			}
			if pathErr = unixsocket.EnsureParent(path); pathErr != nil {
				return nil, pathErr
			}
			return unixsocket.ListenExclusive(path, 0600)
		},
		func(path string) (startShimSocketOwner, error) { return unixsocket.Capture(path) },
	)
	if err != nil {
		return "", err
	}
	if existing {
		if err = s.authenticateExistingShim(address, opts); err != nil {
			return "", err
		}
		return address, nil
	}
	defer func() {
		if retErr != nil {
			retErr = errors.Join(retErr, socket.Close())
		}
	}()
	if err = launchShimWorker(ctx, cmd, socket, address, "address", "shim.pid"); err != nil {
		return "", err
	}
	return address, nil
}

func pathnameShimSocket(address string) (string, error) {
	const unixPrefix = "unix://"
	if !strings.HasPrefix(address, unixPrefix) {
		return "", errors.New("deterministic shim address is not a pathname Unix socket")
	}
	path := strings.TrimPrefix(address, unixPrefix)
	if !filepath.IsAbs(path) || filepath.Clean(path) != path {
		return "", errors.New("deterministic shim socket path is not canonical and absolute")
	}
	return path, nil
}

func acquireStartShimSocket(ctx context.Context, address string, create startShimSocketFactory, capture startShimSocketOwnerFactory) (startShimSocket, bool, error) {
	if err := ctx.Err(); err != nil {
		return nil, false, err
	}
	socket, err := create(address)
	if err == nil {
		return socket, false, nil
	}
	if !shim.SocketEaddrinuse(err) {
		return nil, false, err
	}
	path, err := pathnameShimSocket(address)
	if err != nil {
		return nil, false, err
	}
	owner, err := capture(path)
	if err != nil {
		return nil, false, fmt.Errorf("capture pre-existing shim socket: %w", err)
	}
	connection, dialErr := owner.DialContext(ctx)
	if dialErr == nil {
		return nil, true, errors.Join(connection.Close(), owner.Close())
	}
	if err = ctx.Err(); err != nil {
		return nil, false, errors.Join(err, owner.Close())
	}
	if !errors.Is(dialErr, syscall.ECONNREFUSED) {
		return nil, false, errors.Join(fmt.Errorf("probe pre-existing shim socket: %w", dialErr), owner.Close())
	}
	if err = owner.Remove(); err != nil {
		_ = owner.Close()
		return nil, false, errors.Join(fmt.Errorf("remove stale shim socket: %w", err), dialErr)
	}
	if err = ctx.Err(); err != nil {
		return nil, false, err
	}
	socket, err = create(address)
	if err != nil {
		return nil, false, fmt.Errorf("bind shim socket after stale cleanup: %w", err)
	}
	return socket, false, nil
}

func readProcEntry(directory *os.File, name string, limit int64) ([]byte, error) {
	fd, err := unix.Openat(int(directory.Fd()), name, unix.O_RDONLY|unix.O_CLOEXEC|unix.O_NOFOLLOW, 0)
	if err != nil {
		return nil, err
	}
	file := os.NewFile(uintptr(fd), name)
	defer file.Close()
	data, err := io.ReadAll(io.LimitReader(file, limit+1))
	if err != nil {
		return nil, err
	}
	if int64(len(data)) > limit {
		return nil, errors.New("process metadata exceeds its bound")
	}
	return data, nil
}

func openedIdentity(file *os.File) (rootfspkg.DirectoryIdentity, error) {
	var stat unix.Stat_t
	if err := unix.Fstat(int(file.Fd()), &stat); err != nil {
		return rootfspkg.DirectoryIdentity{}, err
	}
	return rootfspkg.DirectoryIdentity{Device: uint64(stat.Dev), Inode: stat.Ino, UID: stat.Uid}, nil
}

func openProcLink(directory *os.File, name string, directoryOnly bool) (*os.File, rootfspkg.DirectoryIdentity, error) {
	flags := unix.O_PATH | unix.O_CLOEXEC
	if directoryOnly {
		flags |= unix.O_DIRECTORY
	}
	fd, err := unix.Openat(int(directory.Fd()), name, flags, 0)
	if err != nil {
		return nil, rootfspkg.DirectoryIdentity{}, err
	}
	file := os.NewFile(uintptr(fd), name)
	identity, err := openedIdentity(file)
	if err != nil {
		_ = file.Close()
		return nil, rootfspkg.DirectoryIdentity{}, err
	}
	return file, identity, nil
}

func processGroupFromStat(data []byte) (int, error) {
	close := bytes.LastIndex(data, []byte(") "))
	if close < 0 {
		return 0, errors.New("supervisor process stat is malformed")
	}
	fields := strings.Fields(string(data[close+2:]))
	if len(fields) < 3 || fields[0] == "Z" || fields[0] == "X" {
		return 0, errors.New("supervisor process is not live")
	}
	group, err := strconv.Atoi(fields[2])
	if err != nil || group <= 1 {
		return 0, errors.Join(errors.New("supervisor process group is invalid"), err)
	}
	return group, nil
}

func commandLineArguments(data []byte) ([]string, error) {
	if len(data) == 0 || data[len(data)-1] != 0 {
		return nil, errors.New("supervisor command line is empty or unterminated")
	}
	parts := bytes.Split(data[:len(data)-1], []byte{0})
	arguments := make([]string, len(parts))
	for index, part := range parts {
		if len(part) == 0 {
			return nil, errors.New("supervisor command line contains an empty argument")
		}
		arguments[index] = string(part)
	}
	return arguments, nil
}

func (s *service) authenticateExistingShim(address string, opts shim.StartOpts) error {
	if s.bundleDirectory == nil {
		return errors.New("held bundle directory is unavailable for existing shim authentication")
	}
	publishedAddress, _, err := s.bundleDirectory.ReadRegularIdentity("address", 0644, 4096)
	if err != nil || string(publishedAddress) != address {
		return errors.Join(errors.New("existing shim address metadata does not match"), err)
	}
	pidBytes, _, err := s.bundleDirectory.ReadRegularIdentity("shim.pid", 0644, 64)
	if err != nil {
		return fmt.Errorf("read existing shim PID metadata: %w", err)
	}
	if len(pidBytes) == 0 || bytes.IndexFunc(pidBytes, func(r rune) bool { return r < '0' || r > '9' }) >= 0 {
		return errors.New("existing shim PID metadata is invalid")
	}
	pid64, err := strconv.ParseInt(string(pidBytes), 10, 32)
	if err != nil || pid64 <= 1 {
		return errors.Join(errors.New("existing shim PID metadata is invalid"), err)
	}
	pid := int(pid64)
	procFD, err := unix.Open(filepath.Join("/proc", strconv.Itoa(pid)), unix.O_RDONLY|unix.O_DIRECTORY|unix.O_CLOEXEC, 0)
	if err != nil {
		return fmt.Errorf("open existing shim process identity: %w", err)
	}
	processDirectory := os.NewFile(uintptr(procFD), "shim-process")
	defer processDirectory.Close()
	cwd, cwdIdentity, err := openProcLink(processDirectory, "cwd", true)
	if err != nil {
		return fmt.Errorf("open existing shim cwd: %w", err)
	}
	defer cwd.Close()
	if cwdIdentity != s.bundleIdentity {
		return errors.New("existing shim cwd differs from the held bundle")
	}
	shimExecutable, shimExecutableIdentity, err := openProcLink(processDirectory, "exe", false)
	if err != nil {
		return fmt.Errorf("open existing shim executable: %w", err)
	}
	defer shimExecutable.Close()
	selfFD, err := unix.Open("/proc/self/exe", unix.O_PATH|unix.O_CLOEXEC, 0)
	if err != nil {
		return err
	}
	selfExecutable := os.NewFile(uintptr(selfFD), "self-executable")
	defer selfExecutable.Close()
	selfIdentity, err := openedIdentity(selfExecutable)
	if err != nil || shimExecutableIdentity.Device != selfIdentity.Device || shimExecutableIdentity.Inode != selfIdentity.Inode {
		return errors.Join(errors.New("existing shim executable identity differs"), err)
	}
	statBytes, err := readProcEntry(processDirectory, "stat", 4096)
	if err != nil {
		return fmt.Errorf("read existing shim process stat: %w", err)
	}
	group, err := processGroupFromStat(statBytes)
	if err != nil || group != pid {
		return errors.Join(errors.New("existing shim is not its process-group leader"), err)
	}
	commandLine, err := readProcEntry(processDirectory, "cmdline", 16<<10)
	if err != nil {
		return fmt.Errorf("read existing shim command line: %w", err)
	}
	arguments, err := commandLineArguments(commandLine)
	if err != nil {
		return err
	}
	for name, expected := range map[string]string{"namespace": s.namespace, "id": s.id, "address": opts.Address} {
		observed, flagErr := invocationFlagValue(arguments, name)
		if flagErr != nil || observed != expected {
			return errors.Join(fmt.Errorf("existing shim %s invocation differs", name), flagErr)
		}
	}
	return nil
}

type persisted struct {
	SchemaVersion  int                         `json:"schema_version"`
	BundleIdentity rootfspkg.DirectoryIdentity `json:"bundle_identity"`
	ID             string                      `json:"id"`
	Generation     string                      `json:"generation"`
	PID            uint32                      `json:"pid,omitempty"`
	Exit           uint32                      `json:"exit"`
	Exited         time.Time                   `json:"exited"`
	Network        mknetwork.Endpoint          `json:"network"`
	TaskIdentity   string                      `json:"task_identity"`
	StorageSHA256  string                      `json:"storage_sha256"`
	Processes      []persistedProcess          `json:"processes,omitempty"`
}

type persistedProcess struct {
	ID                string            `json:"id"`
	Stdin             string            `json:"stdin,omitempty"`
	Stdout            string            `json:"stdout,omitempty"`
	Stderr            string            `json:"stderr,omitempty"`
	StdinIdentity     processIOIdentity `json:"stdin_identity,omitempty"`
	StdoutIdentity    processIOIdentity `json:"stdout_identity,omitempty"`
	StderrIdentity    processIOIdentity `json:"stderr_identity,omitempty"`
	Terminal          bool              `json:"terminal,omitempty"`
	Width             uint32            `json:"width,omitempty"`
	Height            uint32            `json:"height,omitempty"`
	SizeSet           bool              `json:"size_set,omitempty"`
	StdinClosed       bool              `json:"stdin_closed,omitempty"`
	StdinCloseAcked   bool              `json:"stdin_close_acked,omitempty"`
	StdinOffset       uint64            `json:"stdin_offset,omitempty"`
	StdinPending      []byte            `json:"stdin_pending,omitempty"`
	Status            tasktypes.Status  `json:"status"`
	PID               uint32            `json:"pid,omitempty"`
	Exit              uint32            `json:"exit,omitempty"`
	Exited            time.Time         `json:"exited,omitempty"`
	StdoutOffset      uint64            `json:"stdout_offset,omitempty"`
	StderrOffset      uint64            `json:"stderr_offset,omitempty"`
	ExitEventQueued   bool              `json:"exit_event_queued,omitempty"`
	DeleteEventQueued bool              `json:"delete_event_queued,omitempty"`
	PendingSignal     uint32            `json:"pending_signal,omitempty"`
	PendingSignalOp   string            `json:"pending_signal_operation,omitempty"`
	PendingSignalAck  bool              `json:"pending_signal_acknowledgement,omitempty"`
}

type processIOIdentity struct {
	Device uint64 `json:"device"`
	Inode  uint64 `json:"inode"`
	UID    uint32 `json:"uid"`
	GID    uint32 `json:"gid"`
	Mode   uint32 `json:"mode"`
	Links  uint64 `json:"links"`
}

func processIOIdentityFromInfo(info os.FileInfo) (processIOIdentity, bool) {
	value, ok := info.Sys().(*syscall.Stat_t)
	if !ok {
		return processIOIdentity{}, false
	}
	return processIOIdentity{Device: uint64(value.Dev), Inode: value.Ino, UID: value.Uid,
		GID: value.Gid, Mode: value.Mode, Links: value.Nlink}, true
}

func validProcessIOIdentity(path string, value processIOIdentity, stdin bool) bool {
	if path == "" {
		return value == (processIOIdentity{})
	}
	typeBits := value.Mode & unix.S_IFMT
	typeOK := typeBits == unix.S_IFIFO || !stdin && typeBits == unix.S_IFREG
	return value.Inode != 0 && value.UID == uint32(os.Geteuid()) && value.Links == 1 &&
		value.Mode&0077 == 0 && typeOK
}

func validatePersistedRecovery(value persisted, namespace, task string) error {
	if value.SchemaVersion != 3 || value.BundleIdentity.Device == 0 || value.BundleIdentity.Inode == 0 ||
		value.BundleIdentity.UID != uint32(os.Geteuid()) || value.ID != sandboxID(namespace, task) ||
		!recoveryGeneration.MatchString(value.Generation) ||
		value.TaskIdentity != storageTaskIdentity(namespace, task) ||
		(value.StorageSHA256 != "" && !recoverySHA256.MatchString(value.StorageSHA256)) ||
		len(value.Processes) == 0 || len(value.Processes) > 1024 {
		return errors.New("shim recovery identity or bounds are invalid")
	}
	networkIdentityPresent := value.Network.Generation != "" || value.Network.SandboxID != "" || value.Network.SandboxGeneration != ""
	if networkIdentityPresent {
		if value.Network.SandboxID != value.ID || value.Network.SandboxGeneration != value.Generation ||
			!recoveryGeneration.MatchString(value.Network.Generation) {
			return errors.New("shim recovery network ownership is invalid")
		}
		if err := mknetwork.ValidateEndpoint(value.Network); err != nil {
			return fmt.Errorf("shim recovery network endpoint is invalid: %w", err)
		}
	}
	seen := make(map[string]bool, len(value.Processes))
	initSeen := false
	for _, process := range value.Processes {
		if seen[process.ID] || (process.ID != "" && !guestProcessIdentifier.MatchString(process.ID)) {
			return errors.New("shim recovery contains an invalid or duplicate process identity")
		}
		seen[process.ID] = true
		if process.ID == "" {
			if initSeen {
				return errors.New("shim recovery contains multiple init processes")
			}
			initSeen = true
		}
		if process.Status != tasktypes.Status_CREATED && process.Status != tasktypes.Status_RUNNING &&
			process.Status != tasktypes.Status_PAUSED && process.Status != tasktypes.Status_STOPPED {
			return errors.New("shim recovery contains an invalid process state")
		}
		if process.PendingSignalOp == "" && (process.PendingSignal != 0 || process.PendingSignalAck) || process.PendingSignalOp != "" &&
			(!recoveryGeneration.MatchString(process.PendingSignalOp) || process.PendingSignal > 64 ||
				process.Status != tasktypes.Status_RUNNING && process.Status != tasktypes.Status_PAUSED &&
					!(process.PendingSignalAck && process.Status == tasktypes.Status_STOPPED)) {
			return errors.New("shim recovery contains an invalid pending signal")
		}
		if process.Width > 65535 || process.Height > 65535 || process.StdinCloseAcked &&
			(!process.StdinClosed || len(process.StdinPending) != 0) {
			return errors.New("shim recovery contains invalid terminal or stdin state")
		}
		if len(process.StdinPending) > 32<<10 || len(process.StdinPending) != 0 &&
			(process.Stdin == "" || process.Status != tasktypes.Status_RUNNING && process.Status != tasktypes.Status_PAUSED) {
			return errors.New("shim recovery contains invalid pending stdin")
		}
		if uint64(len(process.StdinPending)) > ^uint64(0)-process.StdinOffset {
			return errors.New("shim recovery pending stdin offset overflows")
		}
		if process.Stdin == "" && process.StdinOffset != 0 {
			return errors.New("shim recovery contains stdin offset without a stream")
		}
		for _, path := range []string{process.Stdin, process.Stdout, process.Stderr} {
			if path != "" && (!filepath.IsAbs(path) || filepath.Clean(path) != path || len(path) > 4096 || strings.ContainsRune(path, 0)) {
				return errors.New("shim recovery contains an invalid stdio path")
			}
		}
		if !validProcessIOIdentity(process.Stdin, process.StdinIdentity, true) ||
			!validProcessIOIdentity(process.Stdout, process.StdoutIdentity, false) ||
			!validProcessIOIdentity(process.Stderr, process.StderrIdentity, false) {
			return errors.New("shim recovery contains invalid stdio ownership")
		}
	}
	if !initSeen {
		return errors.New("shim recovery has no init process")
	}
	return nil
}

func loadPersistedRecovery(path, namespace, task string) (persisted, bool, error) {
	var value persisted
	info, err := os.Lstat(path)
	if errors.Is(err, os.ErrNotExist) {
		return value, false, nil
	}
	if err != nil {
		return value, false, err
	}
	identity, ok := info.Sys().(*syscall.Stat_t)
	if !ok || !info.Mode().IsRegular() || info.Mode().Perm()&0077 != 0 || identity.Uid != uint32(os.Geteuid()) ||
		identity.Nlink != 1 || info.Size() <= 0 || info.Size() > 8<<20 {
		return value, false, errors.New("shim recovery must be a private caller-owned bounded single-link regular file")
	}
	descriptor, err := unix.Openat2(unix.AT_FDCWD, path, &unix.OpenHow{
		Flags: uint64(unix.O_RDONLY | unix.O_CLOEXEC | unix.O_NOFOLLOW), Resolve: unix.RESOLVE_NO_SYMLINKS | unix.RESOLVE_NO_MAGICLINKS,
	})
	if err != nil {
		return value, false, err
	}
	file := os.NewFile(uintptr(descriptor), path)
	defer file.Close()
	opened, err := file.Stat()
	if err != nil || !sameProcessIOIdentity(info, opened) {
		return value, false, errors.New("shim recovery identity changed while opening")
	}
	data, err := io.ReadAll(io.LimitReader(file, (8<<20)+1))
	if err != nil || len(data) > 8<<20 {
		return value, false, errors.New("shim recovery changed or exceeded its read bound")
	}
	after, err := file.Stat()
	if err != nil || !sameProcessIOIdentity(opened, after) {
		return value, false, errors.New("shim recovery identity changed while reading")
	}
	if err = protocol.StrictDecode(data, &value); err != nil {
		return value, false, fmt.Errorf("decode shim recovery: %w", err)
	}
	if err = validatePersistedRecovery(value, namespace, task); err != nil {
		return value, false, err
	}
	return value, true, nil
}

func loadPersistedRecoveryFromDirectory(directory *safefile.Directory, namespace, task string) (persisted, bool, *safefile.Identity, error) {
	var value persisted
	data, present, identity, err := directory.ReadPrivateIdentity("sandbox.json", 8<<20)
	if err != nil || !present {
		return value, present, nil, err
	}
	if err = protocol.StrictDecode(data, &value); err != nil {
		return value, false, nil, fmt.Errorf("decode shim recovery: %w", err)
	}
	if err = validatePersistedRecovery(value, namespace, task); err != nil {
		return value, false, nil, err
	}
	return value, true, &identity, nil
}

func invocationFlagValue(arguments []string, name string) (string, error) {
	var value string
	for index := 0; index < len(arguments); index++ {
		argument := arguments[index]
		matched := false
		var candidate string
		for _, prefix := range []string{"-" + name, "--" + name} {
			if argument == prefix {
				if index+1 >= len(arguments) {
					return "", fmt.Errorf("%s flag has no value", name)
				}
				index++
				candidate, matched = arguments[index], true
				break
			}
			if strings.HasPrefix(argument, prefix+"=") {
				candidate, matched = strings.TrimPrefix(argument, prefix+"="), true
				break
			}
		}
		if !matched {
			continue
		}
		if candidate == "" || value != "" {
			return "", fmt.Errorf("%s flag is empty or duplicated", name)
		}
		value = candidate
	}
	if value == "" {
		return "", fmt.Errorf("%s flag is unavailable", name)
	}
	return value, nil
}

func (s *service) cleanupShimSocket(ctx context.Context, arguments []string) error {
	_, present, err := s.bundleDirectory.EntryIdentity("address")
	if err != nil || !present {
		return err
	}
	data, _, err := s.bundleDirectory.ReadRegularIdentity("address", 0644, 4096)
	if err != nil {
		return err
	}
	containerdAddress, err := invocationFlagValue(arguments, "address")
	if err != nil {
		return err
	}
	expected, err := shim.SocketAddress(namespaces.WithNamespace(ctx, s.namespace), containerdAddress, s.id)
	if err != nil {
		return err
	}
	if string(data) != expected {
		return errors.New("shim address file differs from the deterministic task socket")
	}
	path, err := pathnameShimSocket(expected)
	if err != nil {
		return err
	}
	var owner relayPathOwner
	if s.newShimSocketOwner != nil {
		owner, err = s.newShimSocketOwner(path)
	} else {
		owner, err = unixsocket.Capture(path)
	}
	if errors.Is(err, os.ErrNotExist) {
		return nil
	}
	if err != nil {
		return err
	}
	return owner.Remove()
}

func (s *service) cleanupInvocationArguments() []string {
	if s.shimArguments != nil {
		return s.shimArguments
	}
	return os.Args[1:]
}

func (s *service) Cleanup(ctx context.Context) (*taskapi.DeleteResponse, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	var failures []error
	runtimeDirectory, err := s.ensureRuntimeDirectory()
	if errors.Is(err, os.ErrNotExist) {
		if socketErr := s.cleanupShimSocket(ctx, s.cleanupInvocationArguments()); socketErr != nil {
			failures = append(failures, fmt.Errorf("authenticate and remove shim socket: %w", socketErr))
		}
		now := timestamppb.Now()
		return &taskapi.DeleteResponse{ExitedAt: now}, errors.Join(failures...)
	}
	if err != nil {
		return nil, fmt.Errorf("open shim cleanup ownership: %w", err)
	}
	p, found, _, err := loadPersistedRecoveryFromDirectory(runtimeDirectory, s.namespace, s.id)
	if err != nil {
		return nil, fmt.Errorf("load shim cleanup ownership: %w", err)
	}
	if !found {
		if socketErr := s.cleanupShimSocket(ctx, s.cleanupInvocationArguments()); socketErr != nil {
			failures = append(failures, fmt.Errorf("authenticate and remove shim socket: %w", socketErr))
		}
		now := timestamppb.Now()
		return &taskapi.DeleteResponse{ExitedAt: now}, errors.Join(failures...)
	}
	if p.BundleIdentity != s.bundleIdentity {
		return nil, errors.New("cleanup recovery bundle identity differs from the service handoff")
	}
	var sandboxes []protocol.Sandbox
	if apiErr := s.daemon.Call(ctx, protocol.Request{Version: 1, RequestID: "shim-cleanup-list-" + s.id, Method: "ListSandboxes"}, &sandboxes); apiErr != nil {
		return nil, fmt.Errorf("list sandboxes for shim cleanup: %s", apiErr.Message)
	}
	for _, sandbox := range sandboxes {
		if sandbox.ID != p.ID {
			continue
		}
		if sandbox.Generation != p.Generation || sandbox.Config.BundleIdentity != s.bundleIdentity {
			return nil, errors.New("daemon reports conflicting cleanup ownership for the held bundle identity")
		}
		break
	}
	if err = s.cleanupShimSocket(ctx, s.cleanupInvocationArguments()); err != nil {
		return nil, fmt.Errorf("authenticate and remove shim socket: %w", err)
	}
	s.netEndpoint = p.Network
	if err = s.stopNetwork(); err != nil {
		failures = append(failures, fmt.Errorf("stop recovered network: %w", err))
	}
	if err = s.stopRelay(); err != nil {
		failures = append(failures, fmt.Errorf("stop recovered relay: %w", err))
	}
	if err = s.releaseNetwork(ctx); err != nil {
		failures = append(failures, fmt.Errorf("release recovered network: %w", err))
	}
	if p.ID != "" {
		if _, stopErr := daemon.Mutation(ctx, s.daemon, "StopSandbox", p.ID, p.Generation, "cleanup-stop-"+p.Generation, nil); stopErr != nil && !daemonErrorCode(stopErr, "NOT_FOUND") {
			failures = append(failures, fmt.Errorf("stop recovered sandbox: %w", stopErr))
		} else if _, deleteErr := daemon.Mutation(ctx, s.daemon, "DeleteSandbox", p.ID, p.Generation, "cleanup-delete-"+p.Generation, nil); deleteErr != nil && !daemonErrorCode(deleteErr, "NOT_FOUND") {
			failures = append(failures, fmt.Errorf("delete recovered sandbox: %w", deleteErr))
		} else if p.StorageSHA256 != "" {
			if cleanupErr := s.cleanupRootfs(ctx, rootfspkg.CleanupRequest{Version: rootfspkg.Version, Bundle: s.bundle, BundleIdentity: p.BundleIdentity, TaskIdentity: p.TaskIdentity, StorageSHA256: p.StorageSHA256}); cleanupErr != nil {
				failures = append(failures, fmt.Errorf("cleanup recovered rootfs: %w", cleanupErr))
			}
		}
	}
	if p.Exited.IsZero() {
		p.Exited = time.Now().UTC()
	}
	return &taskapi.DeleteResponse{Pid: p.PID, ExitStatus: p.Exit, ExitedAt: timestamppb.New(p.Exited)}, errors.Join(failures...)
}

func randomToken() ([]byte, string, error) {
	b := make([]byte, 32)
	if _, err := io.ReadFull(rand.Reader, b); err != nil {
		return nil, "", err
	}
	return b, hex.EncodeToString(b), nil
}

func newSignalOperationID() (string, error) {
	b := make([]byte, 16)
	if _, err := io.ReadFull(rand.Reader, b); err != nil {
		return "", err
	}
	return hex.EncodeToString(b), nil
}

func loadExistingToken(runtimeDir string) ([]byte, string, error) {
	path := filepath.Join(runtimeDir, "token")
	info, err := os.Lstat(path)
	if err != nil {
		return nil, "", err
	}
	identity, ok := info.Sys().(*syscall.Stat_t)
	if !ok || !info.Mode().IsRegular() || info.Mode().Perm() != 0600 || info.Size() != 65 ||
		identity.Uid != uint32(os.Geteuid()) || identity.Nlink != 1 {
		return nil, "", errors.New("existing runtime token is unsafe")
	}
	descriptor, err := unix.Openat2(unix.AT_FDCWD, path, &unix.OpenHow{
		Flags: uint64(unix.O_RDONLY | unix.O_CLOEXEC | unix.O_NOFOLLOW), Resolve: unix.RESOLVE_NO_SYMLINKS | unix.RESOLVE_NO_MAGICLINKS,
	})
	if err != nil {
		return nil, "", err
	}
	file := os.NewFile(uintptr(descriptor), path)
	opened, statErr := file.Stat()
	if statErr != nil || !sameProcessIOIdentity(info, opened) {
		_ = file.Close()
		return nil, "", errors.New("runtime token identity changed while opening")
	}
	data, readErr := io.ReadAll(io.LimitReader(file, 66))
	after, afterErr := file.Stat()
	closeErr := file.Close()
	if err = errors.Join(readErr, afterErr, closeErr); err != nil {
		return nil, "", err
	}
	if !sameProcessIOIdentity(opened, after) {
		return nil, "", errors.New("runtime token identity changed while reading")
	}
	if len(data) != 65 || data[64] != '\n' {
		return nil, "", errors.New("existing runtime token is malformed")
	}
	token, err := hex.DecodeString(string(data[:64]))
	if err != nil || len(token) != 32 {
		return nil, "", errors.New("existing runtime token is malformed")
	}
	return token, string(data[:64]), nil
}

func loadExistingTokenFromDirectory(directory *safefile.Directory) ([]byte, string, error) {
	data, present, _, err := directory.ReadPrivateIdentity("token", 65)
	if err != nil {
		return nil, "", err
	}
	if !present {
		return nil, "", os.ErrNotExist
	}
	if len(data) != 65 || data[64] != '\n' {
		return nil, "", errors.New("existing runtime token is malformed")
	}
	token, err := hex.DecodeString(string(data[:64]))
	if err != nil || len(token) != 32 {
		return nil, "", errors.New("existing runtime token is malformed")
	}
	return token, string(data[:64]), nil
}

func loadOrCreateToken(runtimeDir string) (_ []byte, _ string, retErr error) {
	if token, encoded, err := loadExistingToken(runtimeDir); err == nil {
		return token, encoded, nil
	} else if !errors.Is(err, os.ErrNotExist) {
		return nil, "", err
	}
	token, encoded, err := randomToken()
	if err != nil {
		return nil, "", err
	}
	directory, err := openStateDirectory(runtimeDir)
	if err != nil {
		return nil, "", err
	}
	defer func() { retErr = errors.Join(retErr, directory.Close()) }()
	descriptor, err := unix.Openat(int(directory.Fd()), "token",
		unix.O_WRONLY|unix.O_CREAT|unix.O_EXCL|unix.O_CLOEXEC|unix.O_NOFOLLOW, 0600)
	if err != nil {
		return nil, "", err
	}
	file := os.NewFile(uintptr(descriptor), "token")
	createdInfo, err := file.Stat()
	if err != nil {
		_ = file.Close()
		return nil, "", err
	}
	createdIdentity, ok := createdInfo.Sys().(*syscall.Stat_t)
	if !ok {
		_ = file.Close()
		return nil, "", errors.New("created runtime token identity is unavailable")
	}
	remove := true
	defer func() {
		if remove {
			var current unix.Stat_t
			if err := unix.Fstatat(int(directory.Fd()), "token", &current, unix.AT_SYMLINK_NOFOLLOW); err == nil &&
				current.Dev == createdIdentity.Dev && current.Ino == createdIdentity.Ino {
				_ = unix.Unlinkat(int(directory.Fd()), "token", 0)
			}
		}
	}()
	written, err := file.WriteString(encoded + "\n")
	if err == nil && written != 65 {
		err = io.ErrShortWrite
	}
	if err == nil {
		err = file.Sync()
	}
	closeErr := file.Close()
	if err != nil {
		return nil, "", err
	}
	if closeErr != nil {
		return nil, "", closeErr
	}
	err = directory.Sync()
	if err != nil {
		return nil, "", err
	}
	remove = false
	return token, encoded, nil
}

func loadOrCreateTokenFromDirectory(directory *safefile.Directory) ([]byte, string, error) {
	if token, encoded, err := loadExistingTokenFromDirectory(directory); err == nil {
		return token, encoded, nil
	} else if !errors.Is(err, os.ErrNotExist) {
		return nil, "", err
	}
	token, encoded, err := randomToken()
	if err != nil {
		return nil, "", err
	}
	created, _, err := directory.PublishExclusiveIdentity("token", []byte(encoded+"\n"), 0600)
	if err != nil {
		return nil, "", err
	}
	if !created {
		return nil, "", errors.New("runtime token appeared during exclusive creation")
	}
	return token, encoded, nil
}

func (s *service) persistRecovery() error {
	if s.sandbox.ID == "" {
		return nil
	}
	network := s.networkReport("READY")
	p := persisted{SchemaVersion: 3, BundleIdentity: s.bundleIdentity, ID: s.sandbox.ID, Generation: s.sandbox.Generation, Network: network,
		TaskIdentity: storageTaskIdentity(s.namespace, s.id)}
	if s.sandbox.Config.Storage != nil {
		p.StorageSHA256 = s.sandbox.Config.Storage.SHA256
	}
	for _, process := range s.processes {
		if process.id == "" {
			p.PID, p.Exit, p.Exited = process.pid, process.exit, process.exited
		}
		p.Processes = append(p.Processes, persistedProcess{
			ID: process.id, Stdin: process.stdin, Stdout: process.stdout, Stderr: process.stderr,
			StdinIdentity: process.stdinIdentity, StdoutIdentity: process.stdoutIdentity, StderrIdentity: process.stderrIdentity,
			Terminal: process.terminal, Width: process.width, Height: process.height,
			SizeSet: process.sizeSet, StdinClosed: process.stdinClosed, StdinCloseAcked: process.stdinCloseAcked,
			StdinOffset: process.stdinOffset, StdinPending: append([]byte(nil), process.stdinPending...), Status: process.status,
			PID: process.pid, Exit: process.exit, Exited: process.exited,
			StdoutOffset: process.stdoutOffset, StderrOffset: process.stderrOffset,
			ExitEventQueued: process.exitEventQueued, DeleteEventQueued: process.deleteEventQueued,
			PendingSignal: process.pendingSignal, PendingSignalOp: process.pendingSignalOperation,
			PendingSignalAck: process.pendingSignalAcknowledgement,
		})
	}
	sort.Slice(p.Processes, func(i, j int) bool { return p.Processes[i].ID < p.Processes[j].ID })
	b, err := json.Marshal(p)
	if err != nil {
		return err
	}
	if err = s.ensureBundleIdentity(); err != nil {
		return err
	}
	runtimeDirectory, err := s.ensureRuntimeDirectory()
	if err != nil {
		return err
	}
	published, err := runtimeDirectory.ReplaceIdentity("sandbox.json", b, 0600, s.recoveryIdentity)
	if err != nil {
		return err
	}
	s.recoveryIdentity = &published
	return nil
}

func taskGuestPID(pid int) (uint32, error) {
	if pid <= 0 || uint64(pid) > uint64(^uint32(0)) {
		return 0, errors.New("guest returned a process ID outside the Task v2 range")
	}
	return uint32(pid), nil
}

func runningGuestProcess(state agent.ProcessState, processID string) (uint32, error) {
	if state.ID != processID || state.Status != "RUNNING" {
		return 0, errors.New("guest returned a running process with mismatched identity or state")
	}
	return taskGuestPID(state.PID)
}

func startedGuestProcess(state agent.ProcessState, processID string) (uint32, error) {
	if state.Status == "RUNNING" {
		return runningGuestProcess(state, processID)
	}
	if state.Status == "STOPPED" {
		pid, _, err := stoppedGuestProcess(state, processID, 0)
		return pid, err
	}
	return 0, errors.New("guest returned a started process with mismatched identity or state")
}

func createdGuestProcess(state agent.ProcessState, processID string) error {
	if state.ID != processID || state.Status != "CREATED" || state.PID != 0 || state.ExitCode != 0 {
		return errors.New("guest returned a created process with mismatched identity or state")
	}
	return nil
}

func stoppedGuestProcess(state agent.ProcessState, processID string, expectedPID uint32) (uint32, uint32, error) {
	if state.ID != processID || state.Status != "STOPPED" {
		return 0, 0, errors.New("guest returned a stopped process with mismatched identity or state")
	}
	pid, err := taskGuestPID(state.PID)
	if err != nil {
		return 0, 0, err
	}
	if expectedPID != 0 && pid != expectedPID {
		return 0, 0, errors.New("guest returned a stopped process with a different PID")
	}
	if state.ExitCode < 0 || state.ExitCode > 255 {
		return 0, 0, errors.New("guest returned an exit status outside the agent contract")
	}
	return pid, uint32(state.ExitCode), nil
}

func openStateDirectory(directory string) (*os.File, error) {
	if !filepath.IsAbs(directory) || filepath.Clean(directory) != directory {
		return nil, errors.New("state directory must be canonical and absolute")
	}
	info, err := os.Lstat(directory)
	if err != nil {
		return nil, err
	}
	identity, ok := info.Sys().(*syscall.Stat_t)
	if !ok {
		return nil, errors.New("state directory identity is unavailable")
	}
	if !info.IsDir() || info.Mode().Perm()&0002 != 0 || identity.Uid != uint32(os.Geteuid()) {
		return nil, fmt.Errorf("state directory must be caller-owned with safe mode (mode=%#o owner=%d caller=%d)",
			info.Mode().Perm(), identity.Uid, os.Geteuid())
	}
	descriptor, err := unix.Openat2(unix.AT_FDCWD, directory, &unix.OpenHow{
		Flags: uint64(unix.O_RDONLY | unix.O_DIRECTORY | unix.O_CLOEXEC), Resolve: unix.RESOLVE_NO_SYMLINKS | unix.RESOLVE_NO_MAGICLINKS,
	})
	if err != nil {
		return nil, err
	}
	dir := os.NewFile(uintptr(descriptor), directory)
	opened, err := dir.Stat()
	if err != nil || !sameProcessIOIdentity(info, opened) {
		_ = dir.Close()
		return nil, errors.New("state directory identity changed while opening")
	}
	return dir, nil
}

func stateIdentity(info os.FileInfo) (stateFileIdentity, bool) {
	value, ok := info.Sys().(*syscall.Stat_t)
	if !ok {
		return stateFileIdentity{}, false
	}
	return stateFileIdentity{device: uint64(value.Dev), inode: value.Ino, uid: value.Uid,
		mode: value.Mode, links: value.Nlink}, true
}

func inspectStateFileAt(dir *os.File, base string, mode os.FileMode) (stateFileIdentity, bool, error) {
	var stat unix.Stat_t
	err := unix.Fstatat(int(dir.Fd()), base, &stat, unix.AT_SYMLINK_NOFOLLOW)
	if errors.Is(err, syscall.ENOENT) {
		return stateFileIdentity{}, false, nil
	}
	if err != nil {
		return stateFileIdentity{}, false, err
	}
	identity := stateFileIdentity{device: uint64(stat.Dev), inode: stat.Ino, uid: stat.Uid,
		mode: stat.Mode, links: stat.Nlink}
	if stat.Mode&unix.S_IFMT != unix.S_IFREG || stat.Uid != uint32(os.Geteuid()) || stat.Nlink != 1 ||
		os.FileMode(stat.Mode).Perm() != mode.Perm() {
		return stateFileIdentity{}, true, errors.New("state file must be a private caller-owned single-link regular file")
	}
	return identity, true, nil
}

func removeStateFile(path string, expected *stateFileIdentity, mode os.FileMode) (retErr error) {
	dir, err := openStateDirectory(filepath.Dir(path))
	if err != nil {
		return err
	}
	defer func() { retErr = errors.Join(retErr, dir.Close()) }()
	current, found, err := inspectStateFileAt(dir, filepath.Base(path), mode)
	if err != nil {
		return err
	}
	if !found {
		if expected != nil {
			return errors.New("owned state file disappeared before removal")
		}
		return nil
	}
	if expected == nil || current != *expected {
		return errors.New("refusing to remove replaced or unowned state file")
	}
	if err = unix.Unlinkat(int(dir.Fd()), filepath.Base(path), 0); err != nil {
		return err
	}
	return dir.Sync()
}

func atomicWriteFile(path string, data []byte, mode os.FileMode) (retErr error) {
	return atomicWriteFileOwned(path, data, mode, nil, nil)
}

func atomicWriteFileOwned(path string, data []byte, mode os.FileMode, expected, published *stateFileIdentity) (retErr error) {
	if !filepath.IsAbs(path) || filepath.Clean(path) != path || mode.Perm()&0077 != 0 {
		return errors.New("atomic state path and mode must be canonical, absolute, and private")
	}
	directory := filepath.Dir(path)
	dir, err := openStateDirectory(directory)
	if err != nil {
		return err
	}
	defer func() { retErr = errors.Join(retErr, dir.Close()) }()
	base := filepath.Base(path)
	current, found, err := inspectStateFileAt(dir, base, mode)
	if err != nil {
		return err
	}
	if published != nil && (expected == nil && found || expected != nil && (!found || current != *expected)) {
		return errors.New("refusing to replace an unowned or changed state file")
	}
	var temporary *os.File
	var temporaryName string
	for attempt := 0; attempt < 16; attempt++ {
		random := make([]byte, 8)
		if _, err = io.ReadFull(rand.Reader, random); err != nil {
			return err
		}
		temporaryName = "." + base + "." + hex.EncodeToString(random)
		temporaryDescriptor, openErr := unix.Openat(int(dir.Fd()), temporaryName,
			unix.O_WRONLY|unix.O_CREAT|unix.O_EXCL|unix.O_CLOEXEC|unix.O_NOFOLLOW, uint32(mode.Perm()))
		if errors.Is(openErr, syscall.EEXIST) {
			continue
		}
		if openErr != nil {
			return openErr
		}
		temporary = os.NewFile(uintptr(temporaryDescriptor), temporaryName)
		break
	}
	if temporary == nil {
		return errors.New("could not allocate a unique atomic state temporary file")
	}
	renamed := false
	defer func() {
		if !renamed {
			_ = unix.Unlinkat(int(dir.Fd()), temporaryName, 0)
		}
	}()
	if err = temporary.Chmod(mode); err == nil {
		var written int
		written, err = temporary.Write(data)
		if err == nil && written != len(data) {
			err = io.ErrShortWrite
		}
	}
	if err == nil {
		err = temporary.Sync()
	}
	var temporaryIdentity stateFileIdentity
	if err == nil {
		var info os.FileInfo
		info, err = temporary.Stat()
		var ok bool
		if err == nil {
			temporaryIdentity, ok = stateIdentity(info)
			if !ok {
				err = errors.New("temporary state identity is unavailable")
			}
		}
	}
	closeErr := temporary.Close()
	if err != nil {
		return err
	}
	if closeErr != nil {
		return closeErr
	}
	if err = unix.Renameat(int(dir.Fd()), temporaryName, int(dir.Fd()), base); err != nil {
		return err
	}
	renamed = true
	err = dir.Sync()
	if err == nil && published != nil {
		*published = temporaryIdentity
	}
	return err
}

func (s *service) recoverExisting(ctx context.Context) (retErr error) {
	if err := ctx.Err(); err != nil {
		return err
	}
	if err := s.ensureBundleIdentity(); err != nil {
		return fmt.Errorf("verify recovery bundle identity: %w", err)
	}
	runtimeDirectory, err := s.ensureRuntimeDirectory()
	if errors.Is(err, os.ErrNotExist) {
		return nil
	}
	if err != nil {
		return fmt.Errorf("open recovery runtime directory: %w", err)
	}
	recovery, found, recoveryIdentity, err := loadPersistedRecoveryFromDirectory(runtimeDirectory, s.namespace, s.id)
	if err != nil {
		return fmt.Errorf("read shim recovery state: %w", err)
	}
	if !found {
		return nil
	}
	if recovery.BundleIdentity != s.bundleIdentity {
		return errors.New("persisted recovery bundle identity differs from the service handoff")
	}
	s.recoveryIdentity = recoveryIdentity
	var sandboxes []protocol.Sandbox
	if apiErr := s.daemon.Call(ctx, protocol.Request{Version: 1, RequestID: "shim-recover-list-" + s.id, Method: "ListSandboxes"}, &sandboxes); apiErr != nil {
		return fmt.Errorf("list sandboxes for shim recovery: %s", apiErr.Message)
	}
	for _, sandbox := range sandboxes {
		if sandbox.ID == recovery.ID && sandbox.Generation == recovery.Generation {
			s.sandbox = sandbox
			break
		}
	}
	if s.sandbox.ID == "" {
		return errors.New("persisted sandbox generation is not owned by mkruntimed")
	}
	if s.sandbox.Config.BundleIdentity != s.bundleIdentity {
		return errors.New("daemon sandbox bundle identity differs from the service handoff")
	}
	s.token, _, err = loadExistingTokenFromDirectory(runtimeDirectory)
	if err != nil {
		return fmt.Errorf("read recovery token: %w", err)
	}
	s.netEndpoint = recovery.Network
	if s.netEndpoint.SandboxID != s.sandbox.ID || s.netEndpoint.SandboxGeneration != s.sandbox.Generation {
		return errors.New("persisted network binding does not match the sandbox generation")
	}
	bound, device, bindErr := s.attachNetwork(ctx, s.netEndpoint.NetNS, s.netEndpoint.Generation)
	if bindErr != nil {
		return fmt.Errorf("recover CNI endpoint binding: %w", bindErr)
	}
	s.netEndpoint = bound
	s.netDevice = device
	if err = s.ensureNamespaceHolder(); err != nil {
		return fmt.Errorf("recover network namespace holder: %w", err)
	}
	recovered := false
	defer func() {
		if recovered {
			return
		}
		var cleanupErrors []error
		for _, process := range s.processes {
			closeProcessIO(process)
		}
		if s.agent != nil {
			cleanupErrors = append(cleanupErrors, s.agent.Close())
			s.agent = nil
		}
		if s.netDevice != nil {
			cleanupErrors = append(cleanupErrors, s.netDevice.Close())
			s.netDevice = nil
		}
		cleanupErrors = append(cleanupErrors, s.stopNamespaceHolder())
		cleanupErrors = append(cleanupErrors, s.stopRelay())
		retErr = errors.Join(retErr, errors.Join(cleanupErrors...))
	}()
	s.netRXPackets.Store(bound.RXPackets)
	s.netTXPackets.Store(bound.TXPackets)
	s.netRXDrops.Store(bound.RXDrops)
	s.netTXDrops.Store(bound.TXDrops)
	s.netErrors.Store(bound.Errors)
	s.relaySocket = s.agentRelaySocketPath(s.sandbox.Config.AgentPort, s.sandbox.Generation)
	if err = removeStaleRelaySocket(s.relaySocket); err != nil {
		s.relaySocket = ""
		return fmt.Errorf("remove stale recovered agent relay socket: %w", err)
	}
	s.relay = s.relayCommand(s.sandbox.Config.AgentPort, s.relaySocket)
	if err = s.relay.Start(); err != nil {
		return fmt.Errorf("restart recovered agent relay: %w", err)
	}
	deadline := time.Now().Add(5 * time.Second)
	for {
		if s.relayOwner == nil {
			err = s.acquireRelaySocketOwner(s.relaySocket)
			if errors.Is(err, os.ErrNotExist) && time.Now().Before(deadline) && ctx.Err() == nil {
				if err = waitContext(ctx, 50*time.Millisecond); err == nil {
					continue
				}
			}
			if err != nil {
				return fmt.Errorf("capture recovered agent relay socket: %w", err)
			}
		}
		var client agentClient
		client, err = s.dialAgent(ctx, s.relaySocket)
		if err == nil {
			s.agent = client
		}
		if err == nil || time.Now().After(deadline) || ctx.Err() != nil {
			break
		}
		if err = waitContext(ctx, 50*time.Millisecond); err != nil {
			break
		}
	}
	if err != nil {
		return fmt.Errorf("reconnect recovered guest agent: %w", err)
	}
	if err = s.negotiateAgentCapabilities(ctx); err != nil {
		return fmt.Errorf("negotiate recovered guest agent: %w", err)
	}
	type recoveredProcess struct {
		agentID string
		process *process
	}
	type recoveredSignalAcknowledgement struct {
		agentID, operationID string
		process              *process
		signal               uint32
	}
	var running []recoveredProcess
	var signalAcknowledgements []recoveredSignalAcknowledgement
	for _, saved := range recovery.Processes {
		p := &process{
			id: saved.ID, stdin: saved.Stdin, stdout: saved.Stdout, stderr: saved.Stderr,
			stdinIdentity: saved.StdinIdentity, stdoutIdentity: saved.StdoutIdentity, stderrIdentity: saved.StderrIdentity,
			terminal: saved.Terminal, width: saved.Width, height: saved.Height,
			sizeSet: saved.SizeSet, stdinClosed: saved.StdinClosed, stdinCloseAcked: saved.StdinCloseAcked,
			stdinOffset: saved.StdinOffset, stdinPending: append([]byte(nil), saved.StdinPending...), status: saved.Status,
			pid: saved.PID, exit: saved.Exit, exited: saved.Exited,
			stdoutOffset: saved.StdoutOffset, stderrOffset: saved.StderrOffset,
			exitEventQueued: saved.ExitEventQueued, deleteEventQueued: saved.DeleteEventQueued, done: make(chan struct{}),
			pendingSignal: saved.PendingSignal, pendingSignalOperation: saved.PendingSignalOp,
			pendingSignalAcknowledgement: saved.PendingSignalAck,
		}
		s.processes[saved.ID] = p
		if p.status == tasktypes.Status_STOPPED {
			if !p.exitEventQueued {
				if err = s.publishExit(ctx, p.id, p); err != nil {
					return fmt.Errorf("recover process %q exit event: %w", saved.ID, err)
				}
				p.exitEventQueued = true
			}
			close(p.done)
			continue
		}
		if p.status == tasktypes.Status_CREATED && p.id != "" {
			var exists bool
			exists, err = s.reconcileRecoveredCreatedExec(ctx, p)
			if err != nil {
				return err
			}
			if !exists {
				delete(s.processes, p.id)
			}
			continue
		}
		if p.status != tasktypes.Status_RUNNING && p.status != tasktypes.Status_PAUSED {
			continue
		}
		agentID := p.id
		if agentID == "" {
			agentID = "init"
		}
		var state agent.ProcessState
		if err = s.callAgentWithReconnectContext(ctx, "StateProcess", map[string]string{"ID": agentID}, &state); err != nil {
			return fmt.Errorf("recover process %q: %w", saved.ID, err)
		}
		if state.ID != agentID {
			return fmt.Errorf("recover process %q: guest returned a mismatched process identity", saved.ID)
		}
		if state.Status == "STOPPED" {
			if err = s.callAgentWithReconnectContext(ctx, "WaitProcess", map[string]string{"ID": agentID}, &state); err != nil {
				return fmt.Errorf("recover stopped process %q wait state: %w", saved.ID, err)
			}
			var pid, exit uint32
			pid, exit, err = stoppedGuestProcess(state, agentID, p.pid)
			if err != nil {
				return fmt.Errorf("recover stopped process %q wait state: %w", saved.ID, err)
			}
			p.status, p.pid, p.exit, p.stdinPending = tasktypes.Status_STOPPED, pid, exit, nil
			if p.pendingSignalOperation != "" {
				p.pendingSignalAcknowledgement = true
				signalAcknowledgements = append(signalAcknowledgements, recoveredSignalAcknowledgement{
					agentID: agentID, operationID: p.pendingSignalOperation, process: p, signal: p.pendingSignal,
				})
			}
			p.exited = time.Now().UTC()
			if err = s.publishExit(ctx, p.id, p); err != nil {
				return fmt.Errorf("recover stopped process %q exit event: %w", saved.ID, err)
			}
			p.exitEventQueued = true
			close(p.done)
			continue
		}
		guestPID, pidErr := runningGuestProcess(state, agentID)
		if pidErr != nil {
			return fmt.Errorf("recover process %q: %w", saved.ID, pidErr)
		}
		p.pid = guestPID
		if p.pendingSignalOperation != "" {
			if !p.pendingSignalAcknowledgement {
				signalErr := s.signalGuestProcess(ctx, agentID, p.pendingSignal, p.pendingSignalOperation)
				var remoteError *agent.RemoteError
				if signalErr != nil && !errors.As(signalErr, &remoteError) {
					return fmt.Errorf("recover process %q pending signal: %w", saved.ID, signalErr)
				}
				p.pendingSignalAcknowledgement = true
			}
			signalAcknowledgements = append(signalAcknowledgements, recoveredSignalAcknowledgement{
				agentID: agentID, operationID: p.pendingSignalOperation, process: p, signal: p.pendingSignal,
			})
		}
		if p.terminal && p.sizeSet {
			if err = s.resizeGuestProcess(ctx, agentID, p.width, p.height); err != nil {
				return fmt.Errorf("recover process %q terminal size: %w", saved.ID, err)
			}
		}
		if err = s.openProcessIO(ctx, p); err != nil {
			return fmt.Errorf("recover process %q I/O: %w", saved.ID, err)
		}
		running = append(running, recoveredProcess{agentID: agentID, process: p})
	}
	if s.netEndpoint.Generation != "" {
		s.startNetworkPump()
	}
	for _, item := range running {
		go s.pumpStdin(item.agentID, item.process)
		go s.waitProcess(item.agentID, item.process.id, item.process)
	}
	if err = s.persistRecovery(); err != nil {
		return fmt.Errorf("persist reconstructed process state: %w", err)
	}
	for _, item := range signalAcknowledgements {
		if err = s.acknowledgeGuestSignal(ctx, item.agentID, item.operationID); err != nil {
			return fmt.Errorf("acknowledge recovered process %q signal: %w", item.process.id, err)
		}
		item.process.pendingSignal, item.process.pendingSignalOperation, item.process.pendingSignalAcknowledgement = 0, "", false
	}
	if len(signalAcknowledgements) != 0 {
		if err = s.persistRecovery(); err != nil {
			for _, item := range signalAcknowledgements {
				item.process.pendingSignal = item.signal
				item.process.pendingSignalOperation = item.operationID
				item.process.pendingSignalAcknowledgement = true
			}
			return fmt.Errorf("persist recovered signal acknowledgement: %w", err)
		}
	}
	recovered = true
	return nil
}

func (s *service) reconcileRecoveredCreatedExec(ctx context.Context, p *process) (bool, error) {
	var state agent.ProcessState
	err := s.callAgentWithReconnectContext(ctx, "StateProcess", map[string]string{"ID": p.id}, &state)
	if agentNotFound(err) {
		return false, nil
	}
	if err != nil {
		return false, fmt.Errorf("recover created exec process %q: %w", p.id, err)
	}
	if err = createdGuestProcess(state, p.id); err != nil {
		return false, fmt.Errorf("recover created exec process %q: %w", p.id, err)
	}
	if err = s.publish(ctx, ctruntime.TaskExecAddedEventTopic, &eventstypes.TaskExecAdded{ContainerID: s.id, ExecID: p.id}); err != nil {
		return false, fmt.Errorf("recover created exec process %q event: %w", p.id, err)
	}
	return true, nil
}

func relaySocketPath(port uint32, generation string) string {
	if len(generation) > 12 {
		generation = generation[:12]
	}
	return filepath.Join("/run", "mk-agent-"+strconv.Itoa(int(port))+"-"+generation+".sock")
}

func newRelayCommand(binary string, port uint32, socket string) *exec.Cmd {
	command := exec.Command(binary, "server", strconv.Itoa(int(port)), socket)
	command.SysProcAttr = &syscall.SysProcAttr{Setpgid: true}
	return command
}

func removeStaleRelaySocket(path string) error {
	if _, err := os.Lstat(path); errors.Is(err, os.ErrNotExist) {
		// A later publisher is not stale and must remain untouched.
		return nil
	} else if err != nil {
		return err
	}
	owner, err := unixsocket.Capture(path)
	if errors.Is(err, os.ErrNotExist) {
		return nil
	}
	if err != nil {
		return err
	}
	return owner.Remove()
}

func terminateRelay(command *exec.Cmd) error {
	if command == nil || command.Process == nil {
		return nil
	}
	if command.ProcessState != nil {
		return nil
	}
	err := syscall.Kill(-command.Process.Pid, syscall.SIGKILL)
	if err != nil && !errors.Is(err, syscall.ESRCH) {
		return err
	}
	waitErr := command.Wait()
	var exitErr *exec.ExitError
	if waitErr == nil || errors.As(waitErr, &exitErr) || errors.Is(waitErr, syscall.ECHILD) {
		return nil
	}
	return waitErr
}

func relayProcessLive(command *exec.Cmd) (bool, error) {
	if command == nil || command.Process == nil || command.ProcessState != nil {
		return false, nil
	}
	fd, err := unix.Open(filepath.Join("/proc", strconv.Itoa(command.Process.Pid)), unix.O_RDONLY|unix.O_DIRECTORY|unix.O_CLOEXEC, 0)
	if errors.Is(err, syscall.ENOENT) {
		return false, nil
	}
	if err != nil {
		return false, err
	}
	directory := os.NewFile(uintptr(fd), "relay-process")
	defer directory.Close()
	stat, err := readProcEntry(directory, "stat", 4096)
	if errors.Is(err, syscall.ENOENT) {
		return false, nil
	}
	if err != nil {
		return false, err
	}
	close := bytes.LastIndex(stat, []byte(") "))
	if close < 0 {
		return false, errors.New("relay process stat is malformed")
	}
	fields := strings.Fields(string(stat[close+2:]))
	if len(fields) == 0 {
		return false, errors.New("relay process stat omits state")
	}
	return fields[0] != "Z" && fields[0] != "X", nil
}

func (s *service) relaySnapshot() (string, uint64) {
	s.relayMu.Lock()
	defer s.relayMu.Unlock()
	return s.relaySocket, s.relayGeneration
}

func (s *service) replaceExitedRelay(ctx context.Context, observedGeneration uint64) (bool, error) {
	s.relayMu.Lock()
	defer s.relayMu.Unlock()
	if observedGeneration != s.relayGeneration {
		return true, nil
	}
	if s.relay == nil {
		return false, nil
	}
	live, err := relayProcessLive(s.relay)
	if err != nil {
		return false, fmt.Errorf("inspect agent relay process: %w", err)
	}
	if live {
		return false, nil
	}
	if s.relaySocket == "" {
		return false, errors.New("agent relay socket is unavailable")
	}
	if err = terminateRelay(s.relay); err != nil {
		return false, fmt.Errorf("reap exited agent relay: %w", err)
	}
	s.relay = nil
	if s.relayOwner != nil {
		err = s.relayOwner.Remove()
	} else {
		err = removeStaleRelaySocket(s.relaySocket)
	}
	if err != nil {
		return false, fmt.Errorf("remove exited agent relay socket: %w", err)
	}
	s.relayOwner = nil
	command := s.relayCommand(s.sandbox.Config.AgentPort, s.relaySocket)
	if err = command.Start(); err != nil {
		return false, fmt.Errorf("restart exited agent relay: %w", err)
	}
	s.relay = command
	deadline := time.Now().Add(5 * time.Second)
	for {
		owner, captureErr := s.captureRelaySocket(s.relaySocket)
		if captureErr == nil {
			if owner == nil {
				captureErr = errors.New("relay socket capture returned no owner")
			} else {
				s.relayOwner = owner
				s.relayGeneration++
				return true, nil
			}
		}
		if !errors.Is(captureErr, os.ErrNotExist) || time.Now().After(deadline) || ctx.Err() != nil {
			cleanupErr := terminateRelay(command)
			s.relay = nil
			return false, errors.Join(fmt.Errorf("capture restarted agent relay socket: %w", captureErr), ctx.Err(), cleanupErr)
		}
		if err = waitContext(ctx, 50*time.Millisecond); err != nil {
			cleanupErr := terminateRelay(command)
			s.relay = nil
			return false, errors.Join(err, cleanupErr)
		}
	}
}

func daemonErrorCode(err error, code string) bool {
	observed, ok := daemon.ErrorCode(err)
	return ok && observed == code
}

func (s *service) stopRelay() error {
	s.relayMu.Lock()
	defer s.relayMu.Unlock()
	if s.relay != nil {
		if err := terminateRelay(s.relay); err != nil {
			return err
		}
		s.relay = nil
	}
	if s.relaySocket != "" {
		var err error
		if s.relayOwner != nil {
			err = s.relayOwner.Remove()
		} else {
			err = removeStaleRelaySocket(s.relaySocket)
		}
		if err != nil {
			return err
		}
		s.relayOwner = nil
		s.relaySocket = ""
	}
	return nil
}

// sandboxID maps the containerd namespace/task tuple into the daemon's global
// identifier space. The readable prefix is diagnostic only; the digest binds
// the complete, unsanitized tuple so truncation and punctuation cannot alias.
func sandboxID(namespace, id string) string {
	var b strings.Builder
	b.WriteString("mk-")
	for _, r := range strings.ToLower(id) {
		if r >= 'a' && r <= 'z' || r >= '0' && r <= '9' || r == '-' {
			b.WriteRune(r)
		}
	}
	prefix := strings.Trim(strings.TrimPrefix(b.String(), "mk-"), "-")
	if prefix == "" {
		prefix = "task"
	}
	if len(prefix) > 32 {
		prefix = prefix[:32]
	}
	digest := sha256.Sum256([]byte(namespace + "\x00" + id))
	return "mk-" + prefix + "-" + hex.EncodeToString(digest[:8])
}

func storageTaskIdentity(namespace, id string) string {
	digest := sha256.Sum256([]byte(namespace + "\x00" + id))
	return "task-" + hex.EncodeToString(digest[:16])
}

func parseCPUSet(s string) ([][]int, error) {
	var sets [][]int
	for _, group := range strings.Split(s, ";") {
		var set []int
		for _, raw := range strings.Split(group, ",") {
			n, err := strconv.Atoi(strings.TrimSpace(raw))
			if err != nil {
				return nil, err
			}
			set = append(set, n)
		}
		if len(set) > 0 {
			sets = append(sets, set)
		}
	}
	return sets, nil
}

func openAllocationLock(ctx context.Context, path string) (*safefile.Directory, error) {
	absolute, err := filepath.Abs(path)
	if err != nil || filepath.Clean(absolute) != absolute || filepath.Base(absolute) == "." || filepath.Base(absolute) == string(filepath.Separator) {
		return nil, errors.Join(errors.New("allocation lock path must be canonical and below the filesystem root"), err)
	}
	lock, err := safefile.OpenOwnedDirectory(filepath.Dir(absolute))
	if err != nil {
		return nil, err
	}
	for {
		acquired, lockErr := lock.TryLockExclusive()
		if lockErr != nil {
			_ = lock.Close()
			return nil, lockErr
		}
		if acquired {
			return lock, nil
		}
		select {
		case <-ctx.Done():
			_ = lock.Close()
			return nil, ctx.Err()
		case <-time.After(10 * time.Millisecond):
		}
	}
}

func (s *service) allocate(ctx context.Context, bundle string) (protocol.SandboxConfig, *safefile.Directory, error) {
	lock, err := openAllocationLock(ctx, getenv("MK_SHIM_LOCK", "/run/multikernel-shim.lock"))
	if err != nil {
		return protocol.SandboxConfig{}, nil, err
	}
	var existing []protocol.Sandbox
	req := protocol.Request{Version: 1, RequestID: "list-" + s.id, Method: "ListSandboxes"}
	if apiErr := s.daemon.Call(ctx, req, &existing); apiErr != nil {
		lock.Close()
		return protocol.SandboxConfig{}, nil, errors.New(apiErr.Message)
	}
	sets, err := parseCPUSet(getenv("MK_SANDBOX_CPU_SETS", "8,10;12,14;9,11;13,15"))
	if err != nil {
		lock.Close()
		return protocol.SandboxConfig{}, nil, err
	}
	used := map[int]bool{}
	for _, sb := range existing {
		for _, cpu := range sb.Config.CPUs {
			used[cpu] = true
		}
	}
	for i, set := range sets {
		free := true
		for _, cpu := range set {
			if used[cpu] {
				free = false
			}
		}
		if free {
			return protocol.SandboxConfig{SchemaVersion: 1, ID: sandboxID(s.namespace, s.id), CPUs: set, MemoryBytes: 3 << 30, KernelManifest: "gce-mk2", Bundle: bundle,
				BundleIdentity: s.bundleIdentity, AgentPort: uint32(7200 + i), ChildCID: uint32(40 + i), Storage: &protocol.StorageConfig{Port: uint32(4061 + i)}}, lock, nil
		}
	}
	lock.Close()
	return protocol.SandboxConfig{}, nil, errors.New("no disjoint Multikernel CPU set is available")
}

func (s *service) rollbackCreate(ctx context.Context, prepared *rootfspkg.CleanupRequest, lifecycleAttempted bool, config protocol.SandboxConfig, createKey string) error {
	var failures []error
	canCleanupPrepared := !lifecycleAttempted
	if err := s.stopNamespaceHolder(); err != nil {
		failures = append(failures, fmt.Errorf("stop network namespace holder: %w", err))
	}
	if err := s.releaseNetwork(ctx); err != nil {
		failures = append(failures, err)
	}
	if lifecycleAttempted {
		if err := s.cancelCreate(ctx, config, createKey); err != nil {
			failures = append(failures, fmt.Errorf("cancel allocated sandbox: %w", err))
		} else {
			canCleanupPrepared = true
			s.sandbox = protocol.Sandbox{}
		}
	} else if s.sandbox.ID != "" {
		if _, err := daemon.Mutation(ctx, s.daemon, "DeleteSandbox", s.sandbox.ID, s.sandbox.Generation, "shim-create-rollback-delete-"+s.sandbox.Generation, nil); err != nil && !daemonErrorCode(err, "NOT_FOUND") {
			failures = append(failures, fmt.Errorf("delete allocated sandbox: %w", err))
		} else {
			canCleanupPrepared = true
			s.sandbox = protocol.Sandbox{}
		}
	}
	if prepared != nil && canCleanupPrepared {
		if err := s.cleanupRootfs(ctx, *prepared); err != nil {
			failures = append(failures, fmt.Errorf("cleanup prepared rootfs: %w", err))
		}
	}
	s.token = nil
	delete(s.processes, "")
	return errors.Join(failures...)
}

func bundleNetworkNamespaceFrom(directory *safefile.Directory) (string, error) {
	identity, present, err := directory.EntryIdentity("config.json")
	if err != nil || !present {
		return "", errors.Join(errors.New("OCI config.json is missing"), err)
	}
	mode := os.FileMode(identity.Mode).Perm()
	if identity.Mode&unix.S_IFMT != unix.S_IFREG || mode&0022 != 0 || identity.Size > 1<<20 || identity.Size < 0 ||
		identity.UID != uint32(os.Geteuid()) || identity.Links != 1 {
		return "", errors.New("OCI config.json must be a bounded private caller-owned single-link regular file")
	}
	data, opened, err := directory.ReadRegularIdentity("config.json", mode, 1<<20)
	if err != nil {
		return "", err
	}
	if !safefile.SameObject(identity, opened) {
		return "", errors.New("OCI config.json identity changed while reading")
	}
	var spec specs.Spec
	if err = protocol.StrictDecode(data, &spec); err != nil {
		return "", fmt.Errorf("decode OCI config for network ownership: %w", err)
	}
	if spec.Linux == nil {
		return "", errors.New("OCI Linux configuration is required")
	}
	var result string
	count := 0
	for _, namespace := range spec.Linux.Namespaces {
		if namespace.Type != specs.NetworkNamespace {
			continue
		}
		count++
		if count > 1 {
			return "", errors.New("OCI config contains multiple network namespaces")
		}
		result = namespace.Path
	}
	if count != 1 {
		return "", errors.New("OCI config must contain exactly one network namespace")
	}
	if result != "" && (!filepath.IsAbs(result) || filepath.Clean(result) != result) {
		return "", errors.New("OCI network namespace path must be absolute and canonical")
	}
	return result, nil
}

func bundleNetworkNamespace(bundle string) (string, error) {
	directory, err := safefile.OpenOwnedDirectory(bundle)
	if err != nil {
		return "", err
	}
	defer directory.Close()
	return bundleNetworkNamespaceFrom(directory)
}

func (s *service) ensureBundleIdentity() error {
	current, err := safefile.OpenOwnedDirectory(s.bundle)
	if err != nil {
		return err
	}
	identity := current.Identity()
	observed := rootfspkg.DirectoryIdentity{Device: identity.Device, Inode: identity.Inode, UID: identity.UID}
	if s.bundleDirectory == nil {
		s.bundleDirectory, s.bundleIdentity = current, observed
		return nil
	}
	defer current.Close()
	if observed != s.bundleIdentity {
		return errors.New("bundle directory identity changed after shim construction")
	}
	return nil
}

func (s *service) ensureRuntimeDirectory() (*safefile.Directory, error) {
	if err := s.ensureBundleIdentity(); err != nil {
		return nil, err
	}
	s.runtimeMu.Lock()
	defer s.runtimeMu.Unlock()
	current, err := s.bundleDirectory.OpenChildDirectory(".multikernel", 0700)
	if err != nil {
		return nil, err
	}
	if s.runtimeDirectory == nil {
		s.runtimeDirectory = current
		return current, nil
	}
	defer current.Close()
	if !safefile.SameObject(current.Identity(), s.runtimeDirectory.Identity()) {
		return nil, errors.New("runtime directory identity changed after shim binding")
	}
	return s.runtimeDirectory, nil
}

func verifyRuntimeDirectoryHandoff(directory *safefile.Directory, expected rootfspkg.DirectoryIdentity) error {
	identity := directory.Identity()
	observed := rootfspkg.DirectoryIdentity{Device: identity.Device, Inode: identity.Inode, UID: identity.UID}
	if observed != expected {
		return errors.New("runtime directory identity differs from the rootfs handoff")
	}
	return nil
}

func (s *service) closeBundleIdentity() {
	s.bundleClose.Do(func() {
		if s.runtimeDirectory != nil {
			_ = s.runtimeDirectory.Close()
		}
		if s.bundleDirectory != nil {
			_ = s.bundleDirectory.Close()
		}
	})
}

func (s *service) taskPID(execID string, process *process) uint32 {
	if execID == "" && s.namespaceHolder != nil {
		return s.namespaceHolder.PID()
	}
	if process == nil {
		return 0
	}
	return process.pid
}

func (s *service) cancelCreate(ctx context.Context, config protocol.SandboxConfig, key string) error {
	body, err := json.Marshal(config)
	if err != nil {
		return err
	}
	var result struct {
		SafeToCleanup bool `json:"safe_to_cleanup"`
	}
	apiErr := s.daemon.Call(ctx, protocol.Request{
		Version: 1, RequestID: "cancel-" + key, Method: "CancelCreateSandbox",
		IdempotencyKey: key, Body: body,
	}, &result)
	if apiErr != nil {
		return errors.New(apiErr.Code + ": " + apiErr.Message)
	}
	if !result.SafeToCleanup {
		return errors.New("create cancellation did not prove cleanup safety")
	}
	return nil
}

func (s *service) validateTaskRequest(id string) error {
	if id != s.id {
		return fmt.Errorf("%w: request task ID does not match shim task", errdefs.ErrInvalidArgument)
	}
	return nil
}

func (s *service) Create(ctx context.Context, r *taskapi.CreateTaskRequest) (_ *taskapi.CreateTaskResponse, retErr error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	if r == nil {
		return nil, fmt.Errorf("%w: nil create request", errdefs.ErrInvalidArgument)
	}
	if err := s.validateTaskRequest(r.ID); err != nil || r.Bundle != s.bundle {
		return nil, fmt.Errorf("%w: invalid task", errdefs.ErrInvalidArgument)
	}
	boundIO, err := inspectBoundProcessIOPaths(r.Stdin, r.Stdout, r.Stderr)
	if err != nil {
		return nil, fmt.Errorf("%w: %v", errdefs.ErrInvalidArgument, err)
	}
	if err := lockContext(ctx, &s.mu); err != nil {
		return nil, err
	}
	defer s.mu.Unlock()
	if s.shuttingDown {
		return nil, errdefs.ErrFailedPrecondition
	}
	if len(s.processes) != 0 {
		return nil, errdefs.ErrAlreadyExists
	}
	if err := s.ensureBundleIdentity(); err != nil {
		return nil, fmt.Errorf("%w: %v", errdefs.ErrInvalidArgument, err)
	}
	netns, err := bundleNetworkNamespaceFrom(s.bundleDirectory)
	if err != nil {
		return nil, err
	}
	mounts, err := rootfsMounts(r.Rootfs)
	if err != nil {
		return nil, err
	}
	if err = s.validateRootfs(ctx, rootfspkg.ValidateRequest{Version: rootfspkg.Version, Bundle: r.Bundle,
		BundleIdentity: s.bundleIdentity}); err != nil {
		return nil, fmt.Errorf("validate OCI bundle before allocation: %w", err)
	}
	var prepared *rootfspkg.CleanupRequest
	lifecycleAttempted := false
	var config protocol.SandboxConfig
	var createKey string
	fail := true
	defer func() {
		if fail {
			if cleanupErr := s.rollbackCreate(context.WithoutCancel(ctx), prepared, lifecycleAttempted, config, createKey); cleanupErr != nil {
				retErr = errors.Join(retErr, fmt.Errorf("create rollback: %w", cleanupErr))
			}
		}
	}()
	config, lock, err := s.allocate(ctx, r.Bundle)
	if err != nil {
		return nil, err
	}
	defer lock.Close()
	identity := storageTaskIdentity(s.namespace, s.id)
	result, err := s.prepareRootfs(ctx, rootfspkg.PrepareRequest{Version: rootfspkg.Version, Bundle: r.Bundle, BundleIdentity: s.bundleIdentity,
		TaskIdentity: identity, StoragePort: config.Storage.Port, Mounts: mounts})
	if err != nil {
		return nil, err
	}
	config.Storage = &result.Storage
	prepared = &rootfspkg.CleanupRequest{Version: rootfspkg.Version, Bundle: r.Bundle, BundleIdentity: s.bundleIdentity, TaskIdentity: identity, StorageSHA256: result.Storage.SHA256}
	runtimeDirectory, err := s.ensureRuntimeDirectory()
	if err != nil {
		return nil, err
	}
	if err = verifyRuntimeDirectoryHandoff(runtimeDirectory, result.RuntimeIdentity); err != nil {
		return nil, err
	}
	token, tokenHex, err := loadOrCreateTokenFromDirectory(runtimeDirectory)
	if err != nil {
		return nil, err
	}
	s.token = token
	lifecycleAttempted = true
	createKey = "shim-create-" + s.id + "-" + tokenHex[:12]
	createClient := daemonCallerWithTimeout(s.daemon, createSandboxDaemonTimeout)
	created, err := daemon.Mutation(ctx, createClient, "CreateSandbox", "", "", createKey, &config)
	if err != nil {
		cancelContext, cancel := context.WithTimeout(context.WithoutCancel(ctx), 5*time.Second)
		cancelErr := s.cancelCreate(cancelContext, config, createKey)
		cancel()
		if cancelErr == nil {
			lifecycleAttempted = false
		}
		return nil, errors.Join(err, cancelErr)
	}
	s.sandbox = created.Sandbox
	if _, err = daemon.Mutation(ctx, s.daemon, "LoadSandbox", s.sandbox.ID, s.sandbox.Generation, "shim-load-"+s.sandbox.Generation, nil); err != nil {
		return nil, err
	}
	if err = s.provisionNetwork(ctx, netns); err != nil {
		return nil, fmt.Errorf("provision primary network endpoint: %w", err)
	}
	if err = s.ensureNamespaceHolder(); err != nil {
		return nil, err
	}
	s.bundle = r.Bundle
	s.processes[""] = &process{id: "", stdin: boundIO.stdin, stdout: boundIO.stdout, stderr: boundIO.stderr,
		stdinIdentity: boundIO.stdinIdentity, stdoutIdentity: boundIO.stdoutIdentity, stderrIdentity: boundIO.stderrIdentity,
		terminal: r.Terminal, status: tasktypes.Status_CREATED, done: make(chan struct{})}
	if err = s.persistRecovery(); err != nil {
		return nil, fmt.Errorf("persist recovery state: %w", err)
	}
	pid := s.taskPID("", s.processes[""])
	if err = s.publish(ctx, ctruntime.TaskCreateEventTopic, &eventstypes.TaskCreate{ContainerID: s.id, Bundle: r.Bundle, Rootfs: r.Rootfs, Pid: pid}); err != nil {
		return nil, err
	}
	fail = false
	return &taskapi.CreateTaskResponse{Pid: pid}, nil
}

func (s *service) connectAgent(ctx context.Context) error {
	// Docker uses 64-byte container IDs and deeply nested runtime bundles;
	// placing the relay socket in the bundle can exceed sockaddr_un.sun_path.
	// Use a generation-qualified short path under /run instead.
	sock := s.agentRelaySocketPath(s.sandbox.Config.AgentPort, s.sandbox.Generation)
	s.relaySocket = sock
	if err := removeStaleRelaySocket(sock); err != nil {
		s.relaySocket = ""
		return fmt.Errorf("remove stale agent relay socket: %w", err)
	}
	if s.netEndpoint.Generation == "" {
		return errors.New("CNI endpoint is not bound")
	}
	endpoint, device, err := s.attachNetwork(ctx, s.netEndpoint.NetNS, s.netEndpoint.Generation)
	if err != nil {
		return err
	}
	s.netEndpoint, s.netDevice = endpoint, device
	if err := s.persistRecovery(); err != nil {
		return errors.Join(fmt.Errorf("persist network recovery state: %w", err), s.stopNetwork(), s.stopRelay())
	}
	s.relay = s.relayCommand(s.sandbox.Config.AgentPort, sock)
	if err := s.relay.Start(); err != nil {
		return errors.Join(err, s.stopNetwork(), s.stopRelay())
	}
	if _, err := daemon.Mutation(ctx, s.daemon, "StartSandbox", s.sandbox.ID, s.sandbox.Generation, "shim-start-"+s.sandbox.Generation, nil); err != nil {
		return errors.Join(err, s.stopNetwork(), s.stopRelay())
	}
	deadline := time.Now().Add(45 * time.Second)
	for time.Now().Before(deadline) {
		if s.relayOwner == nil {
			err = s.acquireRelaySocketOwner(sock)
			if errors.Is(err, os.ErrNotExist) {
				if err = waitContext(ctx, 100*time.Millisecond); err != nil {
					return errors.Join(err, s.stopNetwork(), s.stopRelay())
				}
				continue
			}
			if err != nil {
				return errors.Join(fmt.Errorf("capture agent relay socket: %w", err), s.stopNetwork(), s.stopRelay())
			}
		}
		client, err := s.dialAgent(ctx, sock)
		if err == nil {
			s.agent = client
			if err = s.negotiateAgentCapabilities(ctx); err != nil {
				_ = s.agent.Close()
				s.agent = nil
				return errors.Join(err, s.stopNetwork(), s.stopRelay())
			}
			if err = s.configureGuestNetwork(ctx, agent.NetworkConfig{
				Name: "mkn0", Address: s.netEndpoint.Address, Gateway: s.netEndpoint.Gateway,
				MTU: s.netEndpoint.MTU, Nameservers: s.netEndpoint.DNS.Nameservers,
			}); err != nil {
				_ = s.agent.Close()
				s.agent = nil
				return errors.Join(err, s.stopNetwork(), s.stopRelay())
			}
			s.startNetworkPump()
			return nil
		}
		if err := waitContext(ctx, 100*time.Millisecond); err != nil {
			return errors.Join(err, s.stopNetwork(), s.stopRelay())
		}
	}
	return errors.Join(errors.New("timed out connecting to child agent"), s.stopNetwork(), s.stopRelay())
}

func (s *service) Start(ctx context.Context, r *taskapi.StartRequest) (*taskapi.StartResponse, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	if r == nil {
		return nil, fmt.Errorf("%w: nil start request", errdefs.ErrInvalidArgument)
	}
	if err := s.validateTaskRequest(r.ID); err != nil {
		return nil, err
	}
	if err := lockContext(ctx, &s.mu); err != nil {
		return nil, err
	}
	p, ok := s.processes[r.ExecID]
	if !ok {
		s.mu.Unlock()
		return nil, errdefs.ErrNotFound
	}
	if p.status != tasktypes.Status_CREATED {
		s.mu.Unlock()
		return nil, errdefs.ErrFailedPrecondition
	}
	if r.ExecID != "" {
		init, exists := s.processes[""]
		if !exists || init.status != tasktypes.Status_RUNNING {
			s.mu.Unlock()
			return nil, errdefs.ErrFailedPrecondition
		}
	}
	if r.ExecID == "" {
		if err := s.ensureNamespaceHolder(); err != nil {
			s.mu.Unlock()
			return nil, err
		}
		if err := s.connectAgent(ctx); err != nil {
			s.mu.Unlock()
			return nil, err
		}
		if err := s.ensureGuestProcessCreated(ctx, "init", "/bundle"); err != nil {
			s.mu.Unlock()
			return nil, err
		}
	}
	processID := r.ExecID
	if processID == "" {
		processID = "init"
	}
	startRequest := map[string]any{"id": processID}
	if p.terminal && p.sizeSet {
		startRequest["width"] = p.width
		startRequest["height"] = p.height
		startRequest["initial_size"] = true
	}
	if err := s.openProcessIO(ctx, p); err != nil {
		s.mu.Unlock()
		return nil, err
	}
	startErr := s.agent.CallContext(ctx, "StartProcess", startRequest, nil)
	var guestState agent.ProcessState
	stateCtx := ctx
	var cancelState context.CancelFunc
	if startErr != nil {
		stateCtx, cancelState = context.WithTimeout(context.WithoutCancel(ctx), 5*time.Second)
	}
	stateErr := s.callAgentWithReconnectContext(stateCtx, "StateProcess", map[string]string{"ID": processID}, &guestState)
	if cancelState != nil {
		cancelState()
	}
	if startErr != nil && stateErr == nil && createdGuestProcess(guestState, processID) == nil {
		closeProcessIO(p)
		s.mu.Unlock()
		return nil, startErr
	}
	guestPID, pidErr := startedGuestProcess(guestState, processID)
	if startErr != nil && (stateErr != nil || pidErr != nil) {
		stateErr = errors.Join(startErr, fmt.Errorf("reconcile failed guest start: %w", errors.Join(stateErr, pidErr)))
	}
	if stateErr != nil || pidErr != nil {
		p.status = tasktypes.Status_RUNNING
		go s.pumpStdin(processID, p)
		go s.waitProcess(processID, r.ExecID, p)
		persistErr := s.persistRecovery()
		killErr := s.killStartedProcess(ctx, processID)
		if stateErr == nil {
			stateErr = pidErr
		}
		s.mu.Unlock()
		if persistErr != nil {
			persistErr = fmt.Errorf("persist unverified started process ownership: %w", persistErr)
		}
		return nil, errors.Join(fmt.Errorf("read started guest process identity: %w", stateErr), persistErr, killErr)
	}
	p.status = tasktypes.Status_RUNNING
	p.pid = guestPID
	pid := s.taskPID(r.ExecID, p)
	go s.pumpStdin(processID, p)
	go s.waitProcess(processID, r.ExecID, p)
	if err := s.persistRecovery(); err != nil {
		killErr := s.killStartedProcess(ctx, processID)
		s.mu.Unlock()
		return nil, errors.Join(fmt.Errorf("persist started process: %w", err), killErr)
	}
	var topic string
	var event any
	if r.ExecID == "" {
		topic, event = ctruntime.TaskStartEventTopic, &eventstypes.TaskStart{ContainerID: s.id, Pid: pid}
	} else {
		topic, event = ctruntime.TaskExecStartedEventTopic, &eventstypes.TaskExecStarted{ContainerID: s.id, ExecID: r.ExecID, Pid: pid}
	}
	if err := s.publish(ctx, topic, event); err != nil {
		killErr := s.killStartedProcess(ctx, processID)
		s.mu.Unlock()
		return nil, errors.Join(err, killErr)
	}
	s.mu.Unlock()
	return &taskapi.StartResponse{Pid: pid}, nil
}

func (s *service) killStartedProcess(ctx context.Context, processID string) error {
	cleanupCtx, cancel := context.WithTimeout(context.WithoutCancel(ctx), 5*time.Second)
	defer cancel()
	operationID, err := newSignalOperationID()
	if err != nil {
		return fmt.Errorf("create cleanup signal identity: %w", err)
	}
	err = s.signalGuestProcess(cleanupCtx, processID, uint32(syscall.SIGKILL), operationID)
	if err == nil {
		err = s.acknowledgeGuestSignal(cleanupCtx, processID, operationID)
	} else {
		var remoteError *agent.RemoteError
		if errors.As(err, &remoteError) {
			err = errors.Join(err, s.acknowledgeGuestSignal(cleanupCtx, processID, operationID))
		}
	}
	if agentNotFound(err) {
		return nil
	}
	if err != nil {
		return fmt.Errorf("kill started guest process: %w", err)
	}
	return nil
}

func inspectProcessIOPath(path string) (os.FileInfo, error) {
	if !filepath.IsAbs(path) || filepath.Clean(path) != path {
		return nil, errors.New("stdio path must be absolute and canonical")
	}
	info, err := os.Lstat(path)
	if err != nil {
		return nil, err
	}
	identity, ok := info.Sys().(*syscall.Stat_t)
	if !ok || identity.Uid != uint32(os.Geteuid()) || identity.Nlink != 1 || info.Mode().Perm()&0077 != 0 ||
		(!info.Mode().IsRegular() && info.Mode()&os.ModeNamedPipe == 0) {
		return nil, errors.New("stdio path must be a private caller-owned single-link FIFO or regular file")
	}
	descriptor, err := unix.Openat2(unix.AT_FDCWD, path, &unix.OpenHow{
		Flags:   uint64(unix.O_PATH | unix.O_CLOEXEC | unix.O_NOFOLLOW),
		Resolve: unix.RESOLVE_NO_SYMLINKS | unix.RESOLVE_NO_MAGICLINKS,
	})
	if err != nil {
		return nil, err
	}
	file := os.NewFile(uintptr(descriptor), path)
	opened, statErr := file.Stat()
	closeErr := file.Close()
	if err = errors.Join(statErr, closeErr); err != nil {
		return nil, err
	}
	if !sameProcessIOIdentity(info, opened) {
		return nil, errors.New("stdio path identity changed while validating")
	}
	return opened, nil
}

func normalizeProcessIOPathAlias(path, alias, target string) (string, error) {
	if !filepath.IsAbs(path) || filepath.Clean(path) != path ||
		!filepath.IsAbs(alias) || filepath.Clean(alias) != alias ||
		!filepath.IsAbs(target) || filepath.Clean(target) != target {
		return "", errors.New("stdio path must be absolute and canonical")
	}
	if !strings.HasPrefix(path, alias+string(os.PathSeparator)) {
		return path, nil
	}
	before, err := os.Lstat(alias)
	if err != nil {
		return "", err
	}
	identity, ok := before.Sys().(*syscall.Stat_t)
	if !ok || before.Mode()&os.ModeSymlink == 0 || identity.Uid != uint32(os.Geteuid()) || identity.Nlink != 1 {
		return "", errors.New("stdio runtime alias is not a caller-owned single-link symlink")
	}
	linked, err := os.Readlink(alias)
	if err != nil {
		return "", err
	}
	after, err := os.Lstat(alias)
	if err != nil || !sameProcessIOIdentity(before, after) {
		return "", errors.New("stdio runtime alias identity changed while validating")
	}
	if linked != target {
		return "", errors.New("stdio runtime alias has an unexpected target")
	}
	return filepath.Join(target, strings.TrimPrefix(path, alias+string(os.PathSeparator))), nil
}

func normalizeProcessIOPath(path string) (string, error) {
	return normalizeProcessIOPathAlias(path, "/var/run", "/run")
}

func sameProcessIOIdentity(before, after os.FileInfo) bool {
	left, leftOK := before.Sys().(*syscall.Stat_t)
	right, rightOK := after.Sys().(*syscall.Stat_t)
	return leftOK && rightOK && os.SameFile(before, after) && before.Mode() == after.Mode() &&
		left.Uid == right.Uid && left.Gid == right.Gid && left.Nlink == right.Nlink && left.Ctim == right.Ctim
}

func inspectBoundProcessIOPath(path string, stdin bool) (processIOIdentity, error) {
	if path == "" {
		return processIOIdentity{}, nil
	}
	info, err := inspectProcessIOPath(path)
	if err != nil {
		return processIOIdentity{}, err
	}
	value, ok := processIOIdentityFromInfo(info)
	if !ok || !validProcessIOIdentity(path, value, stdin) {
		if stdin {
			return processIOIdentity{}, errors.New("stdin must be a private named pipe")
		}
		return processIOIdentity{}, errors.New("output must be a private named pipe or regular file")
	}
	return value, nil
}

type boundProcessIOPaths struct {
	stdin, stdout, stderr                         string
	stdinIdentity, stdoutIdentity, stderrIdentity processIOIdentity
}

func inspectNormalizedProcessIOPath(path string, stdin bool) (string, processIOIdentity, error) {
	if path == "" {
		return "", processIOIdentity{}, nil
	}
	normalized, err := normalizeProcessIOPath(path)
	if err != nil {
		return "", processIOIdentity{}, err
	}
	identity, err := inspectBoundProcessIOPath(normalized, stdin)
	return normalized, identity, err
}

func inspectBoundProcessIOPaths(stdin, stdout, stderr string) (boundProcessIOPaths, error) {
	var result boundProcessIOPaths
	var err error
	result.stdin, result.stdinIdentity, err = inspectNormalizedProcessIOPath(stdin, true)
	if err != nil {
		return boundProcessIOPaths{}, fmt.Errorf("inspect stdin: %w", err)
	}
	result.stdout, result.stdoutIdentity, err = inspectNormalizedProcessIOPath(stdout, false)
	if err != nil {
		return boundProcessIOPaths{}, fmt.Errorf("inspect stdout: %w", err)
	}
	result.stderr, result.stderrIdentity, err = inspectNormalizedProcessIOPath(stderr, false)
	if err != nil {
		return boundProcessIOPaths{}, fmt.Errorf("inspect stderr: %w", err)
	}
	return result, nil
}

func openKnownProcessIOPath(ctx context.Context, path string, flags int, expected processIOIdentity) (*os.File, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	descriptor, err := unix.Openat2(unix.AT_FDCWD, path, &unix.OpenHow{
		Flags:   uint64(flags | unix.O_CLOEXEC | unix.O_NOFOLLOW),
		Resolve: unix.RESOLVE_NO_SYMLINKS | unix.RESOLVE_NO_MAGICLINKS,
	})
	if err != nil {
		return nil, err
	}
	file := os.NewFile(uintptr(descriptor), path)
	opened, err := file.Stat()
	if err != nil {
		_ = file.Close()
		return nil, err
	}
	observed, ok := processIOIdentityFromInfo(opened)
	if !ok || observed != expected {
		_ = file.Close()
		return nil, errors.New("stdio path identity changed while opening")
	}
	if err = ctx.Err(); err != nil {
		_ = file.Close()
		return nil, err
	}
	return file, nil
}

func openOutput(ctx context.Context, path string, expected processIOIdentity) (io.WriteCloser, io.Closer, error) {
	if path == "" {
		return nil, nil, nil
	}
	info, err := inspectProcessIOPath(path)
	if err != nil {
		return nil, nil, err
	}
	observed, ok := processIOIdentityFromInfo(info)
	if !ok || observed != expected {
		return nil, nil, errors.New("stdio path identity changed before opening")
	}
	if info.Mode()&os.ModeNamedPipe == 0 {
		f, err := openKnownProcessIOPath(ctx, path, unix.O_WRONLY|unix.O_APPEND, expected)
		return f, nil, err
	}
	// O_RDWR opens synchronously and keeps a read endpoint present even when
	// the creating client detaches before another client attaches.
	guard, err := openKnownProcessIOPath(ctx, path, unix.O_RDWR|unix.O_NONBLOCK, expected)
	if err != nil {
		return nil, nil, err
	}
	keeper, err := startOutputFIFOKeeper(guard, fifoKeeperGrace)
	if err != nil {
		_ = guard.Close()
		return nil, nil, err
	}
	w, err := openKnownProcessIOPath(ctx, path, unix.O_WRONLY|unix.O_NONBLOCK, expected)
	if err != nil {
		_ = keeper.Close()
		return nil, nil, err
	}
	// A later containerd attach can reopen the same FIFO and consume buffered
	// and future guest output.  The helper retains a duplicate of the guard for
	// a bounded handoff interval if this worker is killed, preventing the
	// existing containerd reader from observing EOF before a replacement worker
	// reopens the FIFO.  It never reads from the FIFO.
	return w, keeper, nil
}

type outputFIFOKeeper struct {
	guard   *os.File
	control *os.File
	command *exec.Cmd
	once    sync.Once
	err     error
}

func startOutputFIFOKeeper(guard *os.File, grace time.Duration) (*outputFIFOKeeper, error) {
	if guard == nil || grace < time.Millisecond || grace > time.Minute {
		return nil, errors.New("invalid output FIFO keeper configuration")
	}
	controlReader, controlWriter, err := os.Pipe()
	if err != nil {
		return nil, fmt.Errorf("create output FIFO keeper control: %w", err)
	}
	self, err := os.Executable()
	if err != nil {
		_ = controlReader.Close()
		_ = controlWriter.Close()
		return nil, fmt.Errorf("resolve output FIFO keeper executable: %w", err)
	}
	command := exec.Command(self, fifoKeeperMode, strconv.FormatInt(grace.Milliseconds(), 10))
	command.ExtraFiles = []*os.File{guard, controlReader}
	if err = command.Start(); err != nil {
		_ = controlReader.Close()
		_ = controlWriter.Close()
		return nil, fmt.Errorf("start output FIFO keeper: %w", err)
	}
	_ = controlReader.Close()
	return &outputFIFOKeeper{guard: guard, control: controlWriter, command: command}, nil
}

func (k *outputFIFOKeeper) Close() error {
	if k == nil {
		return nil
	}
	k.once.Do(func() {
		_, signalErr := k.control.Write([]byte{1})
		controlErr := k.control.Close()
		guardErr := k.guard.Close()
		waitErr := k.command.Wait()
		k.err = errors.Join(signalErr, controlErr, guardErr, waitErr)
	})
	return k.err
}

func runOutputFIFOKeeper(arguments []string) int {
	if len(arguments) != 1 {
		return 2
	}
	milliseconds, err := strconv.ParseInt(arguments[0], 10, 64)
	if err != nil || milliseconds < 1 || milliseconds > int64(time.Minute/time.Millisecond) {
		return 2
	}
	guard := os.NewFile(3, "output-fifo-guard")
	control := os.NewFile(4, "output-fifo-control")
	if guard == nil || control == nil {
		return 2
	}
	defer guard.Close()
	defer control.Close()
	var message [1]byte
	if count, _ := control.Read(message[:]); count == 1 {
		return 0
	}
	// EOF means the worker died without its explicit close notification.  Keep
	// the writer endpoint alive only for the bounded replacement interval.
	time.Sleep(time.Duration(milliseconds) * time.Millisecond)
	return 0
}

func (s *service) openProcessIO(ctx context.Context, p *process) (err error) {
	p.stdoutWriter, p.stdoutGuard, err = openOutput(ctx, p.stdout, p.stdoutIdentity)
	if err != nil {
		return fmt.Errorf("open stdout: %w", err)
	}
	if !p.terminal {
		p.stderrWriter, p.stderrGuard, err = openOutput(ctx, p.stderr, p.stderrIdentity)
		if err != nil {
			closeProcessIO(p)
			return fmt.Errorf("open stderr: %w", err)
		}
	}
	if p.stdin != "" {
		p.stdinReader, err = openKnownProcessIOPath(ctx, p.stdin, unix.O_RDONLY|unix.O_NONBLOCK, p.stdinIdentity)
		if err != nil {
			closeProcessIO(p)
			return fmt.Errorf("open stdin: %w", err)
		}
	}
	return nil
}

func closeProcessIO(p *process) {
	if p.stdinReader != nil {
		_ = p.stdinReader.Close()
		p.stdinReader = nil
	}
	if p.stdoutWriter != nil {
		_ = p.stdoutWriter.Close()
		p.stdoutWriter = nil
	}
	if p.stderrWriter != nil {
		_ = p.stderrWriter.Close()
		p.stderrWriter = nil
	}
	if p.stdoutGuard != nil {
		_ = p.stdoutGuard.Close()
		p.stdoutGuard = nil
	}
	if p.stderrGuard != nil {
		_ = p.stderrGuard.Close()
		p.stderrGuard = nil
	}
}

// probeAgentTransport uses an authenticated, read-only RPC through the common
// reconnect path. The network pump must not dial independently: another agent
// caller may already own the sole connection accepted by a replacement relay.
func (s *service) probeAgentTransport(ctx context.Context) error {
	var capabilities map[string]any
	return s.callAgentWithReconnectContext(ctx, "Capabilities", map[string]any{}, &capabilities)
}

func (s *service) pumpStdin(agentID string, p *process) {
	reader := p.stdinReader
	if reader != nil {
		defer func() {
			s.mu.Lock()
			_ = reader.Close()
			p.stdinReader = nil
			pending := len(p.stdinPending) != 0
			s.mu.Unlock()
			if !pending {
				s.retryPendingStdinClose(agentID, p)
			}
		}()
	}
	if err := s.deliverPendingStdin(agentID, p); err != nil {
		fmt.Fprintf(os.Stderr, "multikernel stdin: %v\n", err)
		return
	}
	if reader == nil {
		s.retryPendingStdinClose(agentID, p)
		return
	}
	buffer := make([]byte, 32<<10)
	for {
		s.mu.Lock()
		closeRequested := p.stdinClosed
		closeAcknowledged := p.stdinCloseAcked
		s.mu.Unlock()
		if closeRequested {
			if !closeAcknowledged {
				s.retryPendingStdinClose(agentID, p)
			}
			return
		}
		n, err := reader.Read(buffer)
		if n > 0 {
			s.mu.Lock()
			stopped := p.status != tasktypes.Status_RUNNING && p.status != tasktypes.Status_PAUSED
			if !stopped {
				p.stdinPending = append(p.stdinPending[:0], buffer[:n]...)
				if persistErr := s.persistRecovery(); persistErr != nil {
					stopped = true
					fmt.Fprintf(os.Stderr, "multikernel stdin intent: %v\n", persistErr)
				}
			}
			s.mu.Unlock()
			if stopped {
				return
			}
			if callErr := s.deliverPendingStdin(agentID, p); callErr != nil {
				fmt.Fprintf(os.Stderr, "multikernel stdin: %v\n", callErr)
				return
			}
		}
		if err != nil && !errors.Is(err, io.EOF) && !errors.Is(err, syscall.EAGAIN) && !errors.Is(err, syscall.EWOULDBLOCK) {
			return
		}
		if n == 0 {
			s.mu.Lock()
			closeRequested := p.stdinClosed
			closeAcknowledged := p.stdinCloseAcked
			s.mu.Unlock()
			if closeRequested && !closeAcknowledged {
				s.retryPendingStdinClose(agentID, p)
				return
			}
			// FIFO EOF can also mean that an attaching client disconnected.
			// Keep the guest side open until CloseIO explicitly requests EOF.
			time.Sleep(10 * time.Millisecond)
		}
	}
}

func (s *service) deliverPendingStdin(agentID string, p *process) error {
	s.mu.Lock()
	offset := p.stdinOffset
	data := append([]byte(nil), p.stdinPending...)
	s.mu.Unlock()
	if len(data) == 0 {
		return nil
	}
	var response struct {
		Offset uint64 `json:"offset"`
	}
	if err := s.callAgentWithReconnect("WriteProcess", map[string]any{
		"id": agentID, "offset": offset, "data": data,
	}, &response); err != nil {
		return err
	}
	if uint64(len(data)) > ^uint64(0)-offset || response.Offset != offset+uint64(len(data)) {
		return errors.New("guest acknowledged an invalid stdin offset")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if p.stdinOffset != offset || !bytes.Equal(p.stdinPending, data) {
		return errors.New("pending stdin identity changed during guest acknowledgement")
	}
	p.stdinOffset, p.stdinPending = response.Offset, nil
	if err := s.persistRecovery(); err != nil {
		p.stdinOffset, p.stdinPending = offset, data
		return fmt.Errorf("persist acknowledged stdin offset: %w", err)
	}
	return nil
}

func (s *service) retryPendingStdinClose(agentID string, p *process) {
	for {
		s.mu.Lock()
		requested := p.stdinClosed && !p.stdinCloseAcked
		stopped := p.status == tasktypes.Status_STOPPED
		s.mu.Unlock()
		if !requested || stopped {
			return
		}
		if err := s.acknowledgeStdinClose(context.Background(), agentID, p); err == nil {
			return
		} else {
			fmt.Fprintf(os.Stderr, "multikernel close stdin: %v\n", err)
		}
		time.Sleep(100 * time.Millisecond)
	}
}

func (s *service) acknowledgeStdinClose(ctx context.Context, agentID string, p *process) error {
	s.mu.Lock()
	if p.stdinCloseAcked {
		s.mu.Unlock()
		return nil
	}
	connected := s.agent != nil
	s.mu.Unlock()
	if !connected {
		return errdefs.ErrFailedPrecondition
	}
	if err := s.callAgentWithReconnectContext(ctx, "CloseProcessStdin", map[string]string{"id": agentID}, nil); err != nil {
		return err
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if p.stdinCloseAcked {
		return nil
	}
	p.stdinCloseAcked = true
	if err := s.persistRecovery(); err != nil {
		p.stdinCloseAcked = false
		return fmt.Errorf("persist acknowledged stdin close: %w", err)
	}
	return nil
}

func (s *service) waitProcess(agentID, execID string, p *process) {
	var state agent.ProcessState
	var pid, exit uint32
	var err error
	stdoutTruncationReported, stderrTruncationReported := false, false
	for {
		var output processOutput
		err = s.readProcessOutput(agentID, p.stdoutOffset, p.stderrOffset, &output)
		if err != nil {
			fmt.Fprintf(os.Stderr, "multikernel output monitor: %v\n", err)
			time.Sleep(100 * time.Millisecond)
			continue
		}
		now := time.Now()
		stdoutAdvance, stdoutDropped := deliverOutput(p.stdoutWriter, output.Stdout, &p.stdoutPressure, now, 30*time.Second)
		stderrAdvance, stderrDropped := deliverOutput(p.stderrWriter, output.Stderr, &p.stderrPressure, now, 30*time.Second)
		s.mu.Lock()
		oldStdoutOffset, oldStderrOffset := p.stdoutOffset, p.stderrOffset
		if stdoutAdvance {
			p.stdoutOffset = output.StdoutOffset
		}
		if stderrAdvance {
			p.stderrOffset = output.StderrOffset
		}
		stdoutChanged := p.stdoutOffset != oldStdoutOffset
		stderrChanged := p.stderrOffset != oldStderrOffset
		var persistErr error
		if stdoutChanged || stderrChanged {
			persistErr = s.persistRecovery()
			if persistErr != nil {
				p.stdoutOffset, p.stderrOffset = oldStdoutOffset, oldStderrOffset
				if stdoutChanged {
					stdoutAdvance = false
				}
				if stderrChanged {
					stderrAdvance = false
				}
			}
		}
		s.mu.Unlock()
		if persistErr != nil {
			fmt.Fprintf(os.Stderr, "multikernel output acknowledgement: %v\n", persistErr)
		}
		if stdoutDropped {
			fmt.Fprintf(os.Stderr, "multikernel stdout: discarded %d bytes after 30s output pressure\n", len(output.Stdout))
		}
		if stderrDropped {
			fmt.Fprintf(os.Stderr, "multikernel stderr: discarded %d bytes after 30s output pressure\n", len(output.Stderr))
		}
		if output.StdoutTruncated && !stdoutTruncationReported {
			fmt.Fprintln(os.Stderr, "multikernel stdout: guest retention limit discarded output before delivery")
			stdoutTruncationReported = true
		}
		if output.StderrTruncated && !stderrTruncationReported {
			fmt.Fprintln(os.Stderr, "multikernel stderr: guest retention limit discarded output before delivery")
			stderrTruncationReported = true
		}
		if !stdoutAdvance || !stderrAdvance {
			time.Sleep(10 * time.Millisecond)
		}
		if output.Status == "STOPPED" && len(output.Stdout) == 0 && len(output.Stderr) == 0 {
			err = s.callAgentWithReconnect("WaitProcess", map[string]string{"ID": agentID}, &state)
			if err != nil {
				fmt.Fprintf(os.Stderr, "multikernel process wait: %v\n", err)
				time.Sleep(100 * time.Millisecond)
				continue
			}
			pid, exit, err = stoppedGuestProcess(state, agentID, p.pid)
			if err != nil {
				fmt.Fprintf(os.Stderr, "multikernel process wait validation: %v\n", err)
				time.Sleep(100 * time.Millisecond)
				continue
			}
			break
		}
		if len(output.Stdout) == 0 && len(output.Stderr) == 0 {
			time.Sleep(20 * time.Millisecond)
		}
	}
	now := time.Now().UTC()
	for {
		s.mu.Lock()
		closeProcessIO(p)
		oldStatus, oldPID, oldExit, oldExited := p.status, p.pid, p.exit, p.exited
		oldPending := append([]byte(nil), p.stdinPending...)
		oldSignal, oldSignalOperation, oldSignalAck := p.pendingSignal, p.pendingSignalOperation, p.pendingSignalAcknowledgement
		p.status, p.pid, p.exit, p.exited, p.stdinPending = tasktypes.Status_STOPPED, pid, exit, now, nil
		if p.pendingSignalOperation != "" {
			p.pendingSignalAcknowledgement = true
		}
		if err = s.persistRecovery(); err == nil {
			break
		}
		p.status, p.pid, p.exit, p.exited, p.stdinPending = oldStatus, oldPID, oldExit, oldExited, oldPending
		p.pendingSignal, p.pendingSignalOperation, p.pendingSignalAcknowledgement = oldSignal, oldSignalOperation, oldSignalAck
		s.mu.Unlock()
		fmt.Fprintf(os.Stderr, "multikernel exit state persistence: %v\n", err)
		time.Sleep(100 * time.Millisecond)
	}
	if p.pendingSignalOperation != "" {
		operationID, signal := p.pendingSignalOperation, p.pendingSignal
		ackCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		ackErr := s.acknowledgeGuestSignal(ackCtx, agentID, operationID)
		cancel()
		if ackErr != nil {
			fmt.Fprintf(os.Stderr, "multikernel signal acknowledgement: %v\n", ackErr)
		} else {
			p.pendingSignal, p.pendingSignalOperation, p.pendingSignalAcknowledgement = 0, "", false
			if err = s.persistRecovery(); err != nil {
				p.pendingSignal, p.pendingSignalOperation, p.pendingSignalAcknowledgement = signal, operationID, true
				fmt.Fprintf(os.Stderr, "multikernel signal acknowledgement persistence: %v\n", err)
			}
		}
	}
	if err := s.publishExit(context.Background(), execID, p); err != nil {
		fmt.Fprintf(os.Stderr, "multikernel exit event queue: %v\n", err)
	} else {
		p.exitEventQueued = true
		if err := s.persistRecovery(); err != nil {
			p.exitEventQueued = false
			fmt.Fprintf(os.Stderr, "multikernel exit event acknowledgement: %v\n", err)
		}
	}
	close(p.done)
	s.mu.Unlock()
}

func (s *service) readProcessOutput(agentID string, stdoutOffset, stderrOffset uint64, output *processOutput) error {
	if err := s.callAgentWithReconnect("ReadProcessOutput", map[string]any{
		"id": agentID, "stdout_offset": stdoutOffset, "stderr_offset": stderrOffset, "limit": uint64(processOutputChunk),
	}, output); err != nil {
		return err
	}
	return validateProcessOutput(stdoutOffset, stderrOffset, *output)
}

func validateProcessOutput(stdoutOffset, stderrOffset uint64, output processOutput) error {
	if len(output.Stdout) > processOutputChunk || len(output.Stderr) > processOutputChunk {
		return errors.New("guest output exceeded the requested atomic chunk")
	}
	exactOffset := func(current, next uint64, data []byte) bool {
		return uint64(len(data)) <= ^uint64(0)-current && next == current+uint64(len(data))
	}
	if !exactOffset(stdoutOffset, output.StdoutOffset, output.Stdout) ||
		!exactOffset(stderrOffset, output.StderrOffset, output.Stderr) {
		return errors.New("guest output returned a non-contiguous offset")
	}
	if output.Status != "RUNNING" && output.Status != "STOPPED" {
		return errors.New("guest output returned an invalid process state")
	}
	return nil
}

func (s *service) callAgentWithReconnect(method string, request, output any) error {
	return s.callAgentWithReconnectContext(context.Background(), method, request, output)
}

func (s *service) callAgentWithReconnectContext(parent context.Context, method string, request, output any) error {
	timeout := s.ioCallTimeout
	if timeout <= 0 {
		timeout = defaultAgentIOCallTimeout
	}
	ctx, cancel := context.WithTimeout(parent, timeout)
	defer cancel()
	var lastErr error
	for {
		if err := s.agent.CallContext(ctx, method, request, output); err == nil {
			return nil
		} else {
			lastErr = err
		}
		var remoteError *agent.RemoteError
		relaySocket, relayGeneration := s.relaySnapshot()
		if errors.As(lastErr, &remoteError) || relaySocket == "" || ctx.Err() != nil {
			return lastErr
		}
		if err := s.agent.ReconnectContext(ctx, relaySocket); err != nil {
			lastErr = errors.Join(lastErr, fmt.Errorf("reconnect guest agent transport: %w", err))
			if _, replaceErr := s.replaceExitedRelay(ctx, relayGeneration); replaceErr != nil {
				lastErr = errors.Join(lastErr, replaceErr)
			}
		}
		if err := waitContext(ctx, 50*time.Millisecond); err != nil {
			return errors.Join(lastErr, err)
		}
	}
}

func (s *service) quiesceAndShutdownGuest(ctx context.Context) error {
	var quiesced guestQuiesceResponse
	if err := s.callAgentWithReconnectContext(ctx, "Quiesce", map[string]any{}, &quiesced); err != nil {
		return fmt.Errorf("quiesce guest agent: %w", err)
	}
	if quiesced.Status != "quiesced" {
		return fmt.Errorf("quiesce guest agent: unexpected status %q", quiesced.Status)
	}
	var shutdown guestQuiesceResponse
	err := s.agent.CallContext(ctx, "Shutdown", map[string]any{}, &shutdown)
	if err != nil {
		if ctxErr := ctx.Err(); ctxErr != nil {
			return ctxErr
		}
		var remote *agent.RemoteError
		if errors.As(err, &remote) {
			return fmt.Errorf("shutdown guest agent: %w", err)
		}
		// Quiesce is the authenticated commit point. After it succeeds, a
		// transport loss during terminal Shutdown is safe to complete locally:
		// the guest is sealed against new mutations and storage is already quiet.
		return nil
	}
	if shutdown.Status != "quiesced" {
		return fmt.Errorf("shutdown guest agent: unexpected status %q", shutdown.Status)
	}
	return nil
}

func (s *service) deleteGuestProcess(ctx context.Context, id string) error {
	err := s.callAgentWithReconnectContext(ctx, "DeleteProcess", map[string]string{"ID": id}, nil)
	if err != nil && !agentNotFound(err) {
		return fmt.Errorf("delete guest process: %w", err)
	}
	return nil
}

func (s *service) resizeGuestProcess(ctx context.Context, id string, width, height uint32) error {
	return s.callAgentWithReconnectContext(ctx, "ResizeProcess", map[string]any{
		"id": id, "width": width, "height": height,
	}, nil)
}

func (s *service) signalGuestProcess(ctx context.Context, id string, signal uint32, operationID string) error {
	return s.callAgentWithReconnectContext(ctx, "SignalProcess", map[string]any{
		"ID": id, "Signal": strconv.FormatUint(uint64(signal), 10), "operation_id": operationID,
	}, nil)
}

func (s *service) acknowledgeGuestSignal(ctx context.Context, id, operationID string) error {
	return s.callAgentWithReconnectContext(ctx, "AcknowledgeSignal", map[string]any{
		"ID": id, "operation_id": operationID,
	}, nil)
}

func (s *service) applyGuestSignal(ctx context.Context, id string, signal uint32) error {
	operationID, err := newSignalOperationID()
	if err != nil {
		return fmt.Errorf("create process signal identity: %w", err)
	}
	if err = s.signalGuestProcess(ctx, id, signal, operationID); err != nil {
		var remoteError *agent.RemoteError
		if !errors.As(err, &remoteError) {
			return err
		}
		ackCtx, cancel := context.WithTimeout(context.WithoutCancel(ctx), 5*time.Second)
		defer cancel()
		return errors.Join(err, s.acknowledgeGuestSignal(ackCtx, id, operationID))
	}
	ackCtx, cancel := context.WithTimeout(context.WithoutCancel(ctx), 5*time.Second)
	defer cancel()
	return s.acknowledgeGuestSignal(ackCtx, id, operationID)
}

// deliverOutput advances a guest offset only after the complete chunk reaches
// its destination. Chunks are capped at Linux PIPE_BUF by waitProcess, making
// nonblocking FIFO writes all-or-nothing. A permanently absent/slow consumer
// cannot retain the shim forever: after the documented bound the chunk is
// deliberately discarded and acknowledged with a diagnostic.
func deliverOutput(writer io.Writer, data []byte, pressure *time.Time, now time.Time, timeout time.Duration) (advance, dropped bool) {
	if len(data) == 0 || writer == nil {
		*pressure = time.Time{}
		return true, false
	}
	n, err := writer.Write(data)
	if err == nil && n == len(data) {
		*pressure = time.Time{}
		return true, false
	}
	if pressure.IsZero() {
		*pressure = now
	}
	if timeout > 0 && now.Sub(*pressure) >= timeout {
		*pressure = time.Time{}
		return true, true
	}
	return false, false
}

func (s *service) publishExit(ctx context.Context, execID string, p *process) error {
	eventID := execID
	if eventID == "" {
		eventID = s.id
	}
	return s.publish(ctx, ctruntime.TaskExitEventTopic, &eventstypes.TaskExit{ContainerID: s.id, ID: eventID,
		Pid: s.taskPID(execID, p), ExitStatus: p.exit, ExitedAt: timestamppb.New(p.exited)})
}

func (s *service) State(ctx context.Context, r *taskapi.StateRequest) (*taskapi.StateResponse, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	if r == nil {
		return nil, fmt.Errorf("%w: nil state request", errdefs.ErrInvalidArgument)
	}
	if err := s.validateTaskRequest(r.ID); err != nil {
		return nil, err
	}
	if err := lockContext(ctx, &s.mu); err != nil {
		return nil, err
	}
	defer s.mu.Unlock()
	p, ok := s.processes[r.ExecID]
	if !ok {
		return nil, errdefs.ErrNotFound
	}
	return &taskapi.StateResponse{ID: s.id, Bundle: s.bundle, Pid: s.taskPID(r.ExecID, p), Status: p.status, Stdin: p.stdin, Stdout: p.stdout, Stderr: p.stderr, ExitStatus: p.exit, ExitedAt: timestamppb.New(p.exited), ExecID: r.ExecID}, nil
}

func (s *service) Wait(ctx context.Context, r *taskapi.WaitRequest) (*taskapi.WaitResponse, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	if r == nil {
		return nil, fmt.Errorf("%w: nil wait request", errdefs.ErrInvalidArgument)
	}
	if err := s.validateTaskRequest(r.ID); err != nil {
		return nil, err
	}
	if err := lockContext(ctx, &s.mu); err != nil {
		return nil, err
	}
	p, ok := s.processes[r.ExecID]
	if !ok {
		s.mu.Unlock()
		return nil, errdefs.ErrNotFound
	}
	done := p.done
	s.mu.Unlock()
	select {
	case <-ctx.Done():
		return nil, ctx.Err()
	case <-done:
	}
	if err := lockContext(ctx, &s.mu); err != nil {
		return nil, err
	}
	defer s.mu.Unlock()
	return &taskapi.WaitResponse{ExitStatus: p.exit, ExitedAt: timestamppb.New(p.exited)}, nil
}

func (s *service) Kill(ctx context.Context, r *taskapi.KillRequest) (*emptypb.Empty, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	if r == nil {
		return nil, fmt.Errorf("%w: nil kill request", errdefs.ErrInvalidArgument)
	}
	if err := s.validateTaskRequest(r.ID); err != nil {
		return nil, err
	}
	if err := lockContext(ctx, &s.mu); err != nil {
		return nil, err
	}
	p, ok := s.processes[r.ExecID]
	if !ok {
		s.mu.Unlock()
		return nil, errdefs.ErrNotFound
	}
	if p.status != tasktypes.Status_RUNNING && p.status != tasktypes.Status_PAUSED {
		s.mu.Unlock()
		return nil, errdefs.ErrFailedPrecondition
	}
	if s.agent == nil {
		s.mu.Unlock()
		return nil, errdefs.ErrFailedPrecondition
	}
	operationID := p.pendingSignalOperation
	if operationID != "" && p.pendingSignal != r.Signal {
		s.mu.Unlock()
		return nil, fmt.Errorf("%w: a different signal remains unacknowledged", errdefs.ErrFailedPrecondition)
	}
	if operationID == "" {
		var err error
		operationID, err = newSignalOperationID()
		if err != nil {
			s.mu.Unlock()
			return nil, fmt.Errorf("create signal operation identity: %w", err)
		}
		p.pendingSignal, p.pendingSignalOperation, p.pendingSignalAcknowledgement = r.Signal, operationID, false
		if err = s.persistRecovery(); err != nil {
			p.pendingSignal, p.pendingSignalOperation = 0, ""
			s.mu.Unlock()
			return nil, fmt.Errorf("persist signal intent: %w", err)
		}
	}
	resultObserved := p.pendingSignalAcknowledgement
	s.mu.Unlock()
	id := r.ExecID
	if id == "" {
		id = "init"
	}
	var signalErr error
	if !resultObserved {
		signalErr = s.signalGuestProcess(ctx, id, r.Signal, operationID)
		var remoteError *agent.RemoteError
		if signalErr != nil && !errors.As(signalErr, &remoteError) {
			return nil, signalErr
		}
		s.mu.Lock()
		if current, exists := s.processes[r.ExecID]; exists && current == p && current.pendingSignalOperation == operationID {
			current.pendingSignalAcknowledgement = true
			if err := s.persistRecovery(); err != nil {
				current.pendingSignalAcknowledgement = false
				s.mu.Unlock()
				return nil, errors.Join(signalErr, fmt.Errorf("persist observed signal result: %w", err))
			}
		}
		s.mu.Unlock()
	}
	ackCtx, cancel := context.WithTimeout(context.WithoutCancel(ctx), 5*time.Second)
	ackErr := s.acknowledgeGuestSignal(ackCtx, id, operationID)
	cancel()
	if ackErr != nil {
		return nil, errors.Join(signalErr, fmt.Errorf("acknowledge guest signal result: %w", ackErr))
	}
	s.mu.Lock()
	var clearErr error
	if current, exists := s.processes[r.ExecID]; exists && current == p && current.pendingSignalOperation == operationID {
		current.pendingSignal, current.pendingSignalOperation, current.pendingSignalAcknowledgement = 0, "", false
		if clearErr = s.persistRecovery(); clearErr != nil {
			current.pendingSignal, current.pendingSignalOperation, current.pendingSignalAcknowledgement = r.Signal, operationID, true
		}
	}
	s.mu.Unlock()
	if clearErr != nil {
		clearErr = fmt.Errorf("persist retired signal intent: %w", clearErr)
	}
	if err := errors.Join(signalErr, clearErr); err != nil {
		return nil, err
	}
	return &emptypb.Empty{}, nil
}

func processSpec(p *specs.Process) agent.ProcessSpec {
	gids := make([]uint32, len(p.User.AdditionalGids))
	copy(gids, p.User.AdditionalGids)
	result := agent.ProcessSpec{Terminal: p.Terminal, User: agent.User{UID: p.User.UID, GID: p.User.GID, AdditionalGids: gids}, Args: p.Args, Env: p.Env, Cwd: p.Cwd}
	if p.ConsoleSize != nil {
		result.ConsoleSize = &agent.ConsoleSize{Width: uint32(p.ConsoleSize.Width), Height: uint32(p.ConsoleSize.Height)}
	}
	if p.NoNewPrivileges {
		value := true
		result.NoNewPrivileges = &value
	}
	for _, limit := range p.Rlimits {
		result.Rlimits = append(result.Rlimits, agent.Rlimit{Type: limit.Type, Hard: limit.Hard, Soft: limit.Soft})
	}
	if p.Capabilities != nil {
		result.Capabilities = map[string][]string{
			"bounding": append([]string(nil), p.Capabilities.Bounding...), "effective": append([]string(nil), p.Capabilities.Effective...),
			"inheritable": append([]string(nil), p.Capabilities.Inheritable...), "permitted": append([]string(nil), p.Capabilities.Permitted...),
			"ambient": append([]string(nil), p.Capabilities.Ambient...),
		}
	}
	return result
}

func validateExecProcess(p *specs.Process) error {
	if p == nil || len(p.Args) == 0 || p.Cwd == "" || !filepath.IsAbs(p.Cwd) {
		return fmt.Errorf("%w: exec args and absolute cwd are required", errdefs.ErrInvalidArgument)
	}
	var unsupported []string
	if p.ConsoleSize != nil && (!p.Terminal || p.ConsoleSize.Width > 65535 || p.ConsoleSize.Height > 65535) {
		return fmt.Errorf("%w: console size requires a terminal and dimensions within the Linux PTY limit", errdefs.ErrInvalidArgument)
	}
	if p.CommandLine != "" {
		unsupported = append(unsupported, "commandLine")
	}
	// Docker copies these two container-level opt-out values into exec specs.
	// They request no child policy: AppArmor is explicitly unconfined and a
	// zero OOM adjustment is the kernel default.  Omit only those exact values
	// from the guest projection, matching the validated init-process contract.
	if p.ApparmorProfile != "" && p.ApparmorProfile != "unconfined" {
		unsupported = append(unsupported, "apparmorProfile")
	}
	if p.OOMScoreAdj != nil && *p.OOMScoreAdj != 0 {
		unsupported = append(unsupported, "oomScoreAdj")
	}
	if p.Scheduler != nil {
		unsupported = append(unsupported, "scheduler")
	}
	if p.SelinuxLabel != "" {
		unsupported = append(unsupported, "selinuxLabel")
	}
	if p.IOPriority != nil {
		unsupported = append(unsupported, "ioPriority")
	}
	if p.User.Umask != nil {
		unsupported = append(unsupported, "umask")
	}
	if p.User.Username != "" {
		unsupported = append(unsupported, "username")
	}
	if len(unsupported) != 0 {
		return fmt.Errorf("%w: unsupported exec process field(s): %s", errdefs.ErrNotImplemented, strings.Join(unsupported, ", "))
	}
	return nil
}

func agentNotFound(err error) bool {
	var remote *agent.RemoteError
	return errors.As(err, &remote) && remote.Failure.Code == "NOT_FOUND"
}

func (s *service) ensureGuestProcessCreated(ctx context.Context, processID, bundle string) error {
	var state agent.ProcessState
	err := s.callAgentWithReconnectContext(ctx, "StateProcess", map[string]string{"ID": processID}, &state)
	if err == nil {
		if err = createdGuestProcess(state, processID); err != nil {
			return fmt.Errorf("reconcile created guest process: %w", err)
		}
		return nil
	}
	if !agentNotFound(err) {
		return fmt.Errorf("inspect created guest process: %w", err)
	}
	createErr := s.agent.CallContext(ctx, "CreateProcess", map[string]any{"ID": processID, "Bundle": bundle}, nil)
	if createErr == nil {
		return nil
	}
	var remoteError *agent.RemoteError
	if errors.As(createErr, &remoteError) {
		return fmt.Errorf("create guest process: %w", createErr)
	}
	reconcileCtx, cancel := context.WithTimeout(context.WithoutCancel(ctx), 5*time.Second)
	defer cancel()
	state = agent.ProcessState{}
	reconcileErr := s.callAgentWithReconnectContext(reconcileCtx, "StateProcess", map[string]string{"ID": processID}, &state)
	if reconcileErr == nil {
		reconcileErr = createdGuestProcess(state, processID)
	}
	if reconcileErr != nil {
		return errors.Join(fmt.Errorf("create guest process: %w", createErr),
			fmt.Errorf("reconcile guest process creation: %w", reconcileErr))
	}
	return nil
}

func (s *service) rollbackExec(ctx context.Context, execID string) error {
	cleanupCtx, cancel := context.WithTimeout(context.WithoutCancel(ctx), 5*time.Second)
	defer cancel()
	deleteErr := s.deleteGuestProcess(cleanupCtx, execID)
	s.mu.Lock()
	if deleteErr == nil {
		delete(s.processes, execID)
	}
	persistErr := s.persistRecovery()
	s.mu.Unlock()
	return errors.Join(deleteErr, persistErr)
}

func (s *service) Exec(ctx context.Context, r *taskapi.ExecProcessRequest) (*emptypb.Empty, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	if r == nil {
		return nil, fmt.Errorf("%w: nil exec request", errdefs.ErrInvalidArgument)
	}
	if err := s.validateTaskRequest(r.ID); err != nil {
		return nil, err
	}
	if !guestProcessIdentifier.MatchString(r.ExecID) {
		return nil, errdefs.ErrInvalidArgument
	}
	boundIO, err := inspectBoundProcessIOPaths(r.Stdin, r.Stdout, r.Stderr)
	if err != nil {
		return nil, fmt.Errorf("%w: %v", errdefs.ErrInvalidArgument, err)
	}
	if err := lockContext(ctx, &s.mu); err != nil {
		return nil, err
	}
	client := s.agent
	s.mu.Unlock()
	if client == nil {
		return nil, errdefs.ErrFailedPrecondition
	}
	v, err := typeurl.UnmarshalAny(r.Spec)
	if err != nil {
		return nil, err
	}
	spec, ok := v.(*specs.Process)
	if !ok {
		return nil, errdefs.ErrInvalidArgument
	}
	if err = validateExecProcess(spec); err != nil {
		return nil, err
	}
	if err := lockContext(ctx, &s.mu); err != nil {
		return nil, err
	}
	init, initExists := s.processes[""]
	if !initExists || init.status != tasktypes.Status_RUNNING {
		s.mu.Unlock()
		return nil, errdefs.ErrFailedPrecondition
	}
	if _, exists := s.processes[r.ExecID]; exists {
		s.mu.Unlock()
		return nil, errdefs.ErrAlreadyExists
	}
	p := &process{id: r.ExecID, stdin: boundIO.stdin, stdout: boundIO.stdout, stderr: boundIO.stderr,
		stdinIdentity: boundIO.stdinIdentity, stdoutIdentity: boundIO.stdoutIdentity, stderrIdentity: boundIO.stderrIdentity,
		terminal: r.Terminal, status: tasktypes.Status_CREATED, done: make(chan struct{})}
	s.processes[r.ExecID] = p
	if err = s.persistRecovery(); err != nil {
		delete(s.processes, r.ExecID)
		s.mu.Unlock()
		return nil, fmt.Errorf("persist exec creation intent: %w", err)
	}
	s.mu.Unlock()
	if createErr := client.CallContext(ctx, "ExecProcess", map[string]any{"id": r.ExecID, "parent_id": "init", "spec": processSpec(spec)}, nil); createErr != nil {
		reconcileCtx, cancel := context.WithTimeout(context.WithoutCancel(ctx), 5*time.Second)
		var state agent.ProcessState
		stateErr := s.callAgentWithReconnectContext(reconcileCtx, "StateProcess", map[string]string{"ID": r.ExecID}, &state)
		cancel()
		stateValidationErr := stateErr
		if stateValidationErr == nil {
			stateValidationErr = createdGuestProcess(state, r.ExecID)
		}
		if stateValidationErr != nil {
			rollbackErr := s.rollbackExec(ctx, r.ExecID)
			return nil, errors.Join(fmt.Errorf("create guest exec: %w", createErr),
				fmt.Errorf("reconcile guest exec creation: %w", stateValidationErr), rollbackErr)
		}
	}
	s.mu.Lock()
	err = s.persistRecovery()
	s.mu.Unlock()
	if err != nil {
		rollbackErr := s.rollbackExec(ctx, r.ExecID)
		return nil, errors.Join(fmt.Errorf("persist exec process: %w", err), rollbackErr)
	}
	if err = s.publish(ctx, ctruntime.TaskExecAddedEventTopic, &eventstypes.TaskExecAdded{ContainerID: s.id, ExecID: r.ExecID}); err != nil {
		return nil, errors.Join(err, s.rollbackExec(ctx, r.ExecID))
	}
	return &emptypb.Empty{}, nil
}

func (s *service) Delete(ctx context.Context, r *taskapi.DeleteRequest) (*taskapi.DeleteResponse, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	if r == nil {
		return nil, fmt.Errorf("%w: nil delete request", errdefs.ErrInvalidArgument)
	}
	if err := s.validateTaskRequest(r.ID); err != nil {
		return nil, err
	}
	if err := lockContext(ctx, &s.mu); err != nil {
		return nil, err
	}
	p, ok := s.processes[r.ExecID]
	if !ok {
		s.mu.Unlock()
		return nil, errdefs.ErrNotFound
	}
	if p.status == tasktypes.Status_RUNNING || p.status == tasktypes.Status_PAUSED {
		s.mu.Unlock()
		return nil, errdefs.ErrFailedPrecondition
	}
	if p.deleting {
		s.mu.Unlock()
		return nil, fmt.Errorf("%w: process deletion is already in progress", errdefs.ErrFailedPrecondition)
	}
	if r.ExecID == "" && len(s.processes) != 1 {
		s.mu.Unlock()
		return nil, fmt.Errorf("%w: delete exec processes before deleting init", errdefs.ErrFailedPrecondition)
	}
	if p.status == tasktypes.Status_STOPPED && !p.exitEventQueued {
		if err := s.publishExit(ctx, r.ExecID, p); err != nil {
			s.mu.Unlock()
			return nil, fmt.Errorf("queue missing exit event before delete: %w", err)
		}
		p.exitEventQueued = true
		if err := s.persistRecovery(); err != nil {
			s.mu.Unlock()
			return nil, fmt.Errorf("persist exit event ordering before delete: %w", err)
		}
	}
	p.deleting = true
	responsePID := s.taskPID(r.ExecID, p)
	client := s.agent
	s.mu.Unlock()
	abort := func(err error) (*taskapi.DeleteResponse, error) {
		s.mu.Lock()
		p.deleting = false
		s.mu.Unlock()
		return nil, err
	}
	id := r.ExecID
	if id == "" {
		id = "init"
	}
	if client != nil {
		if err := s.deleteGuestProcess(ctx, id); err != nil {
			return abort(err)
		}
	}
	if r.ExecID == "" {
		var teardownNotes []error
		var hostFailures []error
		if client != nil {
			if err := s.stopNetwork(); err != nil {
				teardownNotes = append(teardownNotes, err)
			}
			if err := s.quiesceAndShutdownGuest(ctx); err != nil {
				teardownNotes = append(teardownNotes, err)
			}
			closeErr := client.Close()
			s.mu.Lock()
			s.agent = nil
			s.mu.Unlock()
			if closeErr != nil {
				teardownNotes = append(teardownNotes, fmt.Errorf("close guest agent: %w", closeErr))
			}
		}
		if err := s.stopNamespaceHolder(); err != nil {
			hostFailures = append(hostFailures, fmt.Errorf("stop network namespace holder: %w", err))
		}
		if err := s.stopRelay(); err != nil {
			hostFailures = append(hostFailures, fmt.Errorf("stop agent relay: %w", err))
		}
		if err := s.releaseNetwork(ctx); err != nil {
			hostFailures = append(hostFailures, fmt.Errorf("release primary network endpoint: %w", err))
		}
		if _, err := daemon.Mutation(ctx, s.daemon, "StopSandbox", s.sandbox.ID, s.sandbox.Generation, "shim-stop-"+s.sandbox.Generation, nil); err != nil && !daemonErrorCode(err, "NOT_FOUND") {
			hostFailures = append(hostFailures, fmt.Errorf("stop sandbox: %w", err))
		}
		if _, err := daemon.Mutation(ctx, s.daemon, "DeleteSandbox", s.sandbox.ID, s.sandbox.Generation, "shim-delete-"+s.sandbox.Generation, nil); err != nil && !daemonErrorCode(err, "NOT_FOUND") {
			hostFailures = append(hostFailures, fmt.Errorf("delete sandbox: %w", err))
		}
		if len(hostFailures) != 0 {
			return abort(errors.Join(append(hostFailures, teardownNotes...)...))
		}
		if note := errors.Join(teardownNotes...); note != nil {
			fmt.Fprintf(os.Stderr, "multikernel shim: guest teardown completed through sandbox deletion with warnings: %v\n", note)
		}
	}
	s.mu.Lock()
	deleteQueued := p.deleteEventQueued
	s.mu.Unlock()
	if !deleteQueued {
		response := &taskapi.DeleteResponse{Pid: responsePID, ExitStatus: p.exit, ExitedAt: timestamppb.New(p.exited)}
		if err := s.publish(ctx, ctruntime.TaskDeleteEventTopic, &eventstypes.TaskDelete{ContainerID: s.id, ID: r.ExecID, Pid: response.Pid, ExitStatus: p.exit, ExitedAt: response.ExitedAt}); err != nil {
			return abort(fmt.Errorf("queue task delete event: %w", err))
		}
		s.mu.Lock()
		p.deleteEventQueued = true
		persistErr := s.persistRecovery()
		s.mu.Unlock()
		if persistErr != nil {
			return abort(fmt.Errorf("persist queued delete event: %w", persistErr))
		}
	}
	if err := s.flushEvents(ctx); err != nil {
		return abort(fmt.Errorf("flush task delete event: %w", err))
	}
	if r.ExecID == "" && s.sandbox.Config.Storage != nil {
		request := rootfspkg.CleanupRequest{Version: rootfspkg.Version, Bundle: s.bundle, BundleIdentity: s.bundleIdentity,
			TaskIdentity: storageTaskIdentity(s.namespace, s.id), StorageSHA256: s.sandbox.Config.Storage.SHA256}
		if err := s.cleanupRootfs(ctx, request); err != nil {
			return abort(fmt.Errorf("cleanup prepared rootfs: %w", err))
		}
	}
	s.mu.Lock()
	delete(s.processes, r.ExecID)
	if r.ExecID != "" {
		if err := s.persistRecovery(); err != nil {
			s.processes[r.ExecID] = p
			p.deleting = false
			s.mu.Unlock()
			return nil, fmt.Errorf("persist process deletion: %w", err)
		}
	}
	s.mu.Unlock()
	resp := &taskapi.DeleteResponse{Pid: responsePID, ExitStatus: p.exit, ExitedAt: timestamppb.New(p.exited)}
	return resp, nil
}

func (s *service) Pids(ctx context.Context, r *taskapi.PidsRequest) (*taskapi.PidsResponse, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	if r == nil {
		return nil, fmt.Errorf("%w: nil pids request", errdefs.ErrInvalidArgument)
	}
	if err := s.validateTaskRequest(r.ID); err != nil {
		return nil, err
	}
	if err := lockContext(ctx, &s.mu); err != nil {
		return nil, err
	}
	defer s.mu.Unlock()
	processes := make([]*tasktypes.ProcessInfo, 0, len(s.processes))
	for execID, process := range s.processes {
		if pid := s.taskPID(execID, process); pid != 0 {
			processes = append(processes, &tasktypes.ProcessInfo{Pid: pid})
		}
	}
	sort.Slice(processes, func(i, j int) bool { return processes[i].Pid < processes[j].Pid })
	return &taskapi.PidsResponse{Processes: processes}, nil
}
func (s *service) Connect(ctx context.Context, r *taskapi.ConnectRequest) (*taskapi.ConnectResponse, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	if r == nil {
		return nil, fmt.Errorf("%w: nil connect request", errdefs.ErrInvalidArgument)
	}
	if err := s.validateTaskRequest(r.ID); err != nil {
		return nil, err
	}
	if err := lockContext(ctx, &s.mu); err != nil {
		return nil, err
	}
	defer s.mu.Unlock()
	var taskPID uint32
	if init, ok := s.processes[""]; ok {
		if err := s.ensureNamespaceHolder(); err != nil {
			return nil, err
		}
		taskPID = s.taskPID("", init)
	}
	return &taskapi.ConnectResponse{ShimPid: uint32(os.Getpid()), TaskPid: taskPID, Version: "multikernel-v2-host-netns-pid"}, nil
}
func (s *service) Shutdown(ctx context.Context, r *taskapi.ShutdownRequest) (*emptypb.Empty, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	if r == nil {
		return nil, fmt.Errorf("%w: nil shutdown request", errdefs.ErrInvalidArgument)
	}
	if err := s.validateTaskRequest(r.ID); err != nil {
		return nil, err
	}
	if err := lockContext(ctx, &s.mu); err != nil {
		return nil, err
	}
	if len(s.processes) != 0 || s.shuttingDown {
		s.mu.Unlock()
		return &emptypb.Empty{}, nil
	}
	s.shuttingDown = true
	shutdown := s.shutdown
	s.mu.Unlock()
	if err := s.flushEvents(ctx); err != nil {
		s.mu.Lock()
		s.shuttingDown = false
		s.mu.Unlock()
		return nil, fmt.Errorf("flush durable events before shutdown: %w", err)
	}
	go func() {
		s.stopEventRetry()
		s.closeBundleIdentity()
		if shutdown != nil {
			shutdown()
		}
	}()
	return &emptypb.Empty{}, nil
}
func (s *service) ResizePty(ctx context.Context, r *taskapi.ResizePtyRequest) (*emptypb.Empty, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	if r == nil {
		return nil, fmt.Errorf("%w: nil resize request", errdefs.ErrInvalidArgument)
	}
	if err := s.validateTaskRequest(r.ID); err != nil {
		return nil, err
	}
	if r.Width > 65535 || r.Height > 65535 {
		return nil, fmt.Errorf("%w: terminal dimensions exceed the Linux PTY limit", errdefs.ErrInvalidArgument)
	}
	if err := lockContext(ctx, &s.mu); err != nil {
		return nil, err
	}
	p, ok := s.processes[r.ExecID]
	if !ok {
		s.mu.Unlock()
		return nil, errdefs.ErrNotFound
	}
	if !p.terminal {
		s.mu.Unlock()
		return nil, errdefs.ErrFailedPrecondition
	}
	if p.status != tasktypes.Status_CREATED && p.status != tasktypes.Status_RUNNING {
		s.mu.Unlock()
		return nil, errdefs.ErrFailedPrecondition
	}
	if p.status == tasktypes.Status_RUNNING && s.agent == nil {
		s.mu.Unlock()
		return nil, errdefs.ErrFailedPrecondition
	}
	oldWidth, oldHeight, oldSizeSet := p.width, p.height, p.sizeSet
	p.width, p.height, p.sizeSet = r.Width, r.Height, true
	if err := s.persistRecovery(); err != nil {
		p.width, p.height, p.sizeSet = oldWidth, oldHeight, oldSizeSet
		s.mu.Unlock()
		return nil, fmt.Errorf("persist terminal size: %w", err)
	}
	if p.status == tasktypes.Status_CREATED {
		s.mu.Unlock()
		return &emptypb.Empty{}, nil
	}
	id := r.ExecID
	if id == "" {
		id = "init"
	}
	if err := s.resizeGuestProcess(ctx, id, r.Width, r.Height); err != nil {
		p.width, p.height, p.sizeSet = oldWidth, oldHeight, oldSizeSet
		rollbackErr := s.persistRecovery()
		if rollbackErr != nil {
			// The durable new intent won the failure race. Keep memory aligned
			// with it so a caller retry or reconstruction reapplies that intent.
			p.width, p.height, p.sizeSet = r.Width, r.Height, true
		}
		s.mu.Unlock()
		return nil, errors.Join(err, rollbackErr)
	}
	s.mu.Unlock()
	return &emptypb.Empty{}, nil
}

type processSignalTarget struct {
	id      string
	process *process
}

func (s *service) signalTargets(status tasktypes.Status) []processSignalTarget {
	result := make([]processSignalTarget, 0, len(s.processes))
	for id, process := range s.processes {
		if process.status != status {
			continue
		}
		agentID := id
		if agentID == "" {
			agentID = "init"
		}
		result = append(result, processSignalTarget{id: agentID, process: process})
	}
	sort.Slice(result, func(i, j int) bool {
		if result[i].id == "init" || result[j].id == "init" {
			return result[i].id == "init"
		}
		return result[i].id < result[j].id
	})
	return result
}

func (s *service) signalProcessTargets(ctx context.Context, targets []processSignalTarget, signal syscall.Signal) (int, error) {
	for index, target := range targets {
		if err := s.applyGuestSignal(ctx, target.id, uint32(signal)); err != nil {
			return index, err
		}
	}
	return len(targets), nil
}

func (s *service) rollbackProcessSignals(targets []processSignalTarget, signal syscall.Signal) error {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	var failures []error
	for index := len(targets) - 1; index >= 0; index-- {
		err := s.applyGuestSignal(ctx, targets[index].id, uint32(signal))
		if err != nil {
			failures = append(failures, fmt.Errorf("rollback process %s: %w", targets[index].id, err))
		}
	}
	return errors.Join(failures...)
}

func (s *service) Pause(ctx context.Context, r *taskapi.PauseRequest) (*emptypb.Empty, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	if r == nil {
		return nil, fmt.Errorf("%w: nil pause request", errdefs.ErrInvalidArgument)
	}
	if err := s.validateTaskRequest(r.ID); err != nil {
		return nil, err
	}
	if err := lockContext(ctx, &s.mu); err != nil {
		return nil, err
	}
	defer s.mu.Unlock()
	p, ok := s.processes[""]
	if !ok {
		return nil, errdefs.ErrNotFound
	}
	if p.status != tasktypes.Status_RUNNING || s.agent == nil {
		return nil, errdefs.ErrFailedPrecondition
	}
	targets := s.signalTargets(tasktypes.Status_RUNNING)
	signaled, err := s.signalProcessTargets(ctx, targets, syscall.SIGSTOP)
	if err != nil {
		return nil, errors.Join(err, s.rollbackProcessSignals(targets[:signaled], syscall.SIGCONT))
	}
	for _, target := range targets {
		target.process.status = tasktypes.Status_PAUSED
	}
	if err := s.persistRecovery(); err != nil {
		rollbackErr := s.rollbackProcessSignals(targets, syscall.SIGCONT)
		for _, target := range targets {
			target.process.status = tasktypes.Status_RUNNING
		}
		persistErr := s.persistRecovery()
		if persistErr != nil {
			persistErr = fmt.Errorf("persist pause rollback: %w", persistErr)
		}
		return nil, errors.Join(fmt.Errorf("persist paused state: %w", err), rollbackErr, persistErr)
	}
	if err := s.publish(ctx, ctruntime.TaskPausedEventTopic, &eventstypes.TaskPaused{ContainerID: s.id}); err != nil {
		rollbackErr := s.rollbackProcessSignals(targets, syscall.SIGCONT)
		for _, target := range targets {
			target.process.status = tasktypes.Status_RUNNING
		}
		persistErr := s.persistRecovery()
		if persistErr != nil {
			persistErr = fmt.Errorf("persist pause rollback: %w", persistErr)
		}
		return nil, errors.Join(err, rollbackErr, persistErr)
	}
	return &emptypb.Empty{}, nil
}
func (s *service) Resume(ctx context.Context, r *taskapi.ResumeRequest) (*emptypb.Empty, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	if r == nil {
		return nil, fmt.Errorf("%w: nil resume request", errdefs.ErrInvalidArgument)
	}
	if err := s.validateTaskRequest(r.ID); err != nil {
		return nil, err
	}
	if err := lockContext(ctx, &s.mu); err != nil {
		return nil, err
	}
	defer s.mu.Unlock()
	p, ok := s.processes[""]
	if !ok {
		return nil, errdefs.ErrNotFound
	}
	if p.status != tasktypes.Status_PAUSED || s.agent == nil {
		return nil, errdefs.ErrFailedPrecondition
	}
	targets := s.signalTargets(tasktypes.Status_PAUSED)
	signaled, err := s.signalProcessTargets(ctx, targets, syscall.SIGCONT)
	if err != nil {
		return nil, errors.Join(err, s.rollbackProcessSignals(targets[:signaled], syscall.SIGSTOP))
	}
	for _, target := range targets {
		target.process.status = tasktypes.Status_RUNNING
	}
	if err := s.persistRecovery(); err != nil {
		rollbackErr := s.rollbackProcessSignals(targets, syscall.SIGSTOP)
		for _, target := range targets {
			target.process.status = tasktypes.Status_PAUSED
		}
		persistErr := s.persistRecovery()
		if persistErr != nil {
			persistErr = fmt.Errorf("persist resume rollback: %w", persistErr)
		}
		return nil, errors.Join(fmt.Errorf("persist resumed state: %w", err), rollbackErr, persistErr)
	}
	if err := s.publish(ctx, ctruntime.TaskResumedEventTopic, &eventstypes.TaskResumed{ContainerID: s.id}); err != nil {
		rollbackErr := s.rollbackProcessSignals(targets, syscall.SIGSTOP)
		for _, target := range targets {
			target.process.status = tasktypes.Status_PAUSED
		}
		persistErr := s.persistRecovery()
		if persistErr != nil {
			persistErr = fmt.Errorf("persist resume rollback: %w", persistErr)
		}
		return nil, errors.Join(err, rollbackErr, persistErr)
	}
	return &emptypb.Empty{}, nil
}
func (s *service) Checkpoint(context.Context, *taskapi.CheckpointTaskRequest) (*emptypb.Empty, error) {
	return nil, errdefs.ErrNotImplemented
}
func (s *service) CloseIO(ctx context.Context, r *taskapi.CloseIORequest) (*emptypb.Empty, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	if r == nil {
		return nil, fmt.Errorf("%w: nil close I/O request", errdefs.ErrInvalidArgument)
	}
	if err := s.validateTaskRequest(r.ID); err != nil {
		return nil, err
	}
	if !r.Stdin {
		return &emptypb.Empty{}, nil
	}
	if err := lockContext(ctx, &s.mu); err != nil {
		return nil, err
	}
	p, ok := s.processes[r.ExecID]
	if !ok {
		s.mu.Unlock()
		return nil, errdefs.ErrNotFound
	}
	if p.stdinClosed && p.stdinCloseAcked {
		s.mu.Unlock()
		return &emptypb.Empty{}, nil
	}
	if p.status == tasktypes.Status_STOPPED {
		s.mu.Unlock()
		return nil, errdefs.ErrFailedPrecondition
	}
	if p.status != tasktypes.Status_CREATED && p.status != tasktypes.Status_RUNNING && p.status != tasktypes.Status_PAUSED {
		s.mu.Unlock()
		return nil, errdefs.ErrFailedPrecondition
	}
	if !p.stdinClosed {
		p.stdinClosed = true
		if err := s.persistRecovery(); err != nil {
			p.stdinClosed = false
			s.mu.Unlock()
			return nil, fmt.Errorf("persist closed stdin: %w", err)
		}
	}
	if p.status == tasktypes.Status_CREATED {
		s.mu.Unlock()
		return &emptypb.Empty{}, nil
	}
	hasReader := p.stdinReader != nil
	s.mu.Unlock()
	id := r.ExecID
	if id == "" {
		id = "init"
	}
	if hasReader {
		// The pump must forward bytes already buffered in the FIFO before it
		// closes guest stdin. It observes stdinClosed after reaching FIFO EOF.
		return &emptypb.Empty{}, nil
	}
	if err := s.acknowledgeStdinClose(ctx, id, p); err != nil {
		return nil, err
	}
	return &emptypb.Empty{}, nil
}
func (s *service) Update(context.Context, *taskapi.UpdateTaskRequest) (*emptypb.Empty, error) {
	return nil, errdefs.ErrNotImplemented
}
func (s *service) Stats(ctx context.Context, r *taskapi.StatsRequest) (*taskapi.StatsResponse, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	if r == nil {
		return nil, fmt.Errorf("%w: nil stats request", errdefs.ErrInvalidArgument)
	}
	if err := s.validateTaskRequest(r.ID); err != nil {
		return nil, err
	}
	if err := lockContext(ctx, &s.mu); err != nil {
		return nil, err
	}
	p, ok := s.processes[""]
	client := s.agent
	memoryLimit := s.sandbox.Config.MemoryBytes
	var processIDs []string
	for id, process := range s.processes {
		if process.status != tasktypes.Status_RUNNING && process.status != tasktypes.Status_PAUSED {
			continue
		}
		if id == "" {
			id = "init"
		}
		processIDs = append(processIDs, id)
	}
	sort.Strings(processIDs)
	var status tasktypes.Status
	if ok {
		status = p.status
	}
	s.mu.Unlock()
	if !ok || client == nil {
		return nil, errdefs.ErrNotFound
	}
	if status != tasktypes.Status_RUNNING && status != tasktypes.Status_PAUSED {
		return nil, errdefs.ErrFailedPrecondition
	}
	var guest agent.ProcessStats
	for _, id := range processIDs {
		var observed agent.ProcessStats
		if err := s.callAgentWithReconnectContext(ctx, "StatsProcess", map[string]string{"ID": id}, &observed); err != nil {
			return nil, fmt.Errorf("stats process %s: %w", id, err)
		}
		if ^uint64(0)-guest.CPUUserNS < observed.CPUUserNS ||
			^uint64(0)-guest.CPUSystemNS < observed.CPUSystemNS ||
			^uint64(0)-guest.RSSBytes < observed.RSSBytes ||
			^uint64(0)-guest.PIDs < observed.PIDs {
			return nil, errors.New("guest process metrics overflow task aggregate")
		}
		guest.CPUUserNS += observed.CPUUserNS
		guest.CPUSystemNS += observed.CPUSystemNS
		guest.RSSBytes += observed.RSSBytes
		guest.PIDs += observed.PIDs
	}
	if ^uint64(0)-guest.CPUUserNS < guest.CPUSystemNS {
		return nil, errors.New("guest CPU metrics overflow total usage")
	}
	metrics := &cgroupstats.Metrics{
		Pids: &cgroupstats.PidsStat{Current: guest.PIDs, Limit: 1024},
		CPU: &cgroupstats.CPUStat{Usage: &cgroupstats.CPUUsage{
			Total: guest.CPUUserNS + guest.CPUSystemNS, User: guest.CPUUserNS, Kernel: guest.CPUSystemNS,
		}},
		Memory: &cgroupstats.MemoryStat{RSS: guest.RSSBytes, TotalRSS: guest.RSSBytes,
			Usage: &cgroupstats.MemoryEntry{Usage: guest.RSSBytes, Limit: memoryLimit}},
	}
	encoded, err := typeurl.MarshalAny(metrics)
	if err != nil {
		return nil, err
	}
	return &taskapi.StatsResponse{Stats: &anypb.Any{TypeUrl: encoded.GetTypeUrl(), Value: encoded.GetValue()}}, nil
}

var _ taskapi.TaskService = (*service)(nil)

func writeRuntimeInfo(input io.Reader, output io.Writer) error {
	data, err := io.ReadAll(io.LimitReader(input, runtimeInfoInputLimit+1))
	if err != nil {
		return fmt.Errorf("read runtime options: %w", err)
	}
	if len(data) > runtimeInfoInputLimit {
		return errors.New("runtime options exceed the one-MiB limit")
	}
	var options *anypb.Any
	if len(data) != 0 {
		options = &anypb.Any{}
		if err = proto.Unmarshal(data, options); err != nil {
			return fmt.Errorf("decode runtime options: %w", err)
		}
	}
	payload, err := proto.Marshal(&types.RuntimeInfo{
		Name: runtimeName,
		Version: &types.RuntimeVersion{
			Version:  buildinfo.Version,
			Revision: buildinfo.Revision,
		},
		Options: options,
	})
	if err != nil {
		return fmt.Errorf("encode runtime info: %w", err)
	}
	written, err := output.Write(payload)
	if err == nil && written != len(payload) {
		err = io.ErrShortWrite
	}
	return err
}

func main() {
	if len(os.Args) == 3 && os.Args[1] == fifoKeeperMode {
		os.Exit(runOutputFIFOKeeper(os.Args[2:]))
	}
	if len(os.Args) == 2 && os.Args[1] == namespaceHolderMode {
		os.Exit(runNamespaceHolder())
	}
	if buildinfo.PrintRequested(os.Stdout, "containerd-shim-multikernel-v2", os.Args[1:]) {
		return
	}
	// The containerd 2.x discovery probe is a command-like flag. Intercept it
	// before the vendored 1.7 shim runner parses flags.
	if len(os.Args) == 2 && os.Args[1] == "-info" {
		if err := writeRuntimeInfo(os.Stdin, os.Stdout); err != nil {
			fmt.Fprintf(os.Stderr, "%s: runtime info: %v\n", runtimeName, err)
			os.Exit(1)
		}
		return
	}
	if serverInvocation() && os.Getenv("MK_SHIM_WORKER") != "1" {
		os.Exit(superviseShimWorker())
	}
	shim.Run(runtimeName, newService)
}
