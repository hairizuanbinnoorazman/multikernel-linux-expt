package main

import (
	"context"
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"os"
	"path/filepath"
	"regexp"
	"time"

	"github.com/hairizuan/multikernel-linux-expt/runtime/internal/buildinfo"
	"github.com/hairizuan/multikernel-linux-expt/runtime/internal/network"
	"github.com/hairizuan/multikernel-linux-expt/runtime/internal/safefile"
	"github.com/hairizuan/multikernel-linux-expt/runtime/protocol"
)

var cniIdentifier = regexp.MustCompile(`^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$`)

type config struct {
	CNIVersion string `json:"cniVersion"`
	Name       string `json:"name"`
	Type       string `json:"type"`
	Socket     string `json:"socket"`
	CacheDir   string `json:"cacheDir"`
}

type environment struct {
	Command     string
	ContainerID string
	NetNS       string
	IfName      string
}

type caller interface {
	Call(context.Context, network.Request) (network.Response, error)
}

type cniInterface struct {
	Name    string `json:"name"`
	Sandbox string `json:"sandbox,omitempty"`
}
type cniIP struct {
	Version   string `json:"version"`
	Address   string `json:"address"`
	Gateway   string `json:"gateway"`
	Interface int    `json:"interface"`
}
type cniResult struct {
	CNIVersion string         `json:"cniVersion"`
	Interfaces []cniInterface `json:"interfaces"`
	IPs        []cniIP        `json:"ips"`
	DNS        network.DNS    `json:"dns"`
}
type cniVersions struct {
	CNIVersion        string   `json:"cniVersion"`
	SupportedVersions []string `json:"supportedVersions"`
}
type cniError struct {
	CNIVersion string `json:"cniVersion"`
	Code       int    `json:"code"`
	Message    string `json:"msg"`
	Details    string `json:"details"`
}

func requestID(command string) (string, error) {
	data := make([]byte, 8)
	if _, err := rand.Read(data); err != nil {
		return "", err
	}
	return "cni-" + command + "-" + hex.EncodeToString(data), nil
}

func validateConfig(data []byte) (config, error) {
	var value config
	if err := protocol.StrictDecode(data, &value); err != nil {
		return value, err
	}
	if value.CNIVersion != "1.0.0" || !cniIdentifier.MatchString(value.Name) || value.Type != "multikernel" ||
		!filepath.IsAbs(value.Socket) || filepath.Clean(value.Socket) != value.Socket ||
		!filepath.IsAbs(value.CacheDir) || filepath.Clean(value.CacheDir) != value.CacheDir {
		return value, errors.New("CNI config requires cniVersion 1.0.0, a valid name, type multikernel, and absolute socket/cacheDir")
	}
	return value, nil
}

type cacheRecord struct {
	Version    int    `json:"version"`
	Generation string `json:"generation"`
	NetNS      string `json:"netns"`
}

func cachePath(configuration config, env environment) string {
	return filepath.Join(configuration.CacheDir, cacheName(configuration, env))
}

func cacheName(configuration config, env environment) string {
	digest := sha256.Sum256([]byte(configuration.Name + "\x00" + env.ContainerID + "\x00" + env.IfName))
	return hex.EncodeToString(digest[:]) + ".json"
}

func openCacheDirectory(path string, create bool) (*safefile.Directory, error) {
	directory, err := safefile.OpenDirectory(path, create)
	if err != nil {
		return nil, fmt.Errorf("CNI cache directory is unsafe: %w", err)
	}
	return directory, nil
}

func readCache(configuration config, env environment) (cacheRecord, error) {
	directory, err := openCacheDirectory(configuration.CacheDir, false)
	if err != nil {
		return cacheRecord{}, err
	}
	defer directory.Close()
	return readCacheFrom(directory, configuration, env)
}

func readCacheFrom(directory *safefile.Directory, configuration config, env environment) (cacheRecord, error) {
	record, _, _, err := readCacheIdentityFrom(directory, configuration, env)
	return record, err
}

func readCacheIdentityFrom(directory *safefile.Directory, configuration config, env environment) (cacheRecord, safefile.Identity, bool, error) {
	var record cacheRecord
	data, found, quarantined, identity, err := directory.ReadPrivateOrQuarantineIdentity(cacheName(configuration, env), 4096)
	if err != nil {
		return record, safefile.Identity{}, false, err
	}
	if !found {
		return record, safefile.Identity{}, false, fmt.Errorf("CNI endpoint cache %s: %w", cachePath(configuration, env), os.ErrNotExist)
	}
	if err = protocol.StrictDecode(data, &record); err != nil || record.Version != 1 || !endpointGeneration.MatchString(record.Generation) ||
		!filepath.IsAbs(record.NetNS) || filepath.Clean(record.NetNS) != record.NetNS {
		return record, safefile.Identity{}, false, errors.New("CNI endpoint cache is malformed")
	}
	return record, identity, quarantined, nil
}

var endpointGeneration = regexp.MustCompile(`^[0-9a-f]{32}$`)

func writeCache(configuration config, env environment, record cacheRecord) error {
	if record.Version != 1 || !endpointGeneration.MatchString(record.Generation) || !filepath.IsAbs(record.NetNS) || filepath.Clean(record.NetNS) != record.NetNS {
		return errors.New("refusing to publish malformed CNI endpoint cache")
	}
	data, err := json.Marshal(record)
	if err != nil {
		return err
	}
	directory, err := openCacheDirectory(configuration.CacheDir, true)
	if err != nil {
		return err
	}
	defer directory.Close()
	created, err := directory.PublishExclusive(cacheName(configuration, env), append(data, '\n'), 0600)
	if err != nil {
		return err
	}
	if created {
		return nil
	}
	existing, readErr := readCacheFrom(directory, configuration, env)
	if readErr != nil || existing != record {
		return errors.New("CNI endpoint cache already owns a different generation")
	}
	return nil
}

func readCNIInput(input io.Reader) ([]byte, error) {
	data, err := io.ReadAll(io.LimitReader(input, (1<<20)+1))
	if err != nil {
		return nil, err
	}
	if len(data) > 1<<20 {
		return nil, errors.New("CNI configuration exceeds the one-MiB input limit")
	}
	return data, nil
}

func deleteCacheFrom(directory *safefile.Directory, configuration config, env environment, expected *cacheRecord, expectedIdentity safefile.Identity) error {
	if directory == nil {
		return nil
	}
	current, currentIdentity, _, readErr := readCacheIdentityFrom(directory, configuration, env)
	if errors.Is(readErr, os.ErrNotExist) {
		return nil
	}
	if readErr != nil {
		return readErr
	}
	if expected == nil || current != *expected || !safefile.SameObject(currentIdentity, expectedIdentity) {
		return errors.New("CNI endpoint cache changed before deletion")
	}
	_, err := directory.RemoveIfIdentity(cacheName(configuration, env), expectedIdentity)
	return err
}

func validateAllocatedEndpoint(requested, allocated *network.Endpoint) error {
	if allocated == nil || !endpointGeneration.MatchString(allocated.Generation) {
		return errors.New("mknetd returned an invalid endpoint generation")
	}
	if allocated.ContainerID != requested.ContainerID || allocated.NetworkName != requested.NetworkName ||
		allocated.IfName != requested.IfName || allocated.NetNS != requested.NetNS || allocated.Owner != "cni" ||
		allocated.ManagedNamespace || allocated.SandboxID != "" || allocated.SandboxGeneration != "" || allocated.State != "READY" {
		return errors.New("mknetd ADD response identity differs from the exact CNI request")
	}
	ip, subnet, err := net.ParseCIDR(allocated.Address)
	if err != nil || ip.To4() == nil {
		return errors.New("mknetd returned an invalid IPv4 address")
	}
	ones, bits := subnet.Mask.Size()
	gateway := net.ParseIP(allocated.Gateway)
	if bits != 32 || ones != 30 || gateway == nil || gateway.To4() == nil || !subnet.Contains(gateway) || gateway.Equal(ip) {
		return errors.New("mknetd returned an invalid IPv4 /30 gateway")
	}
	if allocated.MTU < 576 || allocated.MTU > 65515 {
		return errors.New("mknetd returned an invalid MTU")
	}
	if len(allocated.DNS.Nameservers) > 8 || len(allocated.DNS.Search) > 8 || len(allocated.DNS.Options) > 8 {
		return errors.New("mknetd returned an oversized DNS policy")
	}
	for _, server := range allocated.DNS.Nameservers {
		if net.ParseIP(server) == nil {
			return errors.New("mknetd returned an invalid DNS server")
		}
	}
	return nil
}

func rollbackAllocatedEndpoint(client caller, allocated *network.Endpoint) error {
	if allocated == nil || !endpointGeneration.MatchString(allocated.Generation) {
		return errors.New("cannot safely roll back an endpoint without its valid generation")
	}
	rollbackID, err := requestID("DEL")
	if err != nil {
		return err
	}
	rollbackCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	_, err = client.Call(rollbackCtx, network.Request{Version: 1, RequestID: rollbackID, Method: "DEL", Endpoint: allocated})
	return err
}

func run(ctx context.Context, input []byte, env environment, client caller) (any, error) {
	if env.Command == "VERSION" {
		return cniVersions{CNIVersion: "1.0.0", SupportedVersions: []string{"1.0.0"}}, nil
	}
	configuration, err := validateConfig(input)
	if err != nil {
		return nil, err
	}
	if !cniIdentifier.MatchString(env.ContainerID) || !cniIdentifier.MatchString(env.IfName) {
		return nil, errors.New("CNI_CONTAINERID and CNI_IFNAME must be valid identifiers")
	}
	if (env.Command == "ADD" || env.Command == "CHECK") && (env.NetNS == "" || env.NetNS[0] != '/') {
		return nil, errors.New("CNI_NETNS must be absolute for ADD and CHECK")
	}
	id, err := requestID(env.Command)
	if err != nil {
		return nil, err
	}
	endpoint := &network.Endpoint{ContainerID: env.ContainerID, NetworkName: configuration.Name, IfName: env.IfName, NetNS: env.NetNS}
	var cached *cacheRecord
	var cachedIdentity safefile.Identity
	var cachedQuarantined bool
	var cacheDirectory *safefile.Directory
	if env.Command == "CHECK" || env.Command == "DEL" {
		cacheDirectory, err = openCacheDirectory(configuration.CacheDir, false)
		var record cacheRecord
		cacheErr := err
		if cacheErr == nil {
			defer cacheDirectory.Close()
			record, cachedIdentity, cachedQuarantined, cacheErr = readCacheIdentityFrom(cacheDirectory, configuration, env)
		}
		if cacheErr == nil {
			if env.Command == "CHECK" && cachedQuarantined {
				return nil, errors.New("CNI endpoint cache deletion is incomplete")
			}
			cached = &record
			endpoint.Generation = record.Generation
			if endpoint.NetNS == "" {
				endpoint.NetNS = record.NetNS
			}
		} else if env.Command == "CHECK" || !errors.Is(cacheErr, os.ErrNotExist) {
			return nil, cacheErr
		}
	}
	response, err := client.Call(ctx, network.Request{Version: 1, RequestID: id, Method: env.Command, Endpoint: endpoint})
	if err != nil {
		return nil, err
	}
	if env.Command == "DEL" {
		if err = deleteCacheFrom(cacheDirectory, configuration, env, cached, cachedIdentity); err != nil {
			return nil, err
		}
		return nil, nil
	}
	if env.Command == "CHECK" {
		if response.Endpoint == nil {
			return nil, errors.New("mknetd CHECK response omitted the endpoint")
		}
		if err = validateAllocatedEndpoint(endpoint, response.Endpoint); err != nil {
			return nil, fmt.Errorf("validate mknetd CHECK response: %w", err)
		}
		return nil, nil
	}
	if env.Command != "ADD" || response.Endpoint == nil {
		return nil, errors.New("unsupported CNI_COMMAND")
	}
	allocated := response.Endpoint
	if err = validateAllocatedEndpoint(endpoint, allocated); err != nil {
		return nil, errors.Join(err, rollbackAllocatedEndpoint(client, allocated))
	}
	if err = writeCache(configuration, env, cacheRecord{Version: 1, Generation: allocated.Generation, NetNS: allocated.NetNS}); err != nil {
		return nil, errors.Join(fmt.Errorf("persist CNI generation cache: %w", err), rollbackAllocatedEndpoint(client, allocated))
	}
	return cniResult{
		CNIVersion: configuration.CNIVersion,
		Interfaces: []cniInterface{{Name: allocated.IfName, Sandbox: allocated.NetNS}},
		IPs:        []cniIP{{Version: "4", Address: allocated.Address, Gateway: allocated.Gateway, Interface: 0}},
		DNS:        allocated.DNS,
	}, nil
}

func errorCode(err error) int {
	var api *network.APIError
	if errors.As(err, &api) {
		switch api.Code {
		case "INVALID_ARGUMENT":
			return 4
		case "NOT_FOUND":
			return 7
		case "RESOURCE_EXHAUSTED":
			return 11
		}
	}
	return 100
}

func main() {
	if buildinfo.PrintRequested(os.Stdout, "mk-cni", os.Args[1:]) {
		return
	}
	input, err := readCNIInput(os.Stdin)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	env := environment{Command: os.Getenv("CNI_COMMAND"), ContainerID: os.Getenv("CNI_CONTAINERID"), NetNS: os.Getenv("CNI_NETNS"), IfName: os.Getenv("CNI_IFNAME")}
	var client caller
	if env.Command != "VERSION" {
		configuration, configErr := validateConfig(input)
		if configErr == nil {
			client = network.Client{Path: configuration.Socket, Timeout: 10 * time.Second}
		}
	}
	result, err := run(context.Background(), input, env, client)
	encoder := json.NewEncoder(os.Stdout)
	if err != nil {
		_ = encoder.Encode(cniError{CNIVersion: "1.0.0", Code: errorCode(err), Message: "multikernel CNI request failed", Details: err.Error()})
		os.Exit(1)
	}
	if result != nil {
		if err = encoder.Encode(result); err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
	}
}
