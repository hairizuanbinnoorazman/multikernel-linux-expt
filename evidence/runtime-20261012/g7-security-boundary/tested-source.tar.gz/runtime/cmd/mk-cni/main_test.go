package main

import (
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/hairizuan/multikernel-linux-expt/runtime/internal/network"
)

type fakeCaller struct {
	requests []network.Request
	response network.Response
	err      error
	hook     func(network.Request)
}

func (f *fakeCaller) Call(_ context.Context, request network.Request) (network.Response, error) {
	f.requests = append(f.requests, request)
	if f.hook != nil {
		f.hook(request)
	}
	return f.response, f.err
}

func validConfig(t *testing.T) []byte {
	t.Helper()
	cache := t.TempDir()
	if err := os.Chmod(cache, 0700); err != nil {
		t.Fatal(err)
	}
	return []byte(fmt.Sprintf(`{"cniVersion":"1.0.0","name":"multikernel","type":"multikernel","socket":"/run/mknetd.sock","cacheDir":%q}`, cache))
}

func TestAddReturnsAllocatedInterfaceIPAndDNS(t *testing.T) {
	fake := &fakeCaller{response: network.Response{Endpoint: &network.Endpoint{
		ContainerID: "box", NetworkName: "multikernel", IfName: "eth0", NetNS: "/run/netns/box",
		Owner: "cni", Generation: "0123456789abcdef0123456789abcdef", Address: "172.31.0.2/30", Gateway: "172.31.0.1", MTU: 1400,
		State: "READY", DNS: network.DNS{Nameservers: []string{"1.1.1.1"}},
	}}}
	value, err := run(context.Background(), validConfig(t), environment{Command: "ADD", ContainerID: "box", IfName: "eth0", NetNS: "/run/netns/box"}, fake)
	if err != nil {
		t.Fatal(err)
	}
	result := value.(cniResult)
	if result.IPs[0].Address != "172.31.0.2/30" || result.Interfaces[0].Sandbox != "/run/netns/box" || result.DNS.Nameservers[0] != "1.1.1.1" {
		t.Fatalf("ADD result = %+v", result)
	}
	if len(fake.requests) != 1 || fake.requests[0].Method != "ADD" {
		t.Fatalf("requests = %+v", fake.requests)
	}
}

func TestAddRejectsMismatchedResponseAndRollsBackExactGeneration(t *testing.T) {
	allocated := &network.Endpoint{
		ContainerID: "other", NetworkName: "multikernel", IfName: "eth0", NetNS: "/run/netns/box", Owner: "cni",
		Generation: "0123456789abcdef0123456789abcdef", Address: "172.31.0.2/30", Gateway: "172.31.0.1", MTU: 1400, State: "READY",
	}
	fake := &fakeCaller{response: network.Response{Endpoint: allocated}}
	_, err := run(context.Background(), validConfig(t), environment{Command: "ADD", ContainerID: "box", IfName: "eth0", NetNS: "/run/netns/box"}, fake)
	if err == nil || !strings.Contains(err.Error(), "identity differs") {
		t.Fatalf("mismatched ADD response error = %v", err)
	}
	if len(fake.requests) != 2 || fake.requests[0].Method != "ADD" || fake.requests[1].Method != "DEL" || fake.requests[1].Endpoint != allocated {
		t.Fatalf("ADD rollback requests = %+v", fake.requests)
	}
}

func TestAddRejectsSymlinkCacheWithoutChangingTargetAndRollsBack(t *testing.T) {
	base := t.TempDir()
	target := filepath.Join(base, "target")
	if err := os.Mkdir(target, 0755); err != nil {
		t.Fatal(err)
	}
	if err := os.Chmod(target, 0755); err != nil {
		t.Fatal(err)
	}
	linked := filepath.Join(base, "cache")
	if err := os.Symlink(target, linked); err != nil {
		t.Fatal(err)
	}
	input := []byte(fmt.Sprintf(`{"cniVersion":"1.0.0","name":"multikernel","type":"multikernel","socket":"/run/mknetd.sock","cacheDir":%q}`, linked))
	allocated := &network.Endpoint{
		ContainerID: "box", NetworkName: "multikernel", IfName: "eth0", NetNS: "/run/netns/box", Owner: "cni",
		Generation: "0123456789abcdef0123456789abcdef", Address: "172.31.0.2/30", Gateway: "172.31.0.1", MTU: 1400, State: "READY",
	}
	fake := &fakeCaller{response: network.Response{Endpoint: allocated}}
	_, err := run(context.Background(), input, environment{Command: "ADD", ContainerID: "box", IfName: "eth0", NetNS: "/run/netns/box"}, fake)
	if err == nil || !strings.Contains(err.Error(), "CNI cache directory is unsafe") {
		t.Fatalf("symlink cache error = %v", err)
	}
	info, statErr := os.Stat(target)
	if statErr != nil {
		t.Fatal(statErr)
	}
	if info.Mode().Perm() != 0755 {
		t.Fatalf("symlink target mode changed: mode=%v", info.Mode().Perm())
	}
	if len(fake.requests) != 2 || fake.requests[1].Method != "DEL" {
		t.Fatalf("symlink cache rollback requests = %+v", fake.requests)
	}
}

func TestDeleteRefusesChangedGenerationCache(t *testing.T) {
	input := validConfig(t)
	configuration, err := validateConfig(input)
	if err != nil {
		t.Fatal(err)
	}
	env := environment{Command: "DEL", ContainerID: "box", IfName: "eth0"}
	first := cacheRecord{Version: 1, Generation: "0123456789abcdef0123456789abcdef", NetNS: "/run/netns/box"}
	if err = writeCache(configuration, env, first); err != nil {
		t.Fatal(err)
	}
	replacement := first
	replacement.Generation = "abcdef0123456789abcdef0123456789"
	fake := &fakeCaller{hook: func(network.Request) {
		data, marshalErr := json.Marshal(replacement)
		if marshalErr != nil {
			t.Fatal(marshalErr)
		}
		if writeErr := os.WriteFile(cachePath(configuration, env), append(data, '\n'), 0600); writeErr != nil {
			t.Fatal(writeErr)
		}
	}}
	if _, err = run(context.Background(), input, env, fake); err == nil || !strings.Contains(err.Error(), "changed before deletion") {
		t.Fatalf("changed generation deletion error = %v", err)
	}
	observed, err := readCache(configuration, env)
	if err != nil || observed != replacement {
		t.Fatalf("changed generation cache = %+v, %v", observed, err)
	}
}

func TestDeleteRefusesSameContentCacheInodeReplacement(t *testing.T) {
	input := validConfig(t)
	configuration, err := validateConfig(input)
	if err != nil {
		t.Fatal(err)
	}
	env := environment{Command: "DEL", ContainerID: "box", IfName: "eth0"}
	record := cacheRecord{Version: 1, Generation: "0123456789abcdef0123456789abcdef", NetNS: "/run/netns/box"}
	if err = writeCache(configuration, env, record); err != nil {
		t.Fatal(err)
	}
	path := cachePath(configuration, env)
	fake := &fakeCaller{hook: func(network.Request) {
		if renameErr := os.Rename(path, path+".original"); renameErr != nil {
			t.Fatal(renameErr)
		}
		data, marshalErr := json.Marshal(record)
		if marshalErr != nil {
			t.Fatal(marshalErr)
		}
		if writeErr := os.WriteFile(path, append(data, '\n'), 0600); writeErr != nil {
			t.Fatal(writeErr)
		}
	}}
	if _, err = run(context.Background(), input, env, fake); err == nil || !strings.Contains(err.Error(), "changed before deletion") {
		t.Fatalf("same-content replacement deletion error = %v", err)
	}
	if value, readErr := os.ReadFile(path); readErr != nil || len(value) == 0 {
		t.Fatalf("replacement cache was modified: %q, %v", value, readErr)
	}
	if value, readErr := os.ReadFile(path + ".original"); readErr != nil || len(value) == 0 {
		t.Fatalf("original cache was modified: %q, %v", value, readErr)
	}
}

func TestDeleteRemainsAnchoredAcrossCacheDirectoryRename(t *testing.T) {
	input := validConfig(t)
	configuration, err := validateConfig(input)
	if err != nil {
		t.Fatal(err)
	}
	env := environment{Command: "DEL", ContainerID: "box", IfName: "eth0"}
	record := cacheRecord{Version: 1, Generation: "0123456789abcdef0123456789abcdef", NetNS: "/run/netns/box"}
	if err = writeCache(configuration, env, record); err != nil {
		t.Fatal(err)
	}
	moved := configuration.CacheDir + ".moved"
	fake := &fakeCaller{hook: func(network.Request) {
		if renameErr := os.Rename(configuration.CacheDir, moved); renameErr != nil {
			t.Fatal(renameErr)
		}
		if mkdirErr := os.Mkdir(configuration.CacheDir, 0700); mkdirErr != nil {
			t.Fatal(mkdirErr)
		}
	}}
	if _, err = run(context.Background(), input, env, fake); err != nil {
		t.Fatal(err)
	}
	if _, statErr := os.Stat(filepath.Join(moved, cacheName(configuration, env))); !errors.Is(statErr, os.ErrNotExist) {
		t.Fatalf("cache remained in original directory inode: %v", statErr)
	}
	if entries, readErr := os.ReadDir(configuration.CacheDir); readErr != nil || len(entries) != 0 {
		t.Fatalf("replacement directory was mutated: %v, %v", entries, readErr)
	}
}

func TestCheckAndDeleteProduceNoResultAndDeleteAllowsEmptyNetNS(t *testing.T) {
	input := validConfig(t)
	configuration, err := validateConfig(input)
	if err != nil {
		t.Fatal(err)
	}
	env := environment{Command: "ADD", ContainerID: "box", IfName: "eth0", NetNS: "/run/netns/box"}
	if err = writeCache(configuration, env, cacheRecord{Version: 1, Generation: "0123456789abcdef0123456789abcdef", NetNS: env.NetNS}); err != nil {
		t.Fatal(err)
	}
	fake := &fakeCaller{response: network.Response{Endpoint: &network.Endpoint{
		ContainerID: "box", NetworkName: "multikernel", IfName: "eth0", NetNS: "/run/netns/box", Owner: "cni",
		Generation: "0123456789abcdef0123456789abcdef", Address: "172.31.0.2/30", Gateway: "172.31.0.1", MTU: 1400, State: "READY",
	}}}
	for _, test := range []environment{
		{Command: "CHECK", ContainerID: "box", IfName: "eth0", NetNS: "/run/netns/box"},
		{Command: "DEL", ContainerID: "box", IfName: "eth0"},
	} {
		value, err := run(context.Background(), input, test, fake)
		if err != nil || value != nil {
			t.Fatalf("%s value=%v error=%v", test.Command, value, err)
		}
	}
	if len(fake.requests) != 2 || fake.requests[0].Endpoint.Generation == "" || fake.requests[1].Endpoint.NetNS != "/run/netns/box" {
		t.Fatalf("cached requests = %+v", fake.requests)
	}
}

func TestRepeatedCheckDeleteAndNameReuse(t *testing.T) {
	input := validConfig(t)
	env := environment{Command: "ADD", ContainerID: "box", IfName: "eth0", NetNS: "/run/netns/box"}
	endpoint := func(generation string) *network.Endpoint {
		return &network.Endpoint{ContainerID: "box", NetworkName: "multikernel", IfName: "eth0", NetNS: env.NetNS,
			Owner: "cni", Generation: generation, Address: "172.31.0.2/30", Gateway: "172.31.0.1", MTU: 1400,
			State: "READY", DNS: network.DNS{Nameservers: []string{"1.1.1.1"}}}
	}
	first := endpoint("0123456789abcdef0123456789abcdef")
	if _, err := run(context.Background(), input, env, &fakeCaller{response: network.Response{Endpoint: first}}); err != nil {
		t.Fatal(err)
	}
	check := environment{Command: "CHECK", ContainerID: env.ContainerID, IfName: env.IfName, NetNS: env.NetNS}
	for attempt := 0; attempt < 2; attempt++ {
		if _, err := run(context.Background(), input, check, &fakeCaller{response: network.Response{Endpoint: first}}); err != nil {
			t.Fatalf("CHECK attempt %d: %v", attempt, err)
		}
	}
	deleteEnv := environment{Command: "DEL", ContainerID: env.ContainerID, IfName: env.IfName}
	firstDelete := &fakeCaller{}
	if _, err := run(context.Background(), input, deleteEnv, firstDelete); err != nil {
		t.Fatal(err)
	}
	if len(firstDelete.requests) != 1 || firstDelete.requests[0].Endpoint.Generation != first.Generation || firstDelete.requests[0].Endpoint.NetNS != env.NetNS {
		t.Fatalf("first DEL request = %+v", firstDelete.requests)
	}
	secondDelete := &fakeCaller{}
	if _, err := run(context.Background(), input, deleteEnv, secondDelete); err != nil {
		t.Fatal(err)
	}
	if len(secondDelete.requests) != 1 || secondDelete.requests[0].Endpoint.Generation != "" {
		t.Fatalf("idempotent DEL request = %+v", secondDelete.requests)
	}
	second := endpoint("abcdef0123456789abcdef0123456789")
	if _, err := run(context.Background(), input, env, &fakeCaller{response: network.Response{Endpoint: second}}); err != nil {
		t.Fatal(err)
	}
	configuration, err := validateConfig(input)
	if err != nil {
		t.Fatal(err)
	}
	record, err := readCache(configuration, env)
	if err != nil || record.Generation != second.Generation {
		t.Fatalf("reused endpoint cache = %+v, %v", record, err)
	}
}

func TestDeleteRecoversIdentityBoundCacheQuarantine(t *testing.T) {
	input := validConfig(t)
	configuration, err := validateConfig(input)
	if err != nil {
		t.Fatal(err)
	}
	env := environment{Command: "DEL", ContainerID: "box", IfName: "eth0"}
	record := cacheRecord{Version: 1, Generation: "0123456789abcdef0123456789abcdef", NetNS: "/run/netns/box"}
	if err = writeCache(configuration, env, record); err != nil {
		t.Fatal(err)
	}
	directory, err := openCacheDirectory(configuration.CacheDir, false)
	if err != nil {
		t.Fatal(err)
	}
	name := cacheName(configuration, env)
	_, found, identity, err := directory.ReadPrivateIdentity(name, 4096)
	if err != nil || !found {
		t.Fatalf("cache identity = %+v, %v, %v", identity, found, err)
	}
	if err = directory.Close(); err != nil {
		t.Fatal(err)
	}
	digest := sha256.Sum256([]byte(name))
	quarantineName := fmt.Sprintf(".mklinux-remove-%s-%016x-%016x", hex.EncodeToString(digest[:8]), identity.Device, identity.Inode)
	quarantinePath := filepath.Join(configuration.CacheDir, quarantineName)
	if err = os.Rename(cachePath(configuration, env), quarantinePath); err != nil {
		t.Fatal(err)
	}
	fake := &fakeCaller{}
	if _, err = run(context.Background(), input, env, fake); err != nil {
		t.Fatal(err)
	}
	if len(fake.requests) != 1 || fake.requests[0].Endpoint.Generation != record.Generation || fake.requests[0].Endpoint.NetNS != record.NetNS {
		t.Fatalf("recovered DEL request = %+v", fake.requests)
	}
	if _, err = os.Stat(quarantinePath); !errors.Is(err, os.ErrNotExist) {
		t.Fatalf("cache quarantine remains: %v", err)
	}
}

func TestCheckRejectsMissingOrMismatchedResponse(t *testing.T) {
	input := validConfig(t)
	configuration, err := validateConfig(input)
	if err != nil {
		t.Fatal(err)
	}
	env := environment{Command: "CHECK", ContainerID: "box", IfName: "eth0", NetNS: "/run/netns/box"}
	record := cacheRecord{Version: 1, Generation: "0123456789abcdef0123456789abcdef", NetNS: env.NetNS}
	if err = writeCache(configuration, env, record); err != nil {
		t.Fatal(err)
	}
	for name, response := range map[string]network.Response{
		"missing": {},
		"mismatched": {Endpoint: &network.Endpoint{
			ContainerID: "other", NetworkName: "multikernel", IfName: "eth0", NetNS: env.NetNS, Owner: "cni",
			Generation: record.Generation, Address: "172.31.0.2/30", Gateway: "172.31.0.1", MTU: 1400, State: "READY",
		}},
	} {
		t.Run(name, func(t *testing.T) {
			fake := &fakeCaller{response: response}
			if _, checkErr := run(context.Background(), input, env, fake); checkErr == nil {
				t.Fatal("unsafe CHECK response was accepted")
			}
			if len(fake.requests) != 1 || fake.requests[0].Method != "CHECK" {
				t.Fatalf("CHECK requests = %+v", fake.requests)
			}
		})
	}
}

func TestVersionDoesNotRequireConfigOrDaemon(t *testing.T) {
	value, err := run(context.Background(), nil, environment{Command: "VERSION"}, nil)
	if err != nil || len(value.(cniVersions).SupportedVersions) != 1 {
		t.Fatalf("VERSION value=%+v error=%v", value, err)
	}
}

func TestCNIRejectsUnknownFieldsUnsafeIdentityAndDaemonErrors(t *testing.T) {
	valid := validConfig(t)
	badConfig := append(append([]byte(nil), valid[:len(valid)-1]...), []byte(`,"extra":true}`)...)
	if _, err := run(context.Background(), badConfig, environment{Command: "ADD", ContainerID: "box", IfName: "eth0", NetNS: "/run/netns/box"}, &fakeCaller{}); err == nil {
		t.Fatal("unknown config field accepted")
	}
	if _, err := run(context.Background(), valid, environment{Command: "ADD", ContainerID: "../box", IfName: "eth0", NetNS: "/run/netns/box"}, &fakeCaller{}); err == nil {
		t.Fatal("unsafe container ID accepted")
	}
	injected := &network.APIError{Code: "RESOURCE_EXHAUSTED", Message: "full"}
	if _, err := run(context.Background(), valid, environment{Command: "ADD", ContainerID: "box", IfName: "eth0", NetNS: "/run/netns/box"}, &fakeCaller{err: injected}); !errors.Is(err, injected) || errorCode(err) != 11 {
		t.Fatalf("daemon error=%v code=%d", err, errorCode(err))
	}
}

func TestCNIInputRejectsOversizedValidPrefix(t *testing.T) {
	prefix := validConfig(t)
	input := append(prefix, bytes.Repeat([]byte(" "), (1<<20)+1)...)
	if _, err := readCNIInput(bytes.NewReader(input)); err == nil {
		t.Fatal("oversized CNI input with a valid JSON prefix was accepted")
	}
	if data, err := readCNIInput(bytes.NewReader(prefix)); err != nil || !bytes.Equal(data, prefix) {
		t.Fatalf("bounded CNI input = %q, %v", data, err)
	}
}

func TestCacheCreationRejectsSymlinkAncestorWithoutMutation(t *testing.T) {
	base := t.TempDir()
	target := filepath.Join(base, "target")
	if err := os.Mkdir(target, 0700); err != nil {
		t.Fatal(err)
	}
	linked := filepath.Join(base, "linked")
	if err := os.Symlink(target, linked); err != nil {
		t.Fatal(err)
	}
	configuration := config{Name: "multikernel", CacheDir: filepath.Join(linked, "new-cache")}
	env := environment{ContainerID: "box", IfName: "eth0"}
	err := writeCache(configuration, env, cacheRecord{Version: 1, Generation: "0123456789abcdef0123456789abcdef", NetNS: "/run/netns/box"})
	if err == nil {
		t.Fatal("cache beneath symlinked ancestor was accepted")
	}
	if _, statErr := os.Stat(filepath.Join(target, "new-cache")); !errors.Is(statErr, os.ErrNotExist) {
		t.Fatalf("cache creation mutated symlink target: %v", statErr)
	}
}

func TestCachePublicationIsIdempotentAndGenerationExclusive(t *testing.T) {
	input := validConfig(t)
	configuration, err := validateConfig(input)
	if err != nil {
		t.Fatal(err)
	}
	env := environment{ContainerID: "box", IfName: "eth0"}
	first := cacheRecord{Version: 1, Generation: "0123456789abcdef0123456789abcdef", NetNS: "/run/netns/box"}
	if err = writeCache(configuration, env, first); err != nil {
		t.Fatal(err)
	}
	if err = writeCache(configuration, env, first); err != nil {
		t.Fatalf("exact cache replay failed: %v", err)
	}
	conflict := first
	conflict.Generation = "abcdef0123456789abcdef0123456789"
	if err = writeCache(configuration, env, conflict); err == nil || !strings.Contains(err.Error(), "different generation") {
		t.Fatalf("conflicting cache generation error = %v", err)
	}
	observed, err := readCache(configuration, env)
	if err != nil || observed != first {
		t.Fatalf("cache after conflict = %+v, %v", observed, err)
	}
	entries, err := os.ReadDir(configuration.CacheDir)
	if err != nil || len(entries) != 1 || entries[0].Name() != filepath.Base(cachePath(configuration, env)) {
		t.Fatalf("cache directory after replay = %v, %v", entries, err)
	}
	linked := filepath.Join(configuration.CacheDir, "attacker-link")
	if err = os.Link(cachePath(configuration, env), linked); err != nil {
		t.Fatal(err)
	}
	if _, err = readCache(configuration, env); err == nil {
		t.Fatal("hard-linked cache ownership record was accepted")
	}
}
