#!/usr/bin/env bash
# Privileged, disposable-host-only diagnostic. No hostile-kernel memory probe.
set -euo pipefail
: "${MK_SECURITY_DISPOSABLE:?set MK_SECURITY_DISPOSABLE=yes on the disposable host}"
[[ $MK_SECURITY_DISPOSABLE == yes ]]
repo_dir=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
kerf=${KERF:?set KERF to the pinned executable}
kernel=${KERNEL:?set KERNEL to the pinned vmlinux}
module=${MK_TRANSPORT_MODULE:?}
relay=${MK_RELAY:?}
agent=${MK_AGENT:?}
ctl=${MK_AGENTCTL:?}
evidence=${EVIDENCE_DIR:?}
mkdir -p "$evidence"
[[ $(uname -r) == 7.0.0-mk2-gce-lab ]]
[[ -d /sys/fs/multikernel/instances ]]
[[ -z $(find /sys/fs/multikernel/instances -mindepth 1 -maxdepth 1 -type d -print -quit) ]]
before_cpus=$(cat /sys/devices/system/cpu/online)
[[ $before_cpus == 0-15 ]]
scratch=$(mktemp -d)
chmod 0700 "$scratch"
name=runtime-g7-authority
port=7717
relay_pid=; console_pid=; token=
cleanup_fixture() {
    local status
    if [[ -n $relay_pid ]]; then kill "$relay_pid" 2>/dev/null || true; wait "$relay_pid" 2>/dev/null || true; relay_pid=; fi
    if [[ -d /sys/fs/multikernel/instances/$name ]]; then
        status=$(cat "/sys/fs/multikernel/instances/$name/status")
        [[ $status != active ]] || sudo "$kerf" kill "$name" --force
        status=$(cat "/sys/fs/multikernel/instances/$name/status")
        [[ $status != loaded ]] || sudo "$kerf" unload "$name"
        sudo "$kerf" delete "$name"
    fi
    if [[ -n $console_pid ]]; then wait "$console_pid" 2>/dev/null || true; console_pid=; fi
    sudo "$kerf" init --cpus=none --memory=none --devices=none
}
cleanup_all() {
    local status=$?
    trap - EXIT
    set +e
    if [[ $status != 0 ]]; then
        python3 - "$scratch" "$evidence" "${fixture:-setup}" "$token" "$status" <<'PY'
import pathlib,sys,json
scratch,out=map(pathlib.Path,sys.argv[1:3]);fixture,token,status=sys.argv[3:]
for name in ['console.log','control.err','relay.log','kerf.log']:
    if (scratch/name).exists():
        data=(scratch/name).read_text(errors='replace')
        if token:
            data=data.replace(token,'[REDACTED_TEST_TOKEN]')
        (out/(fixture+'-failed-'+name)).write_text(data)
(out/'failed-attempt.json').write_text(json.dumps({'fixture':fixture,'exit_status':int(status)})+'\n')
PY
    fi
    cleanup_fixture
    rm -rf "$scratch"
    exit "$status"
}
trap cleanup_all EXIT
sudo modprobe vsock
lsmod | grep -q '^mk_transport ' || sudo insmod "$module"
sha256sum "$kernel" "$module" "$relay" "$agent" "$ctl" > "$evidence/component-hashes.txt"
uname -r > "$evidence/kernel-release.txt"
for fixture in nonroot root-empty-caps root-default; do
    generation=$(od -An -N16 -tx1 /dev/urandom | tr -d ' \n')
    token=$(od -An -N32 -tx1 /dev/urandom | tr -d ' \n')
    initrd=$scratch/$fixture.cpio.gz
    bash "$repo_dir/scripts/build-security-authority-initramfs.sh" "$agent" "$relay" "$module" "$fixture" "$initrd" \
        > "$evidence/$fixture-initramfs.txt"
    sudo "$kerf" init --cpus=8,10,12,14 --memory=8GB --devices=none > "$scratch/kerf.log" 2>&1
    sudo "$kerf" create "$name" --id=27 --cpus=8,10 --memory=4GB >> "$scratch/kerf.log" 2>&1
    sudo "$kerf" load "$name" --kernel="$kernel" --initrd="$initrd" \
        --cmdline="rdinit=/init console=mktty0 panic=-1 mk.sandbox_id=$name mk.generation=$generation mk.token=$token mk.agent_port=$port" \
        >> "$scratch/kerf.log" 2>&1
    "$relay" server "$port" "$scratch/relay.sock" > "$scratch/relay.log" 2>&1 &
    relay_pid=$!
    sudo timeout 60s script -qefc "$kerf exec $name --console" /dev/null > "$scratch/console.log" 2>&1 &
    console_pid=$!
    # The relay creates its Unix listener after the child connects over vsock.
    for ((attempt=0; attempt<300; attempt++)); do
        [[ ! -S $scratch/relay.sock ]] || break
        kill -0 "$relay_pid" 2>/dev/null || break
        sleep 0.1
    done
    [[ -S $scratch/relay.sock ]]
    # The probe emits only booleans for credential visibility. Raw console can
    # contain the boot command line; redact before moving it into evidence.
    timeout 60s "$ctl" --port="$port" --unix-socket="$scratch/relay.sock" \
        --sandbox-id="$name" --generation="$generation" --token-hex="$token" --bundle=/bundle \
        > "$scratch/result.json" 2> "$scratch/control.err"
    python3 - "$scratch" "$evidence" "$fixture" "$token" <<'PY'
import pathlib,sys,json
scratch,out,fixture=map(pathlib.Path,sys.argv[1:4]);token=sys.argv[4]
raw=json.loads((scratch/'result.json').read_text())
result=raw['WaitProcess']
assert result['exit_code']==0,result['exit_code']
assert 'SECURITY_AUTHORITY_END' in result['stdout']
assert token not in json.dumps(raw), 'probe printed a credential'
(out/(str(fixture)+'-result.json')).write_text(json.dumps(raw,indent=2)+'\n')
for name in ['console.log','control.err','relay.log','kerf.log']:
    data=(scratch/name).read_text(errors='replace').replace(token,'[REDACTED_TEST_TOKEN]')
    (out/(str(fixture)+'-'+name)).write_text(data)
PY
    cleanup_fixture > "$evidence/$fixture-cleanup.txt" 2>&1
    rm -f "$scratch/relay.sock"
    [[ $(cat /sys/devices/system/cpu/online) == "$before_cpus" ]]
    [[ ! -d /sys/fs/multikernel/instances/$name ]]
    echo "SECURITY_AUTHORITY_FIXTURE_COMPLETED case=$fixture"
done
printf '{"online_cpus":"%s","active_test_children":0,"fixture_count":3}\n' "$before_cpus" > "$evidence/final-inventory.json"
echo SECURITY_AUTHORITY_COLLECTION_COMPLETED
