#!/bin/busybox sh
# Experimental approved-builder-image bootstrap. Run before accepting workloads.
# UID mappings are established by trusted bootstrap; builder exec enables NNP.
set -eu
root=/bundle/rootfs
mkdir -p "$root/run/buildkit" "$root/run/user/1000"
chown 1000:1000 "$root/run/buildkit" "$root/run/user/1000"
chmod 0700 "$root/run/user/1000"
chmod 0755 "$root/run/buildkit"
# Create the user namespace before chroot: Linux rejects CLONE_NEWUSER when
# the caller's filesystem root differs from its mount namespace root.
/bin/busybox su user -s /bin/sh -c \
    'export TMPDIR=/home/user/.local/tmp XDG_RUNTIME_DIR=/run/user/1000; exec rootlesskit /bin/busybox chroot /bundle/rootfs /bin/busybox setpriv --nnp buildkitd --rootless --oci-worker-snapshotter=native --oci-worker-net=host --addr unix:///run/buildkit/buildkitd.sock --root /home/user/.local/share/buildkit' \
    >/buildkit-bootstrap.log 2>&1 &
builder_pid=$!
for attempt in $(seq 1 100); do
    if [ -S "$root/run/buildkit/buildkitd.sock" ]; then
        # Local to this dedicated workload guest; never exposed on TCP/primary.
        chmod 0666 "$root/run/buildkit/buildkitd.sock"
        echo MK_GUEST_BUILDER_READY
        exit 0
    fi
    kill -0 "$builder_pid" 2>/dev/null || break
    sleep 0.1
done
cat /buildkit-bootstrap.log
echo MK_GUEST_BUILDER_FAILED
exit 1
