package agent

import (
	"bytes"
	"context"
	"crypto/sha256"
	"debug/elf"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"slices"
	"sort"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"time"

	"github.com/containerd/console"
	"github.com/hairizuan/multikernel-linux-expt/runtime/internal/boundedexec"
	"github.com/hairizuan/multikernel-linux-expt/runtime/internal/safefile"
	"golang.org/x/sys/unix"
)

type User struct {
	UID            uint32   `json:"uid"`
	GID            uint32   `json:"gid"`
	AdditionalGids []uint32 `json:"additionalGids,omitempty"`
}
type Rlimit struct {
	Type string `json:"type"`
	Hard uint64 `json:"hard"`
	Soft uint64 `json:"soft"`
}
type ProcessSpec struct {
	Terminal        bool                `json:"terminal,omitempty"`
	ConsoleSize     *ConsoleSize        `json:"consoleSize,omitempty"`
	User            User                `json:"user"`
	Args            []string            `json:"args"`
	Env             []string            `json:"env,omitempty"`
	Cwd             string              `json:"cwd"`
	NoNewPrivileges *bool               `json:"noNewPrivileges,omitempty"`
	Rlimits         []Rlimit            `json:"rlimits,omitempty"`
	Capabilities    map[string][]string `json:"capabilities,omitempty"`
}
type ConsoleSize struct {
	Width  uint32 `json:"width"`
	Height uint32 `json:"height"`
}
type Root struct {
	Path     string `json:"path"`
	Readonly *bool  `json:"readonly,omitempty"`
}
type MountSpec struct {
	Destination string   `json:"destination"`
	Type        string   `json:"type"`
	Source      string   `json:"source"`
	Options     []string `json:"options"`
}
type OCIConfig struct {
	OCIVersion string                     `json:"ociVersion"`
	Process    ProcessSpec                `json:"process"`
	Root       Root                       `json:"root"`
	Hostname   string                     `json:"hostname,omitempty"`
	Mounts     []MountSpec                `json:"mounts,omitempty"`
	Hooks      map[string]json.RawMessage `json:"hooks,omitempty"`
	Linux      *struct {
		Namespaces    []json.RawMessage `json:"namespaces,omitempty"`
		Resources     json.RawMessage   `json:"resources,omitempty"`
		Seccomp       json.RawMessage   `json:"seccomp,omitempty"`
		MaskedPaths   []string          `json:"maskedPaths,omitempty"`
		ReadonlyPaths []string          `json:"readonlyPaths,omitempty"`
	} `json:"linux,omitempty"`
	Annotations map[string]string `json:"annotations,omitempty"`
}
type ProcessState struct {
	ID              string `json:"id"`
	Status          string `json:"status"`
	PID             int    `json:"pid,omitempty"`
	ExitCode        int    `json:"exit_code,omitempty"`
	Stdout          string `json:"stdout,omitempty"`
	Stderr          string `json:"stderr,omitempty"`
	StdoutTruncated bool   `json:"stdout_truncated,omitempty"`
	StderrTruncated bool   `json:"stderr_truncated,omitempty"`
}
type ProcessStats struct {
	CPUUserNS   uint64 `json:"cpu_user_ns"`
	CPUSystemNS uint64 `json:"cpu_system_ns"`
	RSSBytes    uint64 `json:"rss_bytes"`
	PIDs        uint64 `json:"pids"`
}
type process struct {
	spec                 ProcessSpec
	root                 string
	cmd                  *exec.Cmd
	terminal             console.Console
	stdin                io.WriteCloser
	inputMu              sync.Mutex
	stdinClosed          bool
	stdinOffset          uint64
	stdinLastStart       uint64
	stdinLastSize        uint64
	stdinLastHash        [sha256.Size]byte
	stdinHasLast         bool
	stdinPartialStart    uint64
	stdinPartialSize     uint64
	stdinPartialHash     [sha256.Size]byte
	stdinPartialAccepted uint64
	stdinHasPartial      bool
	stdout, stderr       lockedBuffer
	outputDone           chan struct{}
	done                 chan struct{}
	state                ProcessState
	waited               bool
}

type signalResult struct {
	id     string
	signal syscall.Signal
	err    error
}

type lockedBuffer struct {
	mu        sync.Mutex
	b         bytes.Buffer
	base      uint64
	space     chan struct{}
	truncated bool
}

const (
	maxProcesses       = 1024
	maxOutputBytes     = 4 << 20
	maxProcessArgs     = 256
	maxProcessEnv      = 1024
	maxProcessText     = 128 << 10
	maxSupplementalGID = 256
)

func (b *lockedBuffer) Write(p []byte) (int, error) {
	total := len(p)
	timer := time.NewTimer(100 * time.Millisecond)
	defer timer.Stop()
	for len(p) > 0 {
		b.mu.Lock()
		if b.space == nil {
			b.space = make(chan struct{})
		}
		available := maxOutputBytes - b.b.Len()
		if available > 0 {
			if available > len(p) {
				available = len(p)
			}
			_, _ = b.b.Write(p[:available])
			p = p[available:]
			b.mu.Unlock()
			continue
		}
		space := b.space
		b.mu.Unlock()
		select {
		case <-space:
		case <-timer.C:
			b.mu.Lock()
			b.truncated = true
			b.mu.Unlock()
			return total, nil
		}
	}
	return total, nil
}

func (b *lockedBuffer) slice(offset, limit uint64) ([]byte, uint64) {
	b.mu.Lock()
	defer b.mu.Unlock()
	if offset > b.base {
		discard := offset - b.base
		if discard > uint64(b.b.Len()) {
			discard = uint64(b.b.Len())
		}
		if discard > 0 {
			b.b.Next(int(discard))
			b.base += discard
			if b.space != nil {
				close(b.space)
				b.space = make(chan struct{})
			}
		}
	}
	if offset < b.base {
		offset = b.base
	}
	end := b.base + uint64(b.b.Len())
	if offset >= end {
		return nil, end
	}
	if limit > 0 && end-offset > limit {
		end = offset + limit
	}
	startIndex := offset - b.base
	endIndex := end - b.base
	data := append([]byte(nil), b.b.Bytes()[startIndex:endIndex]...)
	return data, end
}

func (b *lockedBuffer) String() string {
	b.mu.Lock()
	defer b.mu.Unlock()
	return b.b.String()
}

func (b *lockedBuffer) Truncated() bool {
	b.mu.Lock()
	defer b.mu.Unlock()
	return b.truncated
}

type Manager struct {
	mu            sync.Mutex
	processes     map[string]*process
	network       *os.File
	networkName   string
	networkMTU    int
	networkConfig NetworkConfig
	networkExec   func(context.Context, ...string) ([]byte, error)
	dnsOwner      *dnsReplacement
	dnsManaged    bool
	dnsPath       string
	policySet     bool
	signalProcess func(int, syscall.Signal) error
	signalResults map[string]signalResult
	signalOrder   []string
	NoChroot      bool
}

func NewManager(noChroot bool) *Manager {
	return &Manager{processes: map[string]*process{}, networkExec: runNetworkCommand,
		dnsPath: "/bundle/rootfs/etc/resolv.conf", signalProcess: syscall.Kill, NoChroot: noChroot}
}

func strictJSON(path string, v any) error {
	descriptor, e := unix.Openat2(unix.AT_FDCWD, path, &unix.OpenHow{
		Flags:   uint64(unix.O_RDONLY | unix.O_CLOEXEC),
		Resolve: unix.RESOLVE_NO_SYMLINKS | unix.RESOLVE_NO_MAGICLINKS,
	})
	if e != nil {
		return e
	}
	f := os.NewFile(uintptr(descriptor), path)
	defer f.Close()
	before, e := f.Stat()
	if e != nil {
		return e
	}
	identity, ok := before.Sys().(*syscall.Stat_t)
	if !ok || !before.Mode().IsRegular() || identity.Nlink != 1 || identity.Uid != uint32(os.Geteuid()) || before.Mode().Perm()&0022 != 0 || before.Size() > 1<<20 {
		return errorf(invalidArgument, "JSON input must be a bounded private caller-owned single-link regular file")
	}
	data, e := io.ReadAll(io.LimitReader(f, (1<<20)+1))
	if e != nil || len(data) > 1<<20 {
		return errorf(invalidArgument, "JSON input exceeds the retained byte limit")
	}
	after, e := f.Stat()
	if e != nil {
		return e
	}
	afterIdentity, ok := after.Sys().(*syscall.Stat_t)
	if !ok || identity.Dev != afterIdentity.Dev || identity.Ino != afterIdentity.Ino ||
		identity.Size != afterIdentity.Size || identity.Mtim != afterIdentity.Mtim || identity.Ctim != afterIdentity.Ctim {
		return errorf(invalidArgument, "JSON input identity changed while reading")
	}
	d := json.NewDecoder(bytes.NewReader(data))
	d.DisallowUnknownFields()
	if e = d.Decode(v); e != nil {
		return e
	}
	var x any
	if e = d.Decode(&x); e != io.EOF {
		return errorf(invalidArgument, "multiple JSON values")
	}
	return nil
}
func LoadBundle(bundle string) (OCIConfig, string, error) {
	if !filepath.IsAbs(bundle) {
		return OCIConfig{}, "", errorf(invalidArgument, "bundle must be absolute")
	}
	if e := secureDirectory(bundle); e != nil {
		return OCIConfig{}, "", e
	}
	var c OCIConfig
	configPath := filepath.Join(bundle, "config.json")
	if e := strictJSON(configPath, &c); e != nil {
		return c, "", e
	}
	if c.OCIVersion != "1.1.0" {
		return c, "", errorf(unsupported, "unsupported OCI version %q", c.OCIVersion)
	}
	if e := validateProcessSpec(c.Process); e != nil {
		return c, "", e
	}
	if c.Hooks != nil {
		return c, "", errorf(unsupported, "hooks are not implemented")
	}
	if err := validateReadonlyBindMounts(c.Mounts); err != nil {
		return c, "", err
	}
	if c.Linux != nil {
		if c.Linux.Namespaces != nil || c.Linux.Resources != nil || c.Linux.Seccomp != nil {
			return c, "", errorf(unsupported, "Linux namespaces/resources/seccomp are not implemented in the guest projection")
		}
		if err := validateRootPolicy(c.Linux.MaskedPaths, c.Linux.ReadonlyPaths); err != nil {
			return c, "", err
		}
	}
	if c.Annotations != nil {
		return c, "", errorf(unsupported, "annotations are not implemented")
	}
	root := c.Root.Path
	if filepath.IsAbs(root) || root == "" || filepath.Clean(root) != root || root == ".." || strings.HasPrefix(root, "../") {
		return c, "", errorf(invalidArgument, "root.path must be a safe bundle-relative directory")
	}
	root = filepath.Join(bundle, root)
	if e := secureDirectory(root); e != nil {
		return c, "", e
	}
	return c, root, nil
}

func secureDirectory(directory string) error {
	if !filepath.IsAbs(directory) {
		return errorf(invalidArgument, "directory must be absolute")
	}
	current := string(filepath.Separator)
	for _, component := range strings.Split(strings.TrimPrefix(filepath.Clean(directory), string(filepath.Separator)), string(filepath.Separator)) {
		if component == "" {
			continue
		}
		current = filepath.Join(current, component)
		info, err := os.Lstat(current)
		if err != nil {
			return errorf(invalidArgument, "root path component is unavailable")
		}
		if info.Mode()&os.ModeSymlink != 0 || !info.IsDir() {
			return errorf(invalidArgument, "root path must contain only real directories")
		}
	}
	return nil
}
func validProcessID(id string) bool {
	if id == "" || len(id) > 64 {
		return false
	}
	for _, r := range id {
		if !(r >= 'a' && r <= 'z' || r >= '0' && r <= '9' || r == '-') {
			return false
		}
	}
	return true
}

func processCreateError(stage string, err error) error {
	return &stageError{operation: "process create", stage: stage, cause: err}
}

func (m *Manager) Create(id, bundle string) error {
	if !validProcessID(id) {
		return errorf(invalidArgument, "invalid process ID")
	}
	c, root, e := LoadBundle(bundle)
	if e != nil {
		return processCreateError("bundle-load", e)
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	if _, ok := m.processes[id]; ok {
		return errorf(alreadyExists, "process exists")
	}
	if len(m.processes) >= maxProcesses {
		return errorf(failedPrecondition, "process retention limit reached")
	}
	if !m.policySet {
		if m.NoChroot && (c.Hostname != "" || c.Root.Readonly != nil || c.Linux != nil || len(c.Mounts) != 0) {
			return errorf(failedPrecondition, "root policy cannot be applied in no-chroot test mode")
		}
		if e = applyRootPolicy(c, root); e != nil {
			return processCreateError("root-policy", e)
		}
		m.policySet = true
	}
	m.processes[id] = &process{spec: c.Process, root: root, done: make(chan struct{}), state: ProcessState{ID: id, Status: "CREATED"}}
	return nil
}

// Exec creates an additional process in the validated root of an existing
// parent process. Protocol callers cannot select a new host path.
func (m *Manager) Exec(id, parentID string, spec ProcessSpec) error {
	if !validProcessID(id) {
		return errorf(invalidArgument, "invalid process ID")
	}
	if err := validateProcessSpec(spec); err != nil {
		return err
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	parent, ok := m.processes[parentID]
	if !ok {
		return errorf(notFound, "parent process not found")
	}
	root := parent.root
	if err := secureDirectory(root); err != nil {
		return err
	}
	if _, ok := m.processes[id]; ok {
		return errorf(alreadyExists, "process exists")
	}
	if len(m.processes) >= maxProcesses {
		return errorf(failedPrecondition, "process retention limit reached")
	}
	m.processes[id] = &process{spec: spec, root: root, done: make(chan struct{}), state: ProcessState{ID: id, Status: "CREATED"}}
	return nil
}
func envList(v []string) error {
	for _, x := range v {
		p := strings.IndexByte(x, '=')
		if p < 1 || strings.IndexByte(x[:p], 0) >= 0 {
			return errorf(invalidArgument, "invalid environment entry")
		}
	}
	return nil
}

func validateProcessSpec(spec ProcessSpec) error {
	if spec.ConsoleSize != nil {
		if !spec.Terminal {
			return errorf(invalidArgument, "console size requires a terminal")
		}
		if spec.ConsoleSize.Width > 65535 || spec.ConsoleSize.Height > 65535 {
			return errorf(invalidArgument, "console size exceeds the Linux PTY limit")
		}
	}
	if len(spec.Args) == 0 || len(spec.Args) > maxProcessArgs || spec.Args[0] == "" {
		return errorf(invalidArgument, "process args must contain a bounded non-empty argv[0]")
	}
	textBytes := 0
	for _, argument := range spec.Args {
		if strings.IndexByte(argument, 0) >= 0 {
			return errorf(invalidArgument, "process args contain NUL")
		}
		textBytes += len(argument) + 1
		if textBytes > maxProcessText {
			return errorf(invalidArgument, "process args exceed the retained byte limit")
		}
	}
	if len(spec.Env) > maxProcessEnv {
		return errorf(invalidArgument, "too many process environment entries")
	}
	seenEnvironment := make(map[string]struct{}, len(spec.Env))
	for _, value := range spec.Env {
		separator := strings.IndexByte(value, '=')
		if separator < 1 || strings.IndexByte(value, 0) >= 0 {
			return errorf(invalidArgument, "invalid environment entry")
		}
		name := value[:separator]
		if _, duplicate := seenEnvironment[name]; duplicate {
			return errorf(invalidArgument, "duplicate environment name %q", name)
		}
		seenEnvironment[name] = struct{}{}
		textBytes += len(value) + 1
		if textBytes > maxProcessText {
			return errorf(invalidArgument, "process args and environment exceed the retained byte limit")
		}
	}
	if spec.Cwd == "" || !filepath.IsAbs(spec.Cwd) || filepath.Clean(spec.Cwd) != spec.Cwd || strings.IndexByte(spec.Cwd, 0) >= 0 || len(spec.Cwd) > 4096 {
		return errorf(invalidArgument, "process cwd must be absolute, canonical, and bounded")
	}
	if len(spec.User.AdditionalGids) > maxSupplementalGID {
		return errorf(invalidArgument, "too many supplemental groups")
	}
	seenGroups := make(map[uint32]struct{}, len(spec.User.AdditionalGids))
	for _, group := range spec.User.AdditionalGids {
		if _, duplicate := seenGroups[group]; duplicate {
			return errorf(invalidArgument, "duplicate supplemental group %d", group)
		}
		seenGroups[group] = struct{}{}
	}
	return validateExecConstraints(spec)
}
func gids(v []uint32) []uint32 { r := make([]uint32, len(v)); copy(r, v); return r }
func (m *Manager) Start(id string) error {
	return m.StartWithSize(id, 0, 0, false)
}

func processStartError(stage string, err error) error {
	return &stageError{operation: "process start", stage: stage, cause: err}
}

const ociExecPath = "/proc/self/exe"

func (m *Manager) StartWithSize(id string, width, height uint32, sizeSet bool) error {
	if width > 65535 || height > 65535 {
		return errorf(invalidArgument, "terminal dimensions exceed the Linux PTY limit")
	}
	m.mu.Lock()
	p, ok := m.processes[id]
	if !ok {
		m.mu.Unlock()
		return errorf(notFound, "process not found")
	}
	if p.state.Status == "RUNNING" {
		m.mu.Unlock()
		return nil
	}
	if p.state.Status != "CREATED" {
		m.mu.Unlock()
		return errorf(failedPrecondition, "process is not created")
	}
	if !sizeSet && p.spec.ConsoleSize != nil {
		width, height, sizeSet = p.spec.ConsoleSize.Width, p.spec.ConsoleSize.Height, true
	}
	if e := envList(p.spec.Env); e != nil {
		m.mu.Unlock()
		return e
	}
	exe := p.spec.Args[0]
	if !strings.HasPrefix(exe, "/") {
		m.mu.Unlock()
		return errorf(invalidArgument, "argv[0] must be absolute")
	}
	if e := validateExecutableArchitecture(filepath.Join(p.root, exe)); e != nil {
		m.mu.Unlock()
		return processStartError("executable", e)
	}
	commandPath := exe
	commandArgs := p.spec.Args[1:]
	executionSpec := p.spec
	if !m.NoChroot {
		executionSpec = workloadDefaults(executionSpec)
	}
	if executionSpec.NoNewPrivileges != nil || executionSpec.Rlimits != nil || executionSpec.Capabilities != nil {
		constraints, constraintErr := encodeExecConstraints(executionSpec)
		if constraintErr != nil {
			m.mu.Unlock()
			return processStartError("constraints", constraintErr)
		}
		// The agent is intentionally outside the OCI root.  Guest init binds the
		// trusted procfs into that root, so this magic link remains an exact
		// handle to the current agent across chroot without copying a helper into
		// the workload filesystem.
		commandPath = ociExecPath
		commandArgs = append([]string{"__oci_exec", constraints}, p.spec.Args...)
	}
	cmd := exec.Command(commandPath, commandArgs...)
	cmd.Env = append([]string(nil), p.spec.Env...)
	cmd.Dir = p.spec.Cwd
	cmd.SysProcAttr = &syscall.SysProcAttr{Setpgid: true}
	if !m.NoChroot {
		cmd.SysProcAttr.Credential = &syscall.Credential{Uid: p.spec.User.UID, Gid: p.spec.User.GID, Groups: gids(p.spec.User.AdditionalGids), NoSetGroups: false}
		cmd.SysProcAttr.Chroot = p.root
	} else {
		cmd.Path = filepath.Join(p.root, exe)
		if p.spec.Cwd != "" {
			cmd.Dir = filepath.Join(p.root, p.spec.Cwd)
		}
	}
	var slave *os.File
	var err error
	if p.spec.Terminal {
		var slavePath string
		p.terminal, slavePath, err = console.NewPty()
		if err != nil {
			m.mu.Unlock()
			return processStartError("terminal", err)
		}
		slave, err = os.OpenFile(slavePath, os.O_RDWR, 0)
		if err != nil {
			p.terminal.Close()
			p.terminal = nil
			m.mu.Unlock()
			return processStartError("terminal", err)
		}
		cmd.Stdin, cmd.Stdout, cmd.Stderr = slave, slave, slave
		cmd.SysProcAttr.Setpgid = false
		cmd.SysProcAttr.Setsid = true
		cmd.SysProcAttr.Setctty = true
		cmd.SysProcAttr.Ctty = 0
		p.outputDone = make(chan struct{})
		if sizeSet {
			if err = p.terminal.Resize(console.WinSize{Width: uint16(width), Height: uint16(height)}); err != nil {
				slave.Close()
				p.terminal.Close()
				p.terminal = nil
				m.mu.Unlock()
				return processStartError("terminal", err)
			}
		}
	} else {
		if sizeSet {
			m.mu.Unlock()
			return errorf(invalidArgument, "cannot size a process without a terminal")
		}
		p.stdin, err = cmd.StdinPipe()
		if err != nil {
			m.mu.Unlock()
			return processStartError("stdio", err)
		}
		cmd.Stdout = &p.stdout
		cmd.Stderr = &p.stderr
	}
	if e := cmd.Start(); e != nil {
		p.inputMu.Lock()
		if p.stdin != nil {
			_ = p.stdin.Close()
			p.stdin = nil
		}
		p.stdinClosed = false
		p.inputMu.Unlock()
		if slave != nil {
			slave.Close()
		}
		if p.terminal != nil {
			p.terminal.Close()
			p.terminal = nil
		}
		m.mu.Unlock()
		return processStartError("exec", e)
	}
	if slave != nil {
		slave.Close()
		p.stdin = p.terminal
		go func() {
			_, _ = io.Copy(&p.stdout, p.terminal)
			close(p.outputDone)
		}()
	}
	p.cmd = cmd
	p.state.Status = "RUNNING"
	p.state.PID = cmd.Process.Pid
	m.mu.Unlock()
	go m.wait(p)
	return nil
}

func validateExecutableArchitecture(path string) error {
	info, err := os.Stat(path)
	if err != nil || !info.Mode().IsRegular() {
		return errors.New("executable is not a regular file")
	}
	binary, err := elf.Open(path)
	if err != nil {
		return errors.New("executable is not a supported ELF image")
	}
	defer binary.Close()
	if binary.FileHeader.Class != elf.ELFCLASS64 || binary.FileHeader.Machine != elf.EM_X86_64 {
		return fmt.Errorf("executable architecture is not linux/amd64: class=%s machine=%s", binary.FileHeader.Class, binary.FileHeader.Machine)
	}
	return nil
}
func (m *Manager) wait(p *process) {
	e := p.cmd.Wait()
	if p.outputDone != nil {
		<-p.outputDone
	}
	code := 0
	if e != nil {
		var x *exec.ExitError
		if errors.As(e, &x) {
			if status, ok := x.Sys().(syscall.WaitStatus); ok && status.Signaled() {
				code = 128 + int(status.Signal())
			} else {
				code = x.ExitCode()
			}
		} else {
			code = 255
		}
	}
	m.mu.Lock()
	p.inputMu.Lock()
	if !p.stdinClosed {
		p.stdinClosed = true
		if p.stdin != nil && !p.spec.Terminal {
			_ = p.stdin.Close()
		}
	}
	p.inputMu.Unlock()
	if p.terminal != nil {
		_ = p.terminal.Close()
	}
	p.state.Status = "STOPPED"
	p.state.ExitCode = code
	p.state.Stdout = p.stdout.String()
	p.state.Stderr = p.stderr.String()
	p.state.StdoutTruncated = p.stdout.Truncated()
	p.state.StderrTruncated = p.stderr.Truncated()
	p.terminal = nil
	close(p.done)
	m.mu.Unlock()
}

func (m *Manager) Write(id string, data []byte) error {
	m.mu.Lock()
	p, ok := m.processes[id]
	m.mu.Unlock()
	if !ok {
		return errorf(failedPrecondition, "process is not running")
	}
	p.inputMu.Lock()
	offset := p.stdinOffset
	p.inputMu.Unlock()
	_, err := m.WriteAt(id, offset, data)
	return err
}

// WriteAt delivers one stdin chunk exactly once for a live agent process.
// Replaying the most recently acknowledged offset and bytes is idempotent,
// which makes a lost transport response safe to retry after reconnect. If the
// local writer reports an error after accepting a prefix, an exact replay
// resumes at the first byte not yet accepted instead of duplicating the prefix.
func (m *Manager) WriteAt(id string, offset uint64, data []byte) (uint64, error) {
	if len(data) == 0 || len(data) > 64<<10 {
		return 0, errorf(invalidArgument, "stdin chunk must contain between 1 byte and 64 KiB")
	}
	m.mu.Lock()
	p, ok := m.processes[id]
	if !ok {
		m.mu.Unlock()
		return 0, errorf(failedPrecondition, "process is not running")
	}
	p.inputMu.Lock()
	running := p.state.Status == "RUNNING"
	m.mu.Unlock()
	defer p.inputMu.Unlock()
	digest := sha256.Sum256(data)
	if p.stdinHasLast && offset == p.stdinLastStart && uint64(len(data)) == p.stdinLastSize && digest == p.stdinLastHash &&
		p.stdinOffset == offset+uint64(len(data)) {
		return p.stdinOffset, nil
	}
	if p.stdinHasPartial && (offset != p.stdinPartialStart || uint64(len(data)) != p.stdinPartialSize || digest != p.stdinPartialHash) {
		return p.stdinOffset, errorf(invalidArgument, "stdin chunk offset or data differs from the partially accepted replay")
	}
	if !running {
		return p.stdinOffset, errorf(failedPrecondition, "process is not running")
	}
	if p.stdinClosed || p.stdin == nil {
		return p.stdinOffset, errorf(failedPrecondition, "process stdin is closed")
	}
	if offset != p.stdinOffset || uint64(len(data)) > ^uint64(0)-offset {
		return p.stdinOffset, errorf(invalidArgument, "stdin chunk offset differs from the exact acknowledged position")
	}
	if !p.stdinHasPartial {
		p.stdinPartialStart = offset
		p.stdinPartialSize = uint64(len(data))
		p.stdinPartialHash = digest
		p.stdinPartialAccepted = 0
		p.stdinHasPartial = true
	}
	for p.stdinPartialAccepted < uint64(len(data)) {
		remaining := data[p.stdinPartialAccepted:]
		written, err := p.stdin.Write(remaining)
		if written < 0 || written > len(remaining) {
			return p.stdinOffset, errors.New("stdin writer returned an invalid byte count")
		}
		p.stdinPartialAccepted += uint64(written)
		if p.stdinPartialAccepted == uint64(len(data)) {
			break
		}
		if err != nil {
			return p.stdinOffset, err
		}
		if written == 0 {
			return p.stdinOffset, io.ErrNoProgress
		}
	}
	p.stdinLastStart, p.stdinLastSize, p.stdinLastHash, p.stdinHasLast = offset, uint64(len(data)), digest, true
	p.stdinOffset = offset + uint64(len(data))
	p.stdinPartialStart, p.stdinPartialSize, p.stdinPartialAccepted, p.stdinHasPartial = 0, 0, 0, false
	p.stdinPartialHash = [sha256.Size]byte{}
	return p.stdinOffset, nil
}

func (m *Manager) CloseStdin(id string) error {
	m.mu.Lock()
	p, ok := m.processes[id]
	if !ok {
		m.mu.Unlock()
		return errorf(notFound, "process not found")
	}
	running := p.state.Status == "RUNNING"
	m.mu.Unlock()
	if !running {
		p.inputMu.Lock()
		closed := p.stdinClosed
		p.inputMu.Unlock()
		if closed {
			return nil
		}
		return errorf(failedPrecondition, "process is not running")
	}
	p.inputMu.Lock()
	defer p.inputMu.Unlock()
	if p.stdinClosed {
		return nil
	}
	p.stdinClosed = true
	if p.stdin == nil {
		return nil
	}
	if p.spec.Terminal {
		// A PTY has no half-close. In canonical mode, EOT supplies the same
		// EOF indication without closing the output side of the console.
		_, err := p.stdin.Write([]byte{4})
		return err
	}
	return p.stdin.Close()
}

func (m *Manager) ReadOutput(id string, stdoutOffset, stderrOffset, limit uint64) ([]byte, []byte, uint64, uint64, string, error) {
	if limit == 0 || limit > 64<<10 {
		return nil, nil, 0, 0, "", errorf(invalidArgument, "output read limit must be between 1 and 64 KiB")
	}
	m.mu.Lock()
	p, ok := m.processes[id]
	if !ok {
		m.mu.Unlock()
		return nil, nil, 0, 0, "", errorf(notFound, "process not found")
	}
	status := p.state.Status
	m.mu.Unlock()
	stdout, nextStdout := p.stdout.slice(stdoutOffset, limit)
	stderr, nextStderr := p.stderr.slice(stderrOffset, limit)
	return stdout, stderr, nextStdout, nextStderr, status, nil
}

func (m *Manager) Resize(id string, width, height uint32) error {
	if width > 65535 || height > 65535 {
		return errorf(invalidArgument, "terminal dimensions exceed the Linux PTY limit")
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	p, ok := m.processes[id]
	if !ok || p.state.Status != "RUNNING" {
		return errorf(failedPrecondition, "process is not running")
	}
	if p.terminal == nil {
		return errorf(failedPrecondition, "process has no terminal")
	}
	return p.terminal.Resize(console.WinSize{Width: uint16(width), Height: uint16(height)})
}
func (m *Manager) Signal(id string, sig syscall.Signal) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	p, ok := m.processes[id]
	if !ok || p.cmd == nil || p.state.Status != "RUNNING" {
		return errorf(failedPrecondition, "process is not running")
	}
	return m.signalProcess(-p.cmd.Process.Pid, sig)
}

var signalOperationID = regexp.MustCompile(`^[0-9a-f]{32}$`)

const maxSignalResults = 4096

// SignalOnce makes an arbitrary process signal replay-safe across an agent
// transport reconnect. The operation ID is generation-scoped by the
// authenticated server and may name only one exact process/signal mutation.
func (m *Manager) SignalOnce(id string, sig syscall.Signal, operationID string) error {
	if !signalOperationID.MatchString(operationID) {
		return errorf(invalidArgument, "signal operation ID must be 32 lowercase hexadecimal characters")
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	if result, exists := m.signalResults[operationID]; exists {
		if result.id != id || result.signal != sig {
			return errorf(invalidArgument, "signal operation ID was reused with a different target or signal")
		}
		return result.err
	}
	p, ok := m.processes[id]
	if !ok || p.cmd == nil || p.state.Status != "RUNNING" {
		return errorf(failedPrecondition, "process is not running")
	}
	if m.signalResults == nil {
		m.signalResults = make(map[string]signalResult)
	}
	if len(m.signalResults) >= maxSignalResults {
		return errorf(failedPrecondition, "signal replay ledger is full")
	}
	err := m.signalProcess(-p.cmd.Process.Pid, sig)
	result := signalResult{id: id, signal: sig}
	if err != nil {
		result.err = err
	}
	m.signalResults[operationID] = result
	m.signalOrder = append(m.signalOrder, operationID)
	return err
}

// AcknowledgeSignal retires a durably observed signal result. Absence is an
// idempotent success so loss of the acknowledgement reply is replay-safe.
func (m *Manager) AcknowledgeSignal(id, operationID string) error {
	if !signalOperationID.MatchString(operationID) {
		return errorf(invalidArgument, "signal operation ID must be 32 lowercase hexadecimal characters")
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	result, exists := m.signalResults[operationID]
	if !exists {
		return nil
	}
	if result.id != id {
		return errorf(invalidArgument, "signal operation ID acknowledgement target differs")
	}
	delete(m.signalResults, operationID)
	for index, value := range m.signalOrder {
		if value == operationID {
			m.signalOrder = append(m.signalOrder[:index], m.signalOrder[index+1:]...)
			break
		}
	}
	return nil
}

func (m *Manager) Quiescent() bool {
	m.mu.Lock()
	defer m.mu.Unlock()
	for _, p := range m.processes {
		if p.state.Status == "RUNNING" {
			return false
		}
	}
	return true
}
func (m *Manager) Wait(id string) (ProcessState, error) {
	m.mu.Lock()
	p, ok := m.processes[id]
	if !ok {
		m.mu.Unlock()
		return ProcessState{}, errorf(notFound, "process not found")
	}
	if p.state.Status == "CREATED" {
		m.mu.Unlock()
		return ProcessState{}, errorf(failedPrecondition, "process is not started")
	}
	done := p.done
	m.mu.Unlock()
	<-done
	m.mu.Lock()
	defer m.mu.Unlock()
	p.waited = true
	return p.state, nil
}
func (m *Manager) State(id string) (ProcessState, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	p, ok := m.processes[id]
	if !ok {
		return ProcessState{}, errorf(notFound, "process not found")
	}
	x := p.state
	x.Stdout = p.stdout.String()
	x.Stderr = p.stderr.String()
	x.StdoutTruncated = p.stdout.Truncated()
	x.StderrTruncated = p.stderr.Truncated()
	return x, nil
}

type procStat struct {
	pgrp, userTicks, systemTicks, rssPages uint64
}

func readProcStat(path string) (procStat, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return procStat{}, err
	}
	end := strings.LastIndexByte(string(data), ')')
	if end < 0 || end+2 >= len(data) {
		return procStat{}, errors.New("malformed proc stat")
	}
	fields := strings.Fields(string(data[end+2:]))
	if len(fields) <= 21 {
		return procStat{}, errors.New("short proc stat")
	}
	parse := func(index int) (uint64, error) { return strconv.ParseUint(fields[index], 10, 64) }
	pgrp, err := parse(2)
	if err != nil {
		return procStat{}, err
	}
	user, err := parse(11)
	if err != nil {
		return procStat{}, err
	}
	system, err := parse(12)
	if err != nil {
		return procStat{}, err
	}
	rss, err := parse(21)
	if err != nil {
		return procStat{}, err
	}
	return procStat{pgrp: pgrp, userTicks: user, systemTicks: system, rssPages: rss}, nil
}

func clockTicks() uint64 {
	data, err := os.ReadFile("/proc/self/auxv")
	if err == nil {
		for len(data) >= 16 {
			key := binary.LittleEndian.Uint64(data[:8])
			value := binary.LittleEndian.Uint64(data[8:16])
			if key == 17 && value > 0 { // AT_CLKTCK
				return value
			}
			data = data[16:]
		}
	}
	return 100
}

func (m *Manager) Stats(id string) (ProcessStats, error) {
	m.mu.Lock()
	p, ok := m.processes[id]
	if !ok || p.state.PID <= 0 {
		m.mu.Unlock()
		return ProcessStats{}, errorf(notFound, "running process not found")
	}
	group := uint64(p.state.PID)
	m.mu.Unlock()
	paths, err := filepath.Glob("/proc/[0-9]*/stat")
	if err != nil {
		return ProcessStats{}, err
	}
	sort.Strings(paths)
	var result ProcessStats
	pageSize := uint64(os.Getpagesize())
	for _, path := range paths {
		stat, readErr := readProcStat(path)
		if readErr != nil || stat.pgrp != group {
			continue
		}
		result.CPUUserNS += stat.userTicks
		result.CPUSystemNS += stat.systemTicks
		result.RSSBytes += stat.rssPages * pageSize
		result.PIDs++
	}
	if result.PIDs == 0 {
		return ProcessStats{}, errorf(failedPrecondition, "process group is no longer present")
	}
	ticks := clockTicks()
	result.CPUUserNS = result.CPUUserNS * uint64(time.Second) / ticks
	result.CPUSystemNS = result.CPUSystemNS * uint64(time.Second) / ticks
	return result, nil
}
func (m *Manager) Delete(id string) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	p, ok := m.processes[id]
	if !ok {
		return nil
	}
	if p.state.Status == "RUNNING" {
		return errorf(failedPrecondition, "process is running")
	}
	if p.state.Status == "STOPPED" && !p.waited {
		return errorf(failedPrecondition, "process exit has not been waited")
	}
	delete(m.processes, id)
	for operationID, result := range m.signalResults {
		if result.id == id {
			delete(m.signalResults, operationID)
		}
	}
	order := m.signalOrder[:0]
	for _, operationID := range m.signalOrder {
		if _, exists := m.signalResults[operationID]; exists {
			order = append(order, operationID)
		}
	}
	m.signalOrder = order
	return nil
}

const (
	tunSetIFF = 0x400454ca
	iffTun    = 0x0001
	iffNoPI   = 0x1000
)

// ConfigureNetwork creates the child side of the primary-mediated point to
// point link. Packets share the authenticated agent channel because the
// pinned Multikernel VSOCK transport cannot sustain a second stream.
type NetworkConfig struct {
	Name        string   `json:"name"`
	Address     string   `json:"address"`
	Gateway     string   `json:"gateway"`
	MTU         int      `json:"mtu"`
	Nameservers []string `json:"nameservers,omitempty"`
}

func runNetworkCommand(ctx context.Context, arguments ...string) ([]byte, error) {
	return runBoundedNetworkCommand(ctx, "/bin/ip", arguments...)
}

func runBoundedNetworkCommand(ctx context.Context, binary string, arguments ...string) ([]byte, error) {
	const (
		timeout         = 30 * time.Second
		maximumOutput   = 1 << 20
		diagnosticLimit = 16 << 10
	)
	output, err := boundedexec.Run(ctx, timeout, binary, arguments,
		[]string{"PATH=/usr/sbin:/usr/bin:/sbin:/bin", "LANG=C", "LC_ALL=C"}, maximumOutput)
	if err != nil && len(output) > diagnosticLimit {
		output = output[:diagnosticLimit]
	}
	return output, err
}

func (m *Manager) executeNetworkCommand(ctx context.Context, arguments ...string) ([]byte, error) {
	if m.networkExec == nil {
		return runNetworkCommand(ctx, arguments...)
	}
	return m.networkExec(ctx, arguments...)
}

type dnsReplacement struct {
	directory       *safefile.Directory
	name            string
	original        []byte
	originalSymlink string
	originalMode    os.FileMode
	originalExisted bool
	originalRemoved bool
	managed         safefile.Identity
	managedOwned    bool
	restored        bool
}

func replaceDNS(path string, nameservers []string) (owner *dnsReplacement, retErr error) {
	absolute, err := filepath.Abs(path)
	if err != nil || filepath.Clean(absolute) != absolute || filepath.Base(absolute) == "." {
		return nil, errors.Join(errors.New("resolv.conf path must be canonical"), err)
	}
	directory, err := safefile.OpenOwnedDirectory(filepath.Dir(absolute))
	if err != nil {
		return nil, err
	}
	state := &dnsReplacement{directory: directory, name: filepath.Base(absolute)}
	cleanup := true
	defer func() {
		if cleanup {
			if restoreErr := state.restore(); restoreErr != nil {
				owner = state
				retErr = errors.Join(retErr, restoreErr)
			} else {
				retErr = errors.Join(retErr, directory.Close())
			}
		}
	}()
	entry, present, err := directory.EntryIdentity(state.name)
	if err != nil {
		return nil, err
	}
	if present {
		state.originalExisted = true
		switch entry.Mode & unix.S_IFMT {
		case unix.S_IFREG:
			state.originalMode = os.FileMode(entry.Mode).Perm()
			if state.originalMode&0022 != 0 {
				return nil, errors.New("resolv.conf may not be group/other-writable")
			}
			var opened safefile.Identity
			state.original, opened, err = directory.ReadRegularIdentity(state.name, state.originalMode, 1<<20)
			if err != nil {
				return nil, err
			}
			if removed, removeErr := directory.RemoveIfIdentity(state.name, opened); removeErr != nil || !removed {
				return nil, errors.Join(errors.New("remove exact original resolv.conf"), removeErr)
			}
			state.originalRemoved = true
		case unix.S_IFLNK:
			state.originalSymlink, entry, err = directory.CaptureSymlinkIdentity(state.name, 4096)
			if err != nil {
				return nil, err
			}
			if removed, removeErr := directory.RemoveIfIdentity(state.name, entry); removeErr != nil || !removed {
				return nil, errors.Join(errors.New("remove exact original resolv.conf symlink"), removeErr)
			}
			state.originalRemoved = true
		default:
			return nil, errors.New("resolv.conf must be a regular file or symlink")
		}
	}
	var resolv strings.Builder
	for _, server := range nameservers {
		fmt.Fprintf(&resolv, "nameserver %s\n", server)
	}
	created, managed, err := directory.PublishExclusiveRegularIdentity(state.name, []byte(resolv.String()), 0644)
	if created {
		state.managed, state.managedOwned = managed, true
	}
	if err != nil || !created {
		return nil, errors.Join(errors.New("publish managed resolv.conf exclusively"), err)
	}
	cleanup = false
	return state, nil
}

func (d *dnsReplacement) restore() error {
	if d == nil || d.directory == nil {
		return nil
	}
	if d.restored {
		return d.directory.Sync()
	}
	if d.managedOwned {
		if _, err := d.directory.RemoveIfIdentity(d.name, d.managed); err != nil {
			return err
		}
		d.managedOwned = false
	}
	if d.originalExisted && !d.originalRemoved {
		d.restored = true
		return nil
	}
	if !d.originalExisted {
		d.restored = true
		return nil
	}
	var created bool
	var err error
	if d.originalSymlink != "" {
		created, _, err = d.directory.PublishExclusiveSymlinkIdentity(d.name, d.originalSymlink, 4096)
	} else {
		created, _, err = d.directory.PublishExclusiveRegularIdentity(d.name, d.original, d.originalMode)
	}
	if created {
		d.restored = true
		d.originalRemoved = false
	}
	if err != nil || !created {
		return errors.Join(errors.New("restore original resolv.conf exclusively"), err)
	}
	return nil
}

func (m *Manager) ConfigureNetwork(config NetworkConfig) error {
	return m.ConfigureNetworkContext(context.Background(), config)
}

func networkSetupError(stage string, err error) error {
	return &stageError{operation: "network setup", stage: stage, cause: err}
}

func (m *Manager) ConfigureNetworkContext(ctx context.Context, config NetworkConfig) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	if config.Name == "" || len(config.Name) > 15 || config.Address == "" || config.Gateway == "" || config.MTU < 576 || config.MTU > 65515 {
		return errorf(invalidArgument, "valid network name, address, gateway, and MTU are required")
	}
	ip, subnet, err := net.ParseCIDR(config.Address)
	if err != nil || ip.To4() == nil {
		return errorf(invalidArgument, "network address must be IPv4 CIDR")
	}
	gateway := net.ParseIP(config.Gateway)
	if gateway == nil || !subnet.Contains(gateway) || gateway.Equal(ip) {
		return errorf(invalidArgument, "network gateway must be a distinct address in the endpoint subnet")
	}
	for _, server := range config.Nameservers {
		if net.ParseIP(server) == nil {
			return errorf(invalidArgument, "network DNS server is not an IP address")
		}
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	if m.network != nil && m.networkName == config.Name && m.networkMTU == config.MTU && m.dnsManaged &&
		m.networkConfig.Name == config.Name && m.networkConfig.Address == config.Address &&
		m.networkConfig.Gateway == config.Gateway && m.networkConfig.MTU == config.MTU &&
		slices.Equal(m.networkConfig.Nameservers, config.Nameservers) {
		return nil
	}
	if m.network != nil || m.networkName != "" || m.dnsManaged || m.networkConfig.Name != "" {
		return errorf(failedPrecondition, "network is already configured or cleanup is pending")
	}
	f, err := os.OpenFile("/dev/net/tun", os.O_RDWR|syscall.O_NONBLOCK, 0)
	if err != nil {
		return networkSetupError("tun-open", err)
	}
	request, err := unix.NewIfreq(config.Name)
	if err != nil {
		f.Close()
		return networkSetupError("tun-request", err)
	}
	request.SetUint16(iffTun | iffNoPI)
	if err = unix.IoctlIfreq(int(f.Fd()), tunSetIFF, request); err != nil {
		f.Close()
		return networkSetupError("tun-create", err)
	}
	commands := []struct {
		stage string
		args  []string
	}{
		{stage: "address", args: []string{"address", "add", config.Address, "dev", config.Name}},
		{stage: "link", args: []string{"link", "set", config.Name, "mtu", strconv.Itoa(config.MTU), "up"}},
		{stage: "route", args: []string{"route", "add", "default", "via", config.Gateway, "dev", config.Name}},
	}
	for _, command := range commands {
		if output, commandErr := m.executeNetworkCommand(ctx, command.args...); commandErr != nil {
			f.Close()
			cleanupCtx, cancel := context.WithTimeout(context.WithoutCancel(ctx), 5*time.Second)
			cleanupOutput, cleanupErr := m.executeNetworkCommand(cleanupCtx, "link", "delete", config.Name)
			cancel()
			operationErr := networkSetupError(command.stage,
				fmt.Errorf("ip %s: %w: %s", strings.Join(command.args, " "), commandErr, strings.TrimSpace(string(output))))
			if cleanupErr != nil {
				m.networkName = config.Name
				cleanupErr = fmt.Errorf("delete child network after setup failure: %w: %s", cleanupErr, strings.TrimSpace(string(cleanupOutput)))
			}
			return errors.Join(operationErr, cleanupErr)
		}
	}
	m.dnsOwner, err = replaceDNS(m.dnsPath, config.Nameservers)
	if err != nil {
		f.Close()
		m.dnsManaged = m.dnsOwner != nil
		cleanupCtx, cancel := context.WithTimeout(context.WithoutCancel(ctx), 5*time.Second)
		cleanupOutput, cleanupErr := m.executeNetworkCommand(cleanupCtx, "link", "delete", config.Name)
		cancel()
		if cleanupErr != nil {
			m.networkName = config.Name
			cleanupErr = fmt.Errorf("delete child network after DNS failure: %w: %s", cleanupErr, strings.TrimSpace(string(cleanupOutput)))
		}
		return errors.Join(networkSetupError("dns", err), cleanupErr)
	}
	m.network = f
	m.networkName = config.Name
	m.networkMTU = config.MTU
	m.networkConfig = config
	m.networkConfig.Nameservers = append([]string(nil), config.Nameservers...)
	m.dnsManaged = true
	return nil
}

// ExchangeNetwork injects at most one primary packet and returns at most one
// child packet. The short deadline keeps lifecycle RPCs responsive.
func (m *Manager) ExchangeNetwork(packet []byte) ([]byte, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	if m.network == nil {
		return nil, errorf(failedPrecondition, "network is not configured")
	}
	if len(packet) > m.networkMTU {
		return nil, errorf(invalidArgument, "network packet is too large")
	}
	if len(packet) != 0 {
		if _, err := unix.Write(int(m.network.Fd()), packet); err != nil {
			return nil, err
		}
	}
	out := make([]byte, 65535)
	for deadline := time.Now().Add(2 * time.Millisecond); ; {
		n, err := unix.Read(int(m.network.Fd()), out)
		if err == nil {
			return out[:n], nil
		}
		if !errors.Is(err, syscall.EAGAIN) && !errors.Is(err, syscall.EWOULDBLOCK) {
			return nil, err
		}
		if time.Now().After(deadline) {
			return nil, nil
		}
		time.Sleep(100 * time.Microsecond)
	}
}

func (m *Manager) CloseNetwork() error {
	return m.CloseNetworkContext(context.Background())
}

func (m *Manager) CloseNetworkContext(ctx context.Context) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	var failures []error
	if m.networkName != "" {
		if output, err := m.executeNetworkCommand(ctx, "link", "delete", m.networkName); err != nil {
			failures = append(failures, fmt.Errorf("delete child network: %w: %s", err, strings.TrimSpace(string(output))))
		} else {
			m.networkName = ""
			m.networkMTU = 0
		}
	}
	// A non-persistent TUN disappears when its final descriptor closes. Delete
	// the named link while the descriptor still owns it so a successful close
	// cannot manufacture a spurious "link not found" cleanup failure.
	if m.network != nil && m.networkName == "" {
		if err := m.network.Close(); err != nil {
			failures = append(failures, err)
		}
		// Close consumes the descriptor even when it reports a terminal close
		// error; retain the replay identity, not an unusable *os.File.
		m.network = nil
	}
	if m.dnsManaged {
		if m.dnsOwner == nil {
			failures = append(failures, errors.New("restore DNS: ownership state is missing"))
		} else if err := m.dnsOwner.restore(); err != nil {
			failures = append(failures, fmt.Errorf("restore DNS: %w", err))
		} else {
			if err := m.dnsOwner.directory.Close(); err != nil {
				failures = append(failures, fmt.Errorf("close DNS ownership: %w", err))
			}
			m.dnsOwner, m.dnsManaged = nil, false
		}
	}
	if len(failures) == 0 {
		m.networkConfig = NetworkConfig{}
	}
	return errors.Join(failures...)
}
func SignalNumber(s string) (syscall.Signal, error) {
	if n, e := strconv.Atoi(s); e == nil && n > 0 && n < 65 {
		return syscall.Signal(n), nil
	}
	m := map[string]syscall.Signal{"SIGTERM": syscall.SIGTERM, "SIGKILL": syscall.SIGKILL, "SIGINT": syscall.SIGINT, "SIGHUP": syscall.SIGHUP}
	v, ok := m[s]
	if !ok {
		return 0, errorf(unsupported, "unsupported signal")
	}
	return v, nil
}
